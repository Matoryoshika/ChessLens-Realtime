package id.chesslens.realtime;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.*;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.view.WindowManager;

import id.chesslens.realtime.engine.*;
import id.chesslens.realtime.overlay.FloatingOverlay;
import id.chesslens.realtime.vision.*;

import java.nio.ByteBuffer;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Opt-in on-device screen capture and chess-position recognition. */
public final class ScreenService extends Service {
    public static final String ACTION_STOP = "id.chesslens.realtime.STOP";
    private static final String CHANNEL = "chesslens_capture";

    private MediaProjection projection;
    private VirtualDisplay display;
    private volatile ImageReader reader;
    private final Object captureLock = new Object();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private FloatingOverlay overlay;
    private final BoardFinder finder = new BoardFinder();
    private final PositionTracker tracker = new PositionTracker();
    private PieceClassifier classifier;
    private UciEngine engine;
    private android.content.SharedPreferences learningPrefs;
    private volatile boolean showMyBest = true;
    private volatile boolean showOpponentBest = true;
    private volatile boolean playerWhite = true;
    private volatile UciEngine.Evaluation lastEvaluation;
    private volatile Rect lastAnalyzedBoard;
    private volatile String lastPlayedFrom = "", lastPlayedTo = "", lastMoveSymbol = "";
    private volatile String lastAnalysisPrefix = "";

    private volatile boolean paused = false;
    private volatile boolean forceRelock = false;
    private int width, height, thinkMs = 700;
    private Rect lastBoard, candidateBoard;
    private int boardMissCount = 0, candidateBoardCount = 0, emptyFrameCount = 0;
    private long lastCaptureDiagnosticAt = 0;
    private String lastAnalyzedFen = "";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!paused) capture();
            main.postDelayed(this, 1050);
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;
        thinkMs = Math.max(200, Math.min(3000, intent.getIntExtra("thinkMs", 700)));
        try {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 26)
                manager.createNotificationChannel(new NotificationChannel(CHANNEL, "ChessLens screen analysis", NotificationManager.IMPORTANCE_LOW));
            PendingIntent home = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Intent end = new Intent(this, ScreenService.class).setAction(ACTION_STOP);
            PendingIntent endAction = PendingIntent.getService(this, 2, end,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification note = new Notification.Builder(this, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("ChessLens Realtime aktif")
                    .setContentText("Membaca posisi papan dan menjalankan Stockfish di perangkat.")
                    .setContentIntent(home).setOngoing(true)
                    .addAction(android.R.drawable.ic_delete, "Hentikan", endAction).build();
            if (Build.VERSION.SDK_INT >= 29) startForeground(13, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(13, note);
            if (!android.provider.Settings.canDrawOverlays(this)) throw new SecurityException("Izin overlay tidak aktif");

            learningPrefs = getSharedPreferences("chesslens_learning_mode", MODE_PRIVATE);
            showMyBest = learningPrefs.getBoolean("show_my_best", true);
            showOpponentBest = learningPrefs.getBoolean("show_opponent_best", true);
            playerWhite = learningPrefs.getBoolean("player_white", true);
            overlay = new FloatingOverlay(this,
                    this::requestBoardRelock,
                    this::togglePause,
                    this::flipOrientation,
                    this::toggleSideToMove,
                    this::toggleMyBest,
                    this::toggleOpponentBest,
                    this::togglePlayerSide,
                    this::stopSelf);
            overlay.setOrientation(tracker.isWhiteBottom(), false);
            overlay.setTurn(tracker.isWhiteToMove());
            overlay.setLearningOptions(showMyBest, showOpponentBest, playerWhite);

            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            Rect bounds;
            if (Build.VERSION.SDK_INT >= 30) bounds = wm.getMaximumWindowMetrics().getBounds();
            else {
                android.graphics.Point point = new android.graphics.Point();
                wm.getDefaultDisplay().getRealSize(point);
                bounds = new Rect(0, 0, point.x, point.y);
            }
            width = bounds.width(); height = bounds.height();
            synchronized (captureLock) { reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2); }

            MediaProjectionManager projectionManager = getSystemService(MediaProjectionManager.class);
            int resultCode = intent.getIntExtra("result", Activity.RESULT_CANCELED);
            @SuppressWarnings("deprecation") Intent permission = intent.getParcelableExtra("data");
            projection = projectionManager.getMediaProjection(resultCode, permission);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(() -> stopSelf()); }
                @Override public void onCapturedContentResize(int newWidth, int newHeight) { main.post(() -> resize(newWidth, newHeight)); }
            }, main);
            display = projection.createVirtualDisplay("ChessLens", width, height,
                    getResources().getDisplayMetrics().densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, main);
            overlay.status("Screen capture aktif. Cari papan catur…");
            main.postDelayed(ticker, 900);
        } catch (Exception error) {
            if (overlay != null) overlay.status("Tidak dapat memulai: " + error.getMessage());
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void requestBoardRelock() {
        forceRelock = true;
        candidateBoard = null;
        candidateBoardCount = 0;
        overlay.clear();
        overlay.status("Mencari ulang batas papan. Posisi dan giliran tidak dihapus.");
    }

    private void togglePause() {
        paused = !paused;
        overlay.setPaused(paused);
        overlay.status(paused ? "⏸ Analisis dijeda." : "▶ Melanjutkan pembacaan papan…");
    }

    private void flipOrientation() {
        tracker.toggleOrientation();
        if (classifier != null) classifier.setRotatePieces180(!tracker.isWhiteBottom());
        lastAnalyzedFen = "";
        overlay.clear();
        overlay.setOrientation(tracker.isWhiteBottom(), true);
        overlay.status("Orientasi manual: " + (tracker.isWhiteBottom() ? "Putih di bawah" : "Hitam di bawah") + ". Membaca ulang kotak…");
    }

    private void toggleSideToMove() {
        tracker.toggleSideToMove();
        lastAnalyzedFen = "";
        lastEvaluation = null;
        overlay.clear();
        overlay.setTurn(tracker.isWhiteToMove());
        overlay.status("Giliran diubah menjadi " + (tracker.isWhiteToMove() ? "Putih" : "Hitam") + ". Menghitung ulang saran…");
    }

    private void toggleMyBest() {
        showMyBest = !showMyBest;
        if (learningPrefs != null) learningPrefs.edit().putBoolean("show_my_best", showMyBest).apply();
        overlay.setLearningOptions(showMyBest, showOpponentBest, playerWhite);
        renderCachedAnalysis();
    }

    private void toggleOpponentBest() {
        showOpponentBest = !showOpponentBest;
        if (learningPrefs != null) learningPrefs.edit().putBoolean("show_opponent_best", showOpponentBest).apply();
        overlay.setLearningOptions(showMyBest, showOpponentBest, playerWhite);
        renderCachedAnalysis();
    }

    private void togglePlayerSide() {
        playerWhite = !playerWhite;
        if (learningPrefs != null) learningPrefs.edit().putBoolean("player_white", playerWhite).apply();
        overlay.setLearningOptions(showMyBest, showOpponentBest, playerWhite);
        renderCachedAnalysis();
    }

    private void resize(int newWidth, int newHeight) {
        if (newWidth < 200 || newHeight < 200 || display == null || (newWidth == width && newHeight == height)) return;
        ImageReader fresh = ImageReader.newInstance(newWidth, newHeight, PixelFormat.RGBA_8888, 2);
        synchronized (captureLock) {
            ImageReader old = reader;
            reader = fresh; width = newWidth; height = newHeight;
            display.resize(newWidth, newHeight, getResources().getDisplayMetrics().densityDpi);
            display.setSurface(fresh.getSurface());
            if (old != null) old.close();
        }
        lastBoard = null; candidateBoard = null; candidateBoardCount = 0; boardMissCount = 0;
        tracker.resetPosition(); lastAnalyzedFen = "";
        overlay.clear(); overlay.status("Ukuran layar berubah. Mencari papan kembali tanpa meminta posisi awal.");
    }

    private void capture() {
        if (!busy.compareAndSet(false, true)) return;
        Bitmap frame = null;
        synchronized (captureLock) {
            if (reader == null) { busy.set(false); return; }
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image != null) {
                    Image.Plane plane = image.getPlanes()[0];
                    ByteBuffer buffer = plane.getBuffer();
                    int rowStride = plane.getRowStride(), pixelStride = plane.getPixelStride();
                    int imageWidth = image.getWidth(), imageHeight = image.getHeight();
                    int paddedWidth = imageWidth + (rowStride - pixelStride * imageWidth) / pixelStride;
                    Bitmap padded = Bitmap.createBitmap(paddedWidth, imageHeight, Bitmap.Config.ARGB_8888);
                    padded.copyPixelsFromBuffer(buffer);
                    frame = Bitmap.createBitmap(padded, 0, 0, imageWidth, imageHeight);
                    padded.recycle();
                }
            } catch (Exception error) {
                long now = System.currentTimeMillis();
                if (overlay != null && now - lastCaptureDiagnosticAt > 2500) {
                    lastCaptureDiagnosticAt = now;
                    overlay.status("Gagal membaca frame: " + error.getClass().getSimpleName() + " — " + error.getMessage());
                }
            } finally { if (image != null) image.close(); }
        }
        if (frame == null) {
            emptyFrameCount++;
            long now = System.currentTimeMillis();
            if (overlay != null && now - lastCaptureDiagnosticAt > 3500) {
                lastCaptureDiagnosticAt = now;
                overlay.status("Belum menerima frame layar (" + emptyFrameCount + "). Hentikan sesi, mulai lagi, lalu setujui screen capture Android.");
            }
            busy.set(false); return;
        }
        emptyFrameCount = 0;
        Bitmap captured = frame;
        worker.submit(() -> {
            try { if (!paused) process(captured); }
            catch (Exception error) { if (overlay != null) overlay.status("Analisis gagal: " + error.getClass().getSimpleName() + " — " + error.getMessage()); }
            finally { captured.recycle(); busy.set(false); }
        });
    }

    private void process(Bitmap frame) throws Exception {
        Rect detected = finder.find(frame);
        if (detected == null) {
            boardMissCount++;
            if (lastBoard != null && boardMissCount <= 2) {
                detected = new Rect(lastBoard); // short grace period for animations/overlays
            } else {
                if (boardMissCount > 3) { lastBoard = null; candidateBoard = null; candidateBoardCount = 0; }
                overlay.status("Frame diterima, tetapi papan belum ditemukan. Skor "
                        + String.format(java.util.Locale.US, "%.1f", finder.getLastScore())
                        + ". Pastikan seluruh papan terlihat dan tidak miring.");
                return;
            }
        } else {
            boardMissCount = 0;
        }

        Rect board = stabiliseBoard(detected);
        if (board == null) return;
        if (classifier == null) {
            overlay.status("Papan terkunci. Memuat model pengenal 13 kelas…");
            classifier = new PieceClassifier(this);
        }

        PieceClassifier.Result result = classifier.classify(frame, board);
        overlay.setOrientation(tracker.isWhiteBottom(), tracker.isManualOrientation());
        overlay.setTurn(tracker.isWhiteToMove());

        if (result.pieceCount < 2 || result.averageConfidence < 0.52f || result.lowConfidenceSquares > 12) {
            overlay.status("Papan terkunci · membaca bidak "
                    + String.format(java.util.Locale.US, "%.0f%%", result.averageConfidence * 100)
                    + " · kotak belum yakin " + result.lowConfidenceSquares + ". Tahan papan tetap diam.");
            return;
        }

        PositionTracker.Update update = tracker.observe(result);
        overlay.setOrientation(tracker.isWhiteBottom(), tracker.isManualOrientation());
        overlay.setTurn(tracker.isWhiteToMove());
        if (update != null) handlePositionUpdate(update, board, result);

        String fen = tracker.getFen();
        if (!fen.isEmpty() && !fen.equals(lastAnalyzedFen)) {
            // If a prior engine start failed, retry on the next stable frame.
            if (update == null) analyzeCurrentPosition(fen, board, result, "Posisi stabil");
        }
    }

    /** Keeps the board lock through small movements and requires two frames for a large relocation. */
    private Rect stabiliseBoard(Rect found) {
        if (lastBoard == null || forceRelock) {
            lastBoard = new Rect(found);
            candidateBoard = null; candidateBoardCount = 0; forceRelock = false;
            overlay.status("Papan ditemukan dan dikunci. Membaca 64 kotak…");
            return new Rect(lastBoard);
        }
        int tolerance = Math.max(10, lastBoard.width() / 14);
        boolean near = Math.abs(found.left - lastBoard.left) <= tolerance
                && Math.abs(found.top - lastBoard.top) <= tolerance
                && Math.abs(found.width() - lastBoard.width()) <= tolerance
                && Math.abs(found.height() - lastBoard.height()) <= tolerance;
        if (near) {
            lastBoard = blend(lastBoard, found, 0.28f);
            candidateBoard = null; candidateBoardCount = 0;
            return new Rect(lastBoard);
        }
        if (candidateBoard != null && close(candidateBoard, found, tolerance)) candidateBoardCount++;
        else { candidateBoard = new Rect(found); candidateBoardCount = 1; }
        if (candidateBoardCount < 2) {
            overlay.status("Papan bergeser. Mengikuti posisi baru…");
            return null;
        }
        lastBoard = new Rect(found);
        candidateBoard = null; candidateBoardCount = 0;
        overlay.status("Posisi papan diperbarui. Kalibrasi tidak perlu diulang.");
        return new Rect(lastBoard);
    }

    private static boolean close(Rect a, Rect b, int tolerance) {
        return Math.abs(a.left - b.left) <= tolerance && Math.abs(a.top - b.top) <= tolerance
                && Math.abs(a.width() - b.width()) <= tolerance && Math.abs(a.height() - b.height()) <= tolerance;
    }

    private static Rect blend(Rect oldRect, Rect newRect, float weight) {
        return new Rect(Math.round(oldRect.left * (1f - weight) + newRect.left * weight),
                Math.round(oldRect.top * (1f - weight) + newRect.top * weight),
                Math.round(oldRect.right * (1f - weight) + newRect.right * weight),
                Math.round(oldRect.bottom * (1f - weight) + newRect.bottom * weight));
    }

    private void handlePositionUpdate(PositionTracker.Update update, Rect board, PieceClassifier.Result recognition) {
        overlay.setTurn(tracker.isWhiteToMove());
        String turn = tracker.isWhiteToMove() ? "Putih" : "Hitam";
        if (update.move == null) {
            String prefix = update.initialPosition ? "Posisi papan berhasil dibaca" : "Posisi papan disinkronkan ulang";
            String suffix = update.resynchronised ? "\nGiliran mungkin perlu dikoreksi lewat tombol Giliran." : "\nGiliran awal diasumsikan Putih; koreksi jika perlu.";
            if (!tracker.isOrientationKnown()) suffix += "\nOrientasi belum pasti; gunakan tombol Putih↓/Hitam↓.";
            lastPlayedFrom = ""; lastPlayedTo = ""; lastMoveSymbol = "";
            analyzeCurrentPosition(update.fen, board, recognition, prefix + " · " + recognition.pieceCount + " bidak\nGiliran: " + turn + suffix);
            return;
        }

        String uci = update.move.toString();
        overlay.annotate(board, uci.substring(0, 2), uci.substring(2, 4), "…", "", "", tracker.isWhiteBottom());
        overlay.status("Langkah " + uci + " terdeteksi stabil. Stockfish sedang menilai…");
        try {
            ensureEngine();
            UciEngine.Evaluation before = engine.analyze(update.before.getFen(), thinkMs);
            UciEngine.Evaluation after = engine.analyze(update.after.getFen(), thinkMs);
            MoveJudge.Result grade = MoveJudge.judge(update.before, update.after, update.move, before, after);
            lastAnalyzedFen = update.after.getFen();
            lastEvaluation = after;
            lastAnalyzedBoard = new Rect(board);
            lastAnalysisPrefix = grade.symbol + " " + grade.name + " · " + uci + "\n" + grade.note
                    + "\nCPL " + grade.centipawnsLost + " · Evaluasi " + after.description;
            lastPlayedFrom = uci.substring(0, 2);
            lastPlayedTo = uci.substring(2, 4);
            lastMoveSymbol = grade.symbol;
            renderCachedAnalysis();
        } catch (Exception error) {
            lastAnalyzedFen = "";
            lastEvaluation = null;
            overlay.status("Posisi terbaca, tetapi Stockfish belum siap: " + error.getMessage());
        }
    }

    private void analyzeCurrentPosition(String fen, Rect board, PieceClassifier.Result recognition, String prefix) {
        try {
            ensureEngine();
            overlay.status(prefix + "\nStockfish sedang menganalisis posisi dan prediksi balasan…");
            UciEngine.Evaluation evaluation = engine.analyze(fen, thinkMs);
            lastAnalyzedFen = fen;
            lastEvaluation = evaluation;
            lastAnalyzedBoard = new Rect(board);
            lastAnalysisPrefix = prefix + "\nEvaluasi " + evaluation.description
                    + " · Akurasi pengenalan " + String.format(java.util.Locale.US, "%.0f%%", recognition.averageConfidence * 100);
            lastPlayedFrom = ""; lastPlayedTo = ""; lastMoveSymbol = "";
            renderCachedAnalysis();
        } catch (Exception error) {
            lastAnalyzedFen = "";
            lastEvaluation = null;
            overlay.status(prefix + "\nStockfish belum siap: " + error.getMessage());
        }
    }

    /** Selects the user's move and the opponent's predicted reply from the same PV. */
    private void renderCachedAnalysis() {
        UciEngine.Evaluation evaluation = lastEvaluation;
        Rect board = lastAnalyzedBoard;
        if (evaluation == null || board == null || overlay == null) return;

        boolean whiteToMove = tracker.isWhiteToMove();
        boolean userToMove = whiteToMove == playerWhite;
        int myPly = userToMove ? 0 : 1;
        int opponentPly = userToMove ? 1 : 0;
        String myMove = showMyBest ? evaluation.moveAt(myPly) : "";
        String opponentMove = showOpponentBest ? evaluation.moveAt(opponentPly) : "";
        overlay.annotate(board, lastPlayedFrom, lastPlayedTo, lastMoveSymbol,
                myMove, opponentMove, tracker.isWhiteBottom());

        StringBuilder status = new StringBuilder(lastAnalysisPrefix);
        status.append("\nGiliran: ").append(whiteToMove ? "Putih" : "Hitam")
                .append(" · Kamu: ").append(playerWhite ? "Putih" : "Hitam");
        if (showMyBest) status.append("\n").append(userToMove ? "Langkah terbaikmu: " : "Prediksi balasanmu: ")
                .append(myMove.isEmpty() ? "belum tersedia di PV" : myMove);
        if (showOpponentBest) status.append("\n").append(userToMove ? "Prediksi langkah lawan: " : "Langkah terbaik lawan: ")
                .append(opponentMove.isEmpty() ? "belum tersedia di PV" : opponentMove);
        status.append("\nHijau = kamu · Oranye putus-putus = prediksi lawan");
        overlay.status(status.toString());
    }

    private void ensureEngine() throws Exception {
        if (engine == null) engine = new UciEngine();
    }

    @Override public void onDestroy() {
        main.removeCallbacks(ticker);
        synchronized (captureLock) {
            if (display != null) { display.release(); display = null; }
            if (reader != null) { reader.close(); reader = null; }
        }
        if (projection != null) { MediaProjection closing = projection; projection = null; closing.stop(); }
        worker.shutdownNow();
        lastEvaluation = null;
        lastAnalyzedBoard = null;
        if (engine != null) { engine.close(); engine = null; }
        if (classifier != null) { classifier.close(); classifier = null; }
        if (overlay != null) { overlay.dispose(); overlay = null; }
        super.onDestroy();
    }
}
