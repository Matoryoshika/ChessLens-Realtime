package id.chesslens.realtime.engine;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads Stockfish 18 as WebAssembly data. No native executable is run from app data. */
public final class EngineInstaller {
    public static final String VERSION = "18-wasm-full-single";
    private static final String PREFS = "chesslens_engine";
    private static final String PREF_READY = "stockfish_ready";
    private static final String PREF_VERSION = "stockfish_version";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int BUFFER_SIZE = 64 * 1024;

    // Pinned Stockfish.js 18.0.5 full-strength, single-threaded WebAssembly build.
    // It keeps the full NNUE network; the large WASM file is downloaded after installation.
    private static final String JS_URL = "https://cdn.jsdelivr.net/npm/stockfish@18.0.5/bin/stockfish-18-single.js";
    private static final String WASM_URL = "https://cdn.jsdelivr.net/npm/stockfish@18.0.5/bin/stockfish-18-single.wasm";
    // Filled by the GitHub Actions build after downloading the pinned npm package assets.
    private static final String JS_SHA256 = "__STOCKFISH_JS_SHA256__";
    private static final String WASM_SHA256 = "__STOCKFISH_WASM_SHA256__";

    private static volatile DownloadTask activeTask;
    private EngineInstaller() {}

    public interface Listener {
        void onProgress(long downloadedBytes, long totalBytes, String phase);
        void onComplete(File engineDirectory);
        void onError(String message);
        void onCancelled();
    }

    public static File engineDirectory(Context context) {
        return new File(context.getFilesDir(), "engine");
    }
    public static File engineJsFile(Context context) {
        return new File(engineDirectory(context), "stockfish-18-single.js");
    }
    /** The worker loader expects this exact sibling filename. */
    public static File engineWasmFile(Context context) {
        return new File(engineDirectory(context), "stockfish.wasm");
    }
    /** Kept for older call sites; WASM is not an executable filesystem path. */
    @Deprecated public static String enginePath(Context context) {
        return engineJsFile(context).getAbsolutePath();
    }

    public static boolean isInstalled(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        File js = engineJsFile(context), wasm = engineWasmFile(context);
        return prefs.getBoolean(PREF_READY, false)
                && VERSION.equals(prefs.getString(PREF_VERSION, ""))
                && js.isFile() && js.length() > 10_000L
                && wasm.isFile() && wasm.length() > 100_000_000L;
    }

    public static synchronized boolean isDownloading() { return activeTask != null; }

    public static synchronized void cancelDownload() {
        DownloadTask task = activeTask;
        if (task != null) task.cancel();
    }

    public static synchronized void download(Context context, Listener listener) {
        if (activeTask != null) return;
        DownloadTask task = new DownloadTask(context.getApplicationContext(), listener);
        activeTask = task;
        EXECUTOR.execute(task);
    }

    public static void forgetInstalled(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(PREF_READY, false).apply();
        engineJsFile(context).delete();
        engineWasmFile(context).delete();
    }

    private static final class Cancelled extends IOException {
        Cancelled() { super("Unduhan dibatalkan oleh pengguna."); }
    }

    private static final class DownloadTask implements Runnable {
        private final Context app;
        private final Listener listener;
        private volatile boolean cancelled;
        private volatile HttpURLConnection connection;
        private volatile InputStream input;

        DownloadTask(Context app, Listener listener) { this.app = app; this.listener = listener; }

        void cancel() {
            cancelled = true;
            InputStream currentInput = input;
            if (currentInput != null) try { currentInput.close(); } catch (IOException ignored) {}
            HttpURLConnection currentConnection = connection;
            if (currentConnection != null) currentConnection.disconnect();
        }

        private void checkCancelled() throws Cancelled {
            if (cancelled || Thread.currentThread().isInterrupted()) throw new Cancelled();
        }

        @Override public void run() {
            File directory = engineDirectory(app);
            try {
                if (!directory.exists() && !directory.mkdirs()) throw new IOException("Tidak dapat membuat folder engine internal.");
                downloadOne(JS_URL, new File(directory, "stockfish-18-single.js"), false, JS_SHA256, "Memasang loader Stockfish 18…");
                checkCancelled();
                downloadOne(WASM_URL, new File(directory, "stockfish.wasm"), true, WASM_SHA256, "Mengunduh Stockfish 18 Full (sekitar 113 MB)…");
                checkCancelled();
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putBoolean(PREF_READY, true).putString(PREF_VERSION, VERSION).apply();
                post(() -> listener.onComplete(directory));
            } catch (Cancelled ignored) {
                deletePartials(directory);
                post(listener::onCancelled);
            } catch (Exception error) {
                deletePartials(directory);
                if (cancelled) {
                    post(listener::onCancelled);
                } else {
                    String message = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
                    post(() -> listener.onError(message));
                }
            } finally {
                HttpURLConnection current = connection;
                if (current != null) current.disconnect();
                synchronized (EngineInstaller.class) {
                    if (activeTask == this) activeTask = null;
                }
            }
        }

        private void downloadOne(String urlText, File destination, boolean wasm, String expectedHash, String phase) throws Exception {
            checkCancelled();
            if (expectedHash.startsWith("__")) throw new IOException("Checksum engine belum dipasang pada build aplikasi.");
            if (destination.isFile() && isValidAsset(destination, wasm)
                    && expectedHash.equalsIgnoreCase(sha256(destination))) {
                postProgress(destination.length(), destination.length(), phase + " ✓");
                return;
            }
            if (destination.exists() && !destination.delete()) throw new IOException("Tidak dapat menghapus file engine lama.");
            File partial = new File(destination.getParentFile(), destination.getName() + ".part");
            if (partial.exists() && !partial.delete()) throw new IOException("Tidak dapat membersihkan file unduhan sementara.");

            HttpURLConnection conn = (HttpURLConnection) new URL(urlText).openConnection();
            connection = conn;
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(25_000);
            conn.setReadTimeout(45_000);
            conn.setRequestProperty("User-Agent", "ChessLens-Realtime/0.7 Android");
            conn.setRequestProperty("Accept", "application/octet-stream");
            conn.connect();
            checkCancelled();
            int response = conn.getResponseCode();
            if (response < 200 || response >= 300) throw new IOException("Server engine merespons HTTP " + response + ".");
            long total = conn.getContentLengthLong();
            long downloaded = 0;
            postProgress(0, total, phase);
            try (InputStream source = new BufferedInputStream(conn.getInputStream(), BUFFER_SIZE)) {
                input = source;
                try (OutputStream target = new BufferedOutputStream(new FileOutputStream(partial), BUFFER_SIZE)) {
                    byte[] buffer = new byte[BUFFER_SIZE];
                    long lastReport = 0;
                    for (int n; (n = source.read(buffer)) != -1;) {
                        checkCancelled();
                        target.write(buffer, 0, n);
                        downloaded += n;
                        if (downloaded - lastReport >= 256 * 1024L) {
                            lastReport = downloaded;
                            postProgress(downloaded, total, phase);
                        }
                    }
                    target.flush();
                }
            } finally {
                input = null;
                conn.disconnect();
                connection = null;
            }
            checkCancelled();
            if (total > 0 && downloaded != total) {
                partial.delete();
                throw new IOException("Unduhan tidak lengkap (" + downloaded + " dari " + total + " byte).");
            }
            if (!partial.isFile() || !isValidAsset(partial, wasm)) {
                partial.delete();
                throw new IOException(wasm
                        ? "File Stockfish WASM tidak lengkap atau header WebAssembly tidak valid."
                        : "Loader Stockfish tidak valid atau unduhan terpotong.");
            }
            String actualHash = sha256(partial);
            if (!expectedHash.equalsIgnoreCase(actualHash)) {
                partial.delete();
                throw new IOException("Verifikasi SHA-256 gagal untuk " + destination.getName() + ". File sementara dihapus.");
            }
            checkCancelled();
            if (!partial.renameTo(destination)) {
                copyFile(partial, destination);
                partial.delete();
            }
            postProgress(downloaded, total > 0 ? total : downloaded, phase + " ✓");
        }

        private void postProgress(long downloaded, long total, String phase) {
            post(() -> listener.onProgress(downloaded, total, phase));
        }
        private void post(Runnable action) { MAIN.post(action); }
        private void deletePartials(File directory) {
            if (directory == null || !directory.exists()) return;
            File[] files = directory.listFiles((dir, name) -> name.endsWith(".part"));
            if (files != null) for (File file : files) file.delete();
        }
    }


    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            for (int n; (n = input.read(buffer)) >= 0;) if (n > 0) digest.update(buffer, 0, n);
        }
        StringBuilder result = new StringBuilder();
        for (byte value : digest.digest()) result.append(String.format(Locale.US, "%02x", value & 0xff));
        return result.toString();
    }

    private static boolean isValidAsset(File file, boolean wasm) throws IOException {
        if (!file.isFile()) return false;
        if (!wasm) {
            if (file.length() < 10_000L) return false;
            try (InputStream in = new FileInputStream(file)) {
                byte[] header = new byte[128];
                int n = in.read(header);
                if (n <= 0) return false;
                String text = new String(header, 0, n, java.nio.charset.StandardCharsets.UTF_8);
                return text.contains("Stockfish") || text.contains("stockfish");
            }
        }
        if (file.length() < 100_000_000L) return false;
        try (InputStream in = new FileInputStream(file)) {
            return in.read() == 0x00 && in.read() == 0x61 && in.read() == 0x73 && in.read() == 0x6d;
        }
    }

    private static void copyFile(File source, File destination) throws IOException {
        try (InputStream input = new FileInputStream(source); OutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            for (int n; (n = input.read(buffer)) >= 0;) if (n > 0) output.write(buffer, 0, n);
            output.flush();
        }
    }
}
