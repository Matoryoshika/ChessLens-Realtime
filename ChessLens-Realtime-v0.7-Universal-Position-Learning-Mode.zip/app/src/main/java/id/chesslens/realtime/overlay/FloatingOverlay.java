package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Native overlay with touch-through arrows and compact analysis controls. */
public final class FloatingOverlay {
    private final WindowManager windowManager;
    private final ArrowCanvas arrows;
    private final LinearLayout panel;
    private final TextView status;
    private final Button pauseButton;
    private final Button orientationButton;
    private final Button turnButton;
    private final Button myBestButton;
    private final Button opponentBestButton;
    private final Button playerSideButton;
    private final WindowManager.LayoutParams params;
    private float touchX, touchY;
    private int beginX, beginY;

    public FloatingOverlay(Context context, Runnable relockBoard, Runnable togglePause,
                           Runnable flipOrientation, Runnable toggleTurn, Runnable toggleMyBest,
                           Runnable toggleOpponentBest, Runnable togglePlayerSide, Runnable stop) {
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        arrows = new ArrowCanvas(context);
        WindowManager.LayoutParams canvasParams = new WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        canvasParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowManager.addView(arrows, canvasParams);

        panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(18, 13, 18, 11);
        GradientDrawable backdrop = new GradientDrawable();
        backdrop.setColor(0xee111a2c);
        backdrop.setCornerRadius(24);
        panel.setBackground(backdrop);

        status = new TextView(context);
        status.setText("♟ ChessLens: mencari papan…");
        status.setTextSize(13);
        status.setTextColor(Color.WHITE);
        status.setMaxLines(9);
        status.setMinWidth(dp(context, 235));
        panel.addView(status);

        TextView hint = new TextView(context);
        hint.setText("Hijau = langkahmu · Oranye putus = prediksi lawan");
        hint.setTextSize(10);
        hint.setTextColor(0xffb7c5d9);
        panel.addView(hint);

        LinearLayout firstRow = row(context);
        Button relock = button(context, "Kunci papan", relockBoard);
        firstRow.addView(relock);
        orientationButton = button(context, "Putih ↓", flipOrientation);
        firstRow.addView(orientationButton);
        turnButton = button(context, "Giliran: Putih", toggleTurn);
        firstRow.addView(turnButton);
        panel.addView(firstRow);

        LinearLayout secondRow = row(context);
        pauseButton = button(context, "Jeda", togglePause);
        secondRow.addView(pauseButton);
        Button close = button(context, "Stop", stop);
        secondRow.addView(close);
        panel.addView(secondRow);

        LinearLayout learningRow = row(context);
        myBestButton = button(context, "Saya ON", toggleMyBest);
        opponentBestButton = button(context, "Lawan ON", toggleOpponentBest);
        playerSideButton = button(context, "Saya: Putih", togglePlayerSide);
        learningRow.addView(myBestButton);
        learningRow.addView(opponentBestButton);
        learningRow.addView(playerSideButton);
        panel.addView(learningRow);

        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 14;
        params.y = 90;
        windowManager.addView(panel, params);

        status.setOnTouchListener((View view, MotionEvent event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                touchX = event.getRawX(); touchY = event.getRawY();
                beginX = params.x; beginY = params.y;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = beginX + (int) (event.getRawX() - touchX);
                params.y = beginY + (int) (event.getRawY() - touchY);
                windowManager.updateViewLayout(panel, params);
                return true;
            }
            return true;
        });
    }

    private static LinearLayout row(Context context) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private static Button button(Context context, String label, Runnable action) {
        Button button = new Button(context);
        button.setText(label);
        button.setTextSize(10);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(context, 6), 0, dp(context, 6), 0);
        button.setOnClickListener(view -> action.run());
        return button;
    }

    private static int dp(Context context, int value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public void status(String message) { status.post(() -> status.setText(message)); }
    public void setPaused(boolean paused) { pauseButton.post(() -> pauseButton.setText(paused ? "Lanjut" : "Jeda")); }
    public void setOrientation(boolean whiteBottom, boolean manual) {
        String label = whiteBottom ? "Putih ↓" : "Hitam ↓";
        orientationButton.post(() -> orientationButton.setText(label + (manual ? " *" : "")));
    }
    public void setTurn(boolean whiteToMove) {
        turnButton.post(() -> turnButton.setText("Giliran: " + (whiteToMove ? "Putih" : "Hitam")));
    }
    public void setLearningOptions(boolean myBest, boolean opponentBest, boolean playerWhite) {
        myBestButton.post(() -> myBestButton.setText("Saya " + (myBest ? "ON" : "OFF")));
        opponentBestButton.post(() -> opponentBestButton.setText("Lawan " + (opponentBest ? "ON" : "OFF")));
        playerSideButton.post(() -> playerSideButton.setText("Saya: " + (playerWhite ? "Putih" : "Hitam")));
    }
    public void annotate(Rect rect, String from, String to, String symbol, String myBestMove,
                         String opponentBestMove, boolean whiteBottom) {
        arrows.post(() -> arrows.update(rect, from, to, symbol, myBestMove, opponentBestMove, whiteBottom));
    }
    public void annotate(Rect rect, String from, String to, String symbol, String bestMove, boolean whiteBottom) {
        annotate(rect, from, to, symbol, bestMove, "", whiteBottom);
    }
    public void clear() { arrows.post(() -> arrows.update(null, "", "", "", "", "", true)); }
    public void dispose() {
        try { windowManager.removeView(arrows); } catch (Exception ignored) { }
        try { windowManager.removeView(panel); } catch (Exception ignored) { }
    }
}
