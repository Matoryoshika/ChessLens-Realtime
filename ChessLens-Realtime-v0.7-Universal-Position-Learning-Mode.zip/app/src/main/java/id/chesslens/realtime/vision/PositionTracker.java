package id.chesslens.realtime.vision;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Side;
import com.github.bhlangonijr.chesslib.move.Move;

/**
 * Tracks arbitrary recognised positions. It no longer learns templates from the
 * standard starting position: every stable 64-square classification becomes a FEN.
 */
public final class PositionTracker {
    private boolean whiteBottom = true;
    private boolean manualOrientation = false;
    private boolean orientationLocked = false;
    private boolean whiteToMove = true;
    private String currentPlacement = "";
    private String pendingPlacement = "";
    private int stableFrames = 0;
    private Board currentBoard;

    public static final class Update {
        public final Board before;
        public final Board after;
        public final Move move;
        public final boolean initialPosition;
        public final boolean resynchronised;
        public final String fen;
        Update(Board before, Board after, Move move, boolean initial, boolean resync) {
            this.before = before; this.after = after; this.move = move;
            this.initialPosition = initial; this.resynchronised = resync;
            this.fen = after.getFen();
        }
    }

    public boolean isReady() { return currentBoard != null; }
    public boolean isWhiteBottom() { return whiteBottom; }
    public boolean isManualOrientation() { return manualOrientation; }
    public boolean isOrientationKnown() { return orientationLocked; }
    public boolean isWhiteToMove() { return whiteToMove; }
    public String getFen() { return currentBoard == null ? "" : currentBoard.getFen(); }
    public Board getBoardCopy() { return currentBoard == null ? null : copy(currentBoard); }

    public void setWhiteBottom(boolean value, boolean manual) {
        whiteBottom = value;
        if (manual) { manualOrientation = true; orientationLocked = true; }
        pendingPlacement = "";
        stableFrames = 0;
    }

    public void useAutomaticOrientation() { manualOrientation = false; orientationLocked = false; }

    public void toggleOrientation() {
        whiteBottom = !whiteBottom;
        manualOrientation = true;
        orientationLocked = true;
        pendingPlacement = "";
        stableFrames = 0;
    }

    /** Toggle the side to move when a new mid-game scan has no move history. */
    public void toggleSideToMove() {
        whiteToMove = !whiteToMove;
        pendingPlacement = "";
        stableFrames = 0;
        if (currentBoard != null) currentBoard = boardFromPlacement(currentPlacement, whiteToMove);
    }

    public void resetPosition() {
        currentPlacement = "";
        pendingPlacement = "";
        stableFrames = 0;
        currentBoard = null;
    }

    /**
     * Applies a stable model result. Two consecutive identical classifications
     * are required so piece-drag animations do not become false positions.
     */
    public Update observe(PieceClassifier.Result result) {
        if (result == null || result.pieceCount < 2 || result.averageConfidence < 0.52f
                || result.lowConfidenceSquares > 12) return null;
        if (!manualOrientation && !orientationLocked && result.orientationReliable) {
            whiteBottom = result.suggestedWhiteBottom;
            orientationLocked = true;
        }
        String placement = result.toFenPlacement(whiteBottom);
        if (!isSanePlacement(placement)) return null;

        if (!placement.equals(pendingPlacement)) {
            pendingPlacement = placement;
            stableFrames = 1;
            return null;
        }
        stableFrames++;
        if (stableFrames < 2 || placement.equals(currentPlacement)) return null;

        if (currentBoard == null) {
            currentPlacement = placement;
            currentBoard = boardFromPlacement(placement, whiteToMove);
            pendingPlacement = placement;
            return new Update(null, copy(currentBoard), null, true, false);
        }

        Board before = copy(currentBoard);
        Move matched = findMatchingLegalMove(before, placement);
        if (matched != null) {
            Board after = copy(before);
            if (!after.doMove(matched)) return null;
            currentBoard = after;
            currentPlacement = placement;
            whiteToMove = after.getSideToMove() == Side.WHITE;
            pendingPlacement = placement;
            return new Update(before, copy(after), matched, false, false);
        }

        // A new game, a missed frame, or a correction may change more than one
        // legal ply. Resynchronise to the visible position and flag turn ambiguity.
        whiteToMove = !whiteToMove;
        currentPlacement = placement;
        currentBoard = boardFromPlacement(placement, whiteToMove);
        pendingPlacement = placement;
        return new Update(before, copy(currentBoard), null, false, true);
    }

    private static Move findMatchingLegalMove(Board before, String targetPlacement) {
        for (Move move : before.legalMoves()) {
            Board candidate = copy(before);
            if (candidate.doMove(move) && placementOf(candidate).equals(targetPlacement)) return move;
        }
        return null;
    }

    private static Board boardFromPlacement(String placement, boolean whiteToMove) {
        Board board = new Board();
        board.loadFromFen(placement + (whiteToMove ? " w " : " b ") + "- - 0 1");
        return board;
    }

    private static String placementOf(Board board) {
        return board.getFen().split(" ")[0];
    }

    private static Board copy(Board source) {
        Board result = new Board();
        result.loadFromFen(source.getFen());
        return result;
    }

    private static boolean isSanePlacement(String placement) {
        int whiteKings = 0, blackKings = 0, pieces = 0;
        for (int i = 0; i < placement.length(); i++) {
            char p = placement.charAt(i);
            if (p == 'K') whiteKings++;
            else if (p == 'k') blackKings++;
            else if (p >= 'A' && p <= 'Z' || p >= 'a' && p <= 'z') pieces++;
        }
        return whiteKings == 1 && blackKings == 1 && pieces + whiteKings + blackKings <= 32;
    }
}
