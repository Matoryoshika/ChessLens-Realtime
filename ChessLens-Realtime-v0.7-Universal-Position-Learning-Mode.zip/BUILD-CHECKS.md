# ChessLens Realtime v0.7 — Build and QA checklist

## Checks completed while preparing the source archive
- [x] Python conversion script passes `py_compile`.
- [x] CNN architecture shape smoke test returns `[64, 13]` with 156,461 parameters.
- [x] FEN orientation mapping test passes for normal, flipped, and non-starting layouts.
- [x] Old standard-start-position-only template gate is removed from the new `PositionTracker`.
- [x] Stockfish remains an on-demand download in the workflow definition.

## CI checks — pending the user's GitHub upload/build
- [ ] Download the upstream Chess CV safetensors weights.
- [ ] Convert weights to ONNX and verify PyTorch/ONNX parity.
- [ ] Build the Android APK with ONNX Runtime.
- [ ] Verify APK signature and the packaged model asset.
- [ ] Confirm Stockfish JS/WASM is not bundled in the installer APK.

## Must test on the target phone
- [ ] Start capture with a standard starting position.
- [ ] Start capture after the game has already reached a middlegame.
- [ ] Start from an endgame with only a few pieces.
- [ ] Flip the board and confirm square-to-FEN mapping remains correct.
- [ ] Toggle side to move and confirm the best-move arrow changes accordingly.
- [ ] Make one legal move and confirm the played-move arrow, evaluation, and best reply appear.
- [ ] Move/resize the board slightly and confirm the board lock follows without repeating calibration.
- [ ] Test at least one Chess.com theme and one Lichess-like theme.
- [ ] Confirm Stockfish worker initialises from the hidden WebView while the capture service is active.

## Important
A successful APK build does not prove the classifier generalises to every board theme. Verify the generated FEN against the visible board before trusting engine recommendations.

## Learning Mode checks added
- [x] UCI parser retains the deepest Stockfish principal variation, not only `bestmove`.
- [x] Java smoke test validates the final bestmove, second PV reply, deeper PV continuation, and score parsing against simulated UCI output.
- [x] First and second PV plies are mapped to user/opponent based on the selected player side and current side to move.
- [x] Floating HUD exposes independent My Best / Opponent Best toggles and a player-side selector.
- [x] Own and opponent arrows use distinct colors and styles.
- [x] Toggle changes re-render the cached PV without launching duplicate engine searches.
- [x] CI runs `tools/test_learning_pv.py` for all four combinations of player color and side to move.
- [ ] Verify both arrows and all four player-side/turn combinations on the target phone.
