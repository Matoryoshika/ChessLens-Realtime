# ChessLens Realtime v0.7

ChessLens Realtime v0.7 adds arbitrary-position board reading and first-position Stockfish analysis.

## What changes from v0.6

The old `PositionTracker` learned piece templates only from the standard starting position and could only follow legal next moves. v0.7 replaces that approach with a 13-class classifier that predicts each of the 64 squares independently, then creates a FEN from the visible board. The tracker waits for two matching frames, detects a legal one-ply transition when possible, and resynchronises if frames were skipped.

The piece classifier compares normal and 180-degree-rotated square crops on first use, then caches the better-scoring transform so piece artwork remains recognisable when a board is flipped. The Floating HUD now includes:
- **Kunci papan** — reacquire the board rectangle without clearing the recognised position.
- **Putih ↓ / Hitam ↓** — manually flip the board mapping.
- **Giliran: Putih / Hitam** — set the side to move when the session starts mid-game.
- **Jeda / Stop** — pause or end capture.

Stockfish is asked to analyse the first stable position, not only after a move from the standard starting setup. The dashed cyan arrow shows the engine's best move.

## Build

Use `.github/workflows/build-android-v0.7.yml`. The workflow:
1. Downloads the MIT-licensed `pieces.safetensors` model from the Chess CV Hugging Face repository.
2. Converts MLX weights to ONNX using the included PyTorch conversion script.
3. Runs an ONNX Runtime smoke test and checks parity with PyTorch.
4. Packages the ONNX model in the app and builds the Android APK.
5. Downloads Stockfish 18 WASM as a separate first-run in-app download, not in the APK.

The ONNX model is bundled in the APK; Stockfish remains on-demand. The ONNX Runtime Android library increases APK size compared with v0.6.

## Recognition limits

The model classifies 32x32 RGB crops from each board square and was trained on synthetic 2D digital-board images. It is aimed at supported digital board themes, not guaranteed for every custom theme or physical board photo. The model source reports external ChessVision dataset macro-F1 of 92.28%; that is a source-reported result, not a guarantee on this phone or the user's board theme.

When a session starts mid-game, the app can infer piece placement but cannot recover move history. Side to move is selectable in the HUD. Castling and en-passant rights default to none because those rights cannot be deduced from a single image. Verify the FEN and turn before relying on engine output.

See `THIRD_PARTY_NOTICES.md` for the model and runtime licenses.


## Learning Mode — My Move & Opponent Prediction

The Floating HUD includes three controls:

- `Saya ON/OFF`: show or hide the best move for the side selected as the user's side.
- `Lawan ON/OFF`: show or hide the opponent's best move/predicted reply.
- `Saya: Putih/Hitam`: select which color the user is playing.

The app reads the first two plies of Stockfish's principal variation (PV). When it is the user's turn, PV ply 1 is the user's candidate and PV ply 2 is the predicted opponent reply. When it is the opponent's turn, the first PV move is the opponent's candidate and the second is the user's predicted reply. The own arrow is green with an `S` marker; the opponent arrow is dashed orange with an `L` marker. Both controls are independent and persist across sessions. A prediction is conditional on the PV line and does not guarantee what the opponent will actually play.
