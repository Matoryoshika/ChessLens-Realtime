package id.chesslens.realtime.vision;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.move.Move;

import org.junit.Test;

import static org.junit.Assert.*;

public class PositionTrackerTest {
    @Test public void standardStartingPositionKnowsWhiteMovesFirst() {
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result start = resultFor(new Board());

        assertNull(tracker.observe(start));
        PositionTracker.Update update = tracker.observe(start);

        assertNotNull(update);
        assertTrue(update.initialPosition);
        assertTrue(tracker.isOrientationKnown());
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
    }

    @Test public void middlegameStartDoesNotGuessTurnAndInfersItFromNextLegalMove() {
        Board board = new Board();
        assertTrue(board.doMove(findMove(board, "e2e4")));
        assertTrue(board.doMove(findMove(board, "e7e5")));
        assertTrue(board.doMove(findMove(board, "g1f3")));
        // This is a mid-game position with Black to move, but the tracker has no history.
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result initial = resultFor(board);

        assertNull(tracker.observe(initial));
        PositionTracker.Update first = tracker.observe(initial);
        assertNotNull(first);
        assertTrue(first.initialPosition);
        assertFalse(tracker.isTurnKnown());

        assertTrue(board.doMove(findMove(board, "b8c6")));
        PieceClassifier.Result afterBlackMove = resultFor(board);
        assertNull(tracker.observe(afterBlackMove));
        PositionTracker.Update move = tracker.observe(afterBlackMove);

        assertNotNull(move);
        assertNotNull(move.move);
        assertEquals("b8c6", move.move.toString());
        assertTrue(move.turnInferred);
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
    }


    @Test public void kingRowsCanDetermineOrientationWhenClassifierHeuristicIsUncertain() {
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result start = resultFor(new Board());
        PieceClassifier.Result uncertain = new PieceClassifier.Result(start.screenPieces,
                start.confidenceBySquare, start.averageConfidence, start.minimumConfidence,
                start.lowConfidenceSquares, start.pieceCount, false, false, 0.0f,
                start.whiteSamples, start.blackSamples, start.rotated180, 1, 1);
        assertNull(tracker.observe(uncertain));
        PositionTracker.Update update = tracker.observe(uncertain);
        assertNotNull(update);
        assertTrue(tracker.isOrientationKnown());
        assertTrue(tracker.isWhiteBottom());
        assertTrue(tracker.isTurnKnown());
    }

    @Test public void incompleteStartingOccupancyMustNotInventMissingPawns() {
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result start = resultFor(new Board());
        char[] noisy = start.screenPieces.clone();
        noisy[8] = '.';
        noisy[55] = '.';
        PieceClassifier.Result partial = new PieceClassifier.Result(noisy,
                start.confidenceBySquare, 0.44f, 0.30f, 18,
                30, true, false, 0.0f, 15, 15, false, 1, 1);
        assertNull(tracker.observe(partial));
        PositionTracker.Update update = tracker.observe(partial);
        assertNotNull(update);
        assertFalse(tracker.isTurnKnown());
        assertNotEquals(new Board().getFen().split(" ")[0], update.fen.split(" ")[0]);
    }

    @Test public void afterFirstE4MustNotBeRecognisedAsInitialPosition() {
        Board board = new Board();
        assertTrue(board.doMove(findMove(board, "e2e4")));
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result afterMove = resultFor(board);
        assertNull(tracker.observe(afterMove));
        PositionTracker.Update update = tracker.observe(afterMove);
        assertNotNull(update);
        assertTrue("Opening is exactly one legal ply after start", tracker.isTurnKnown());
        assertFalse("Black should move after 1.e4", tracker.isWhiteToMove());
        assertEquals(1, update.recoveredPlies);
        assertEquals(board.getFen().split(" ")[0], update.fen.split(" ")[0]);
    }

    @Test public void differentMoveThanEngineSuggestionStillContinuesTracking() {
        PositionTracker tracker = new PositionTracker();
        Board board = new Board();
        PieceClassifier.Result starting = resultFor(board);
        tracker.observe(starting);
        tracker.observe(starting);
        assertTrue(tracker.isTurnKnown());
        // Stockfish could suggest e2e4, but the player chooses d2d4.
        assertTrue(board.doMove(findMove(board, "d2d4")));
        PieceClassifier.Result alternate = resultFor(board);
        assertNull(tracker.observe(alternate));
        PositionTracker.Update first = tracker.observe(alternate);
        assertNotNull(first);
        assertNotNull(first.move);
        assertEquals("d2d4", first.move.toString());
        assertTrue(tracker.isTurnKnown());
        assertFalse(tracker.isWhiteToMove());

        assertTrue(board.doMove(findMove(board, "d7d5")));
        PieceClassifier.Result black = resultFor(board);
        tracker.observe(black);
        PositionTracker.Update second = tracker.observe(black);
        assertNotNull(second);
        assertEquals("d7d5", second.move.toString());
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
    }

    @Test public void recoveringTwoSkippedMovesMustPreserveTurn() {
        PositionTracker tracker = new PositionTracker();
        Board board = new Board();
        PieceClassifier.Result starting = resultFor(board);
        tracker.observe(starting);
        tracker.observe(starting);
        assertTrue(board.doMove(findMove(board, "e2e4")));
        PieceClassifier.Result e4 = resultFor(board);
        tracker.observe(e4);
        assertNotNull(tracker.observe(e4));
        assertFalse(tracker.isWhiteToMove());

        // Skip observing ...e6 and only inspect the resulting board after d4.
        assertTrue(board.doMove(findMove(board, "e7e6")));
        assertTrue(board.doMove(findMove(board, "d2d4")));
        PieceClassifier.Result skipped = resultFor(board);
        assertNull(tracker.observe(skipped));
        PositionTracker.Update recovered = tracker.observe(skipped);
        assertNotNull("Should follow two legal plies", recovered);
        assertEquals(2, recovered.recoveredPlies);
        assertNull("No single played move can be named", recovered.move);
        assertTrue(tracker.isTurnKnown());
        assertFalse(tracker.isWhiteToMove());
        assertEquals(board.getFen().split(" ")[0], tracker.getFen().split(" ")[0]);
    }

    @Test public void shortNoisySequenceMustNotDestroyKnownTurn() {
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result starting = resultFor(new Board());
        tracker.observe(starting);
        tracker.observe(starting);
        char[] noisy = starting.screenPieces.clone();
        // F1 bishop suddenly materialises on A3, a non-legal move from start.
        noisy[7 * 8 + 5] = '.';
        noisy[5 * 8 + 0] = 'B';
        PieceClassifier.Result glitch = withPieces(noisy);
        for (int n = 0; n < 4; n++) assertNull(tracker.observe(glitch));
        assertTrue("Don't lose turn on an animation/classifier glitch", tracker.isTurnKnown());
        assertTrue(tracker.hasUnconfirmedPosition());
        assertNull(tracker.observe(starting));
        assertFalse(tracker.hasUnconfirmedPosition());
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
    }

    @Test public void firstObservedE4AndE6CanRecoverTurnFromLegalOpening() {
        PositionTracker tracker = new PositionTracker();
        Board board = new Board();
        assertTrue(board.doMove(findMove(board, "e2e4")));
        assertTrue(board.doMove(findMove(board, "e7e6")));
        PieceClassifier.Result afterTwo = resultFor(board);
        tracker.observe(afterTwo);
        PositionTracker.Update update = tracker.observe(afterTwo);
        assertNotNull(update);
        assertEquals(2, update.recoveredPlies);
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
        assertEquals(board.getFen().split(" ")[0], tracker.getFen().split(" ")[0]);
    }

    private static PieceClassifier.Result withPieces(char[] pieces) {
        int count = 0, white = 0, black = 0;
        for (char c : pieces) {
            if (c == '.') continue;
            count++;
            if (Character.isUpperCase(c)) white++; else black++;
        }
        return new PieceClassifier.Result(pieces, new float[64], 0.95f, 0.90f,
                0, count, true, true, 0.90f, white, black, false, 1, 1);
    }

    private static Move findMove(Board board, String uci) {
        for (Move move : board.legalMoves()) {
            if (uci.equalsIgnoreCase(move.toString())) return move;
        }
        throw new AssertionError("Expected legal move not found: " + uci);
    }

    private static PieceClassifier.Result resultFor(Board board) {
        String placement = board.getFen().split(" ")[0];
        char[] screen = new char[64];
        int count = 0, white = 0, black = 0;
        for (int row = 0; row < 8; row++) {
            int col = 0;
            for (char symbol : placement.split("/")[row].toCharArray()) {
                if (Character.isDigit(symbol)) {
                    int empty = symbol - '0';
                    for (int i = 0; i < empty; i++) screen[row * 8 + col++] = '.';
                } else {
                    screen[row * 8 + col++] = symbol;
                    count++;
                    if (Character.isUpperCase(symbol)) white++;
                    else black++;
                }
            }
        }
        return new PieceClassifier.Result(screen, new float[64], 0.95f, 0.90f,
                0, count, true, true, 0.90f, white, black, false, 1, 1);
    }
}
