package id.chesslens.realtime.vision;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Side;
import com.github.bhlangonijr.chesslib.move.Move;

/** Tracks stable board positions and infers the side to move from observed legal transitions. */
public final class PositionTracker {
    private static final int UNMATCHED_STABLE_FRAMES = 6;
    private static final String START_PLACEMENT =
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

    private boolean whiteBottom = true;
    private boolean orientationLocked = false;
    private boolean whiteToMove = true;
    private boolean turnKnown = false;
    private String currentPlacement = "";
    private String pendingPlacement = "";
    private int stableFrames = 0;
    private Board currentBoard;

    public static final class Update {
        public final Board before;
        public final Board after;
        public final Move move;
        public final boolean initialPosition;
        public final boolean resynchronised;
        public final boolean turnKnown;
        public final boolean turnInferred;
        public final String fen;
        /** Number of legal plies recovered (0 for an untracked resynchronisation). */
        public final int recoveredPlies;

        Update(Board before, Board after, Move move, boolean initial, boolean resync,
               boolean known, boolean inferred, int plies) {
            this.before = before;
            this.after = after;
            this.move = move;
            this.initialPosition = initial;
            this.resynchronised = resync;
            this.turnKnown = known;
            this.turnInferred = inferred;
            this.recoveredPlies = plies;
            this.fen = after.getFen();
        }
    }

    private static final class Match {
        final Board before;
        final Board after;
        final Move move;
        final int plies;
        Match(Board before, Board after, Move move, int plies) {
            this.before = before;
            this.after = after;
            this.move = move;
            this.plies = plies;
        }
    }

    public synchronized boolean isReady() { return currentBoard != null; }
    public synchronized boolean isWhiteBottom() { return whiteBottom; }
    public synchronized boolean isOrientationKnown() { return orientationLocked; }
    public synchronized boolean isTurnKnown() { return turnKnown; }
    public synchronized boolean isWhiteToMove() { return whiteToMove; }
    /** True while a changed visual position is being checked against legal chess moves. */
    public synchronized boolean hasUnconfirmedPosition() {
        return currentBoard != null && !pendingPlacement.equals(currentPlacement)
                && stableFrames >= 2;
    }
    public synchronized String getFen() { return currentBoard == null ? "" : currentBoard.getFen(); }
    public synchronized Board getBoardCopy() { return currentBoard == null ? null : copy(currentBoard); }

    public synchronized void resetPosition() {
        currentPlacement = "";
        pendingPlacement = "";
        stableFrames = 0;
        currentBoard = null;
        whiteToMove = true;
        turnKnown = false;
    }

    /**
     * Applies a stable model result. Two matching frames are required for a move.
     * If the app starts mid-game, the turn is deliberately unknown until a legal
     * one-ply transition is observed; piece placement alone cannot reveal whose
     * turn it is. A standard starting position is the one safe exception.
     */
    public synchronized Update observe(PieceClassifier.Result result) {
        if (result == null || result.pieceCount < 4 || result.averageConfidence < 0.42f
                || result.lowConfidenceSquares > 22) return null;

        boolean orientationChanged = false;
        if (!orientationLocked) {
            Boolean kingOrientation = inferWhiteBottomFromKings(result.screenPieces);
            if (kingOrientation == null && looksLikeStartingOccupancy(result.screenPieces)) {
                kingOrientation = inferWhiteBottomFromStartingRows(result.screenPieces);
            }
            boolean reliable = kingOrientation != null || result.orientationReliable;
            if (reliable) {
                boolean nextWhiteBottom = kingOrientation != null
                        ? kingOrientation : result.suggestedWhiteBottom;
                orientationChanged = currentBoard != null && whiteBottom != nextWhiteBottom;
                whiteBottom = nextWhiteBottom;
                orientationLocked = true;
                if (orientationChanged) resetPosition();
            }
        }

        String placement = result.toFenPlacement(whiteBottom);
        // Never fabricate starting pieces. Only the exact canonical placement is a start.
        boolean startingSetup = currentBoard == null && START_PLACEMENT.equals(placement);
        if (!isSanePlacement(placement)) return null;

        if (!placement.equals(pendingPlacement)) {
            pendingPlacement = placement;
            stableFrames = 1;
            return null;
        }
        stableFrames++;
        if (stableFrames < 2 || placement.equals(currentPlacement)) return null;

        if (currentBoard == null) {
            // First frame may already be after 1.e4 or 1.e4 e6. Recover actual
            // side-to-move and castling rights from legal opening transitions.
            Match opening = startingSetup ? null : recoverFromStart(placement);
            currentPlacement = placement;
            if (opening != null) {
                currentBoard = opening.after;
                whiteToMove = currentBoard.getSideToMove() == Side.WHITE;
                turnKnown = true;
                return new Update(null, copy(currentBoard), null, true, false,
                        true, true, opening.plies);
            }
            whiteToMove = true;
            turnKnown = startingSetup;
            currentBoard = boardFromPlacement(placement, whiteToMove);
            return new Update(null, copy(currentBoard), null, true, false,
                    turnKnown, false, 0);
        }

        if (turnKnown) {
            Match direct = findMatchingMove(currentBoard, placement);
            if (direct != null) return accept(direct, placement, false);

            // Missing an opponent reply is common at 2 FPS. Follow the real
            // observed legal moves, not the Stockfish recommendation.
            Match twoPlies = findMatchingTwoPlies(currentBoard, placement);
            if (twoPlies != null) return accept(twoPlies, placement, true);
        } else {
            Match whiteCandidate = findMatchingMove(currentPlacement, true, placement);
            Match blackCandidate = findMatchingMove(currentPlacement, false, placement);
            if (whiteCandidate != null && blackCandidate == null)
                return accept(whiteCandidate, placement, true);
            if (blackCandidate != null && whiteCandidate == null)
                return accept(blackCandidate, placement, true);

            // If both sides' one-ply transitions fail, a unique two-ply legal
            // sequence can still infer the correct turn. Never invent a turn
            // when competing sequences disagree.
            if (whiteCandidate == null && blackCandidate == null) {
                Match whiteTwo = findMatchingTwoPlies(boardFromPlacement(currentPlacement, true), placement);
                Match blackTwo = findMatchingTwoPlies(boardFromPlacement(currentPlacement, false), placement);
                if (whiteTwo != null && blackTwo == null) return accept(whiteTwo, placement, true);
                if (blackTwo != null && whiteTwo == null) return accept(blackTwo, placement, true);
            }
        }

        // A temporary drag or CV classification error must not destroy the
        // established move history. Give the classifier time to settle.
        // A single hallucinated piece can change only one or two squares and
        // look stable. Give such anomalies more time before abandoning history.
        int changedSquares = changedSquares(currentPlacement, placement);
        if (stableFrames < (changedSquares <= 2 ? 12 : UNMATCHED_STABLE_FRAMES)) return null;

        Board before = copy(currentBoard);
        currentPlacement = placement;
        whiteToMove = true; // unknown; never use this side as a confirmed turn.
        turnKnown = false;
        currentBoard = boardFromPlacement(placement, whiteToMove);
        pendingPlacement = placement;
        return new Update(before, copy(currentBoard), null, false, true, false, false, 0);
    }

    private Update accept(Match match, String placement, boolean inferred) {
        currentBoard = match.after;
        currentPlacement = placement;
        whiteToMove = currentBoard.getSideToMove() == Side.WHITE;
        turnKnown = true;
        pendingPlacement = placement;
        return new Update(copy(match.before), copy(currentBoard), match.move,
                false, false, true, inferred, match.plies);
    }

    /** Try the exact opening seed, but never force a midgame into starting FEN. */
    private static Match recoverFromStart(String placement) {
        if (pieceCount(placement) < 30) return null;
        Board starting = new Board();
        Match one = findMatchingMove(starting, placement);
        return one != null ? one : findMatchingTwoPlies(starting, placement);
    }

    private static int changedSquares(String before, String after) {
        if (before == null || before.isEmpty() || after == null || after.isEmpty()) return 64;
        String a = expand(before), b = expand(after);
        if (a.length() != 64 || b.length() != 64) return 64;
        int changes = 0;
        for (int i = 0; i < 64; i++) if (a.charAt(i) != b.charAt(i)) changes++;
        return changes;
    }

    private static String expand(String placement) {
        StringBuilder squares = new StringBuilder(64);
        for (int i = 0; i < placement.length(); i++) {
            char c = placement.charAt(i);
            if (c == '/') continue;
            if (c >= '1' && c <= '8') for (int j = 0; j < c - '0'; j++) squares.append('.');
            else squares.append(c);
        }
        return squares.toString();
    }

    private static int pieceCount(String placement) {
        int count = 0;
        for (int i = 0; i < placement.length(); i++)
            if ("PNBRQKpnbrqk".indexOf(placement.charAt(i)) >= 0) count++;
        return count;
    }

    private static Match findMatchingMove(Board source, String targetPlacement) {
        if (source == null) return null;
        Board before = copy(source);
        Match found = null;
        for (Move move : before.legalMoves()) {
            Board after = copy(before);
            if (!after.doMove(move) || !placementOf(after).equals(targetPlacement)) continue;
            if (found != null && !found.after.getFen().equals(after.getFen())) return null;
            found = new Match(before, after, move, 1);
        }
        return found;
    }

    /** Recovers up to two missed legal moves. Ambiguous metadata is rejected. */
    private static Match findMatchingTwoPlies(Board source, String targetPlacement) {
        if (source == null) return null;
        Board before = copy(source);
        Match found = null;
        for (Move first : before.legalMoves()) {
            Board intermediate = copy(before);
            if (!intermediate.doMove(first)) continue;
            for (Move second : intermediate.legalMoves()) {
                Board after = copy(intermediate);
                if (!after.doMove(second) || !placementOf(after).equals(targetPlacement)) continue;
                if (found != null && !found.after.getFen().equals(after.getFen())) return null;
                found = new Match(before, after, null, 2);
            }
        }
        return found;
    }

    private static Match findMatchingMove(String placement, boolean sideWhite, String targetPlacement) {
        return findMatchingMove(boardFromPlacement(placement, sideWhite), targetPlacement);
    }

    private static Board boardFromPlacement(String placement, boolean whiteToMove) {
        Board board = new Board();
        String castling = START_PLACEMENT.equals(placement) ? "KQkq" : "-";
        board.loadFromFen(placement + (whiteToMove ? " w " : " b ") + castling + " - 0 1");
        return board;
    }

    private static String placementOf(Board board) {
        return board.getFen().split(" ")[0];
    }

    private static Board copy(Board source) {
        Board result = new Board();
        result.loadFromFen(source.getFen());
        return result;
    }

    private static Boolean inferWhiteBottomFromKings(char[] screenPieces) {
        int whiteKingRow = -1, blackKingRow = -1, whiteKings = 0, blackKings = 0;
        for (int i = 0; i < screenPieces.length; i++) {
            if (screenPieces[i] == 'K') { whiteKings++; whiteKingRow = i / 8; }
            else if (screenPieces[i] == 'k') { blackKings++; blackKingRow = i / 8; }
        }
        if (whiteKings != 1 || blackKings != 1) return null;
        if (whiteKingRow >= 5 && blackKingRow <= 2) return true;
        if (blackKingRow >= 5 && whiteKingRow <= 2) return false;
        return null;
    }

    private static Boolean inferWhiteBottomFromStartingRows(char[] screenPieces) {
        int topWhite = 0, topBlack = 0, bottomWhite = 0, bottomBlack = 0;
        for (int i = 0; i < 64; i++) {
            char piece = screenPieces[i];
            int row = i / 8;
            if (row <= 1) {
                if (Character.isUpperCase(piece) && piece != '.') topWhite++;
                else if (Character.isLowerCase(piece)) topBlack++;
            } else if (row >= 6) {
                if (Character.isUpperCase(piece) && piece != '.') bottomWhite++;
                else if (Character.isLowerCase(piece)) bottomBlack++;
            }
        }
        if (topBlack >= topWhite + 3 && bottomWhite >= bottomBlack + 3) return true;
        if (topWhite >= topBlack + 3 && bottomBlack >= bottomWhite + 3) return false;
        return null;
    }

    /**
     * Only a board with all 32 pieces on their two home ranks is eligible
     * for start-position recovery. After 1.e4 one pawn is in the center and
     * must NEVER be silently replaced with the full starting FEN.
     */
    private static boolean looksLikeStartingOccupancy(char[] screenPieces) {
        if (screenPieces == null || screenPieces.length != 64) return false;
        int kingsWhite = 0, kingsBlack = 0;
        for (int i = 0; i < 64; i++) {
            if (screenPieces[i] == 'K') kingsWhite++;
            if (screenPieces[i] == 'k') kingsBlack++;
            boolean homeRank = (i / 8 <= 1 || i / 8 >= 6);
            if (homeRank != (screenPieces[i] != '.')) return false;
        }
        return kingsWhite == 1 && kingsBlack == 1;
    }

    private static boolean isSanePlacement(String placement) {
        int whiteKings = 0, blackKings = 0, whitePawns = 0, blackPawns = 0;
        int pieces = 0;
        String[] ranks = placement.split("/");
        if (ranks.length != 8) return false;
        for (int rank = 0; rank < ranks.length; rank++) {
            int files = 0;
            for (int i = 0; i < ranks[rank].length(); i++) {
                char p = ranks[rank].charAt(i);
                if (p >= '1' && p <= '8') { files += p - '0'; continue; }
                files++;
                if (p == 'K') whiteKings++;
                else if (p == 'k') blackKings++;
                else if (p == 'P') { whitePawns++; if (rank == 0 || rank == 7) return false; }
                else if (p == 'p') { blackPawns++; if (rank == 0 || rank == 7) return false; }
                else if ("BNRQbnrq".indexOf(p) < 0) return false;
                pieces++;
            }
            if (files != 8) return false;
        }
        return whiteKings == 1 && blackKings == 1 && pieces <= 32
                && whitePawns <= 8 && blackPawns <= 8;
    }
}
