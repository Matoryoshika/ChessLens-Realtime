package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.view.View;

/** Exactly one understated arrow from square-center to square-center. */
public final class ArrowCanvas extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Rect boardRect;
    private int sourceWidth, sourceHeight;
    private String activeMove = "";
    private boolean whiteBottom = true;
    private boolean opponentTurn = false;

    public ArrowCanvas(Context context) {
        super(context);
        setWillNotDraw(false);
    }

    public void update(Rect rect, int frameWidth, int frameHeight,
                       String from, String to, String mark,
                       String myMove, String opponentMove, boolean white,
                       boolean playerKnown) {
        boardRect = rect == null ? null : new Rect(rect);
        sourceWidth = frameWidth;
        sourceHeight = frameHeight;
        whiteBottom = white;
        // The caller shows only the recommendation for the actual turn.
        activeMove = valid(myMove) ? myMove : valid(opponentMove) ? opponentMove : "";
        opponentTurn = !valid(myMove) && valid(opponentMove);
        invalidate();
    }

    private static boolean valid(String move) {
        return move != null && move.matches("[a-h][1-8][a-h][1-8][qrbn]?");
    }

    private PointF center(Rect board, String square) {
        int file = square.charAt(0) - 'a';
        int row = 8 - (square.charAt(1) - '0');
        if (!whiteBottom) { file = 7 - file; row = 7 - row; }
        return new PointF(board.left + (file + 0.5f) * board.width() / 8f,
                board.top + (row + 0.5f) * board.height() / 8f);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (boardRect == null || !valid(activeMove) || sourceWidth <= 0 || sourceHeight <= 0) return;
        Rect board = new Rect(
                Math.round(boardRect.left * getWidth() / (float) sourceWidth),
                Math.round(boardRect.top * getHeight() / (float) sourceHeight),
                Math.round(boardRect.right * getWidth() / (float) sourceWidth),
                Math.round(boardRect.bottom * getHeight() / (float) sourceHeight));
        if (board.width() < 64 || board.height() < 64) return;
        PointF start = center(board, activeMove.substring(0, 2));
        PointF end = center(board, activeMove.substring(2, 4));
        float dx = end.x - start.x, dy = end.y - start.y;
        float dist = (float) Math.hypot(dx, dy);
        if (dist < 1f) return;
        float ux = dx / dist, uy = dy / dist;
        float px = -uy, py = ux;
        float cell = Math.min(board.width(), board.height()) / 8f;
        float shaft = Math.max(2.5f, cell * 0.075f);
        int color = opponentTurn ? 0xAEEDAD66 : 0xB06DDCA3;

        paint.reset(); paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(shaft + Math.max(1f, cell * 0.035f));
        paint.setColor(0x48101827);
        canvas.drawLine(start.x, start.y, end.x, end.y, paint);
        paint.setStrokeWidth(shaft);
        paint.setColor(color);
        canvas.drawLine(start.x, start.y, end.x, end.y, paint);

        // Compact head, with its tip at the exact center of the destination.
        float headLength = cell * 0.30f;
        float headHalf = cell * 0.17f;
        Path arrowhead = new Path();
        arrowhead.moveTo(end.x, end.y);
        arrowhead.lineTo(end.x - ux * headLength + px * headHalf,
                end.y - uy * headLength + py * headHalf);
        arrowhead.lineTo(end.x - ux * headLength - px * headHalf,
                end.y - uy * headLength - py * headHalf);
        arrowhead.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        canvas.drawPath(arrowhead, paint);

        // A small origin dot, not an oversized ring or a confusing badge.
        paint.setColor(Color.argb(180, 255, 255, 255));
        canvas.drawCircle(start.x, start.y, Math.max(2f, cell * 0.105f), paint);
        paint.setColor(color);
        canvas.drawCircle(start.x, start.y, Math.max(1.5f, cell * 0.065f), paint);
    }
}
