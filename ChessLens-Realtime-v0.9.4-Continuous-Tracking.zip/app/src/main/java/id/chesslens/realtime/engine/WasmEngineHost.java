package id.chesslens.realtime.engine;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * One process-level transport for Stockfish WASM. During screen capture the
 * foreground Service OWNS a 2x2 transparent overlay WebView, rather than an
 * Activity whose UI is moved to the background. Each reload is a new epoch:
 * responses from old WebViews/workers cannot contaminate the new UCI queue.
 *
 * Being able to post a message to the Worker is NOT UCI readiness. UciEngine
 * must still observe the real 'uciok' and 'readyok' handshake.
 */
public final class WasmEngineHost {
    private static final String HOST = "chesslens.local";
    private static final String BASE_URL = "https://" + HOST + "/";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LinkedBlockingQueue<String> OUTPUT = new LinkedBlockingQueue<>();

    private static volatile WebView webView;
    private static volatile Context appContext;
    private static volatile WindowManager serviceWindowManager;
    private static volatile boolean serviceOwned;
    private static volatile boolean pageStarted;
    private static volatile String engineError;
    private static volatile String diagnosticStage = "not attached";
    private static volatile CountDownLatch pageBootstrap = new CountDownLatch(1);
    private static volatile long epoch;

    private WasmEngineHost() {}

    private static final String HTML = "<!doctype html><html><head><meta charset='utf-8'></head><body>"
            + "<script>(function(){"
            + "function fail(m){try{ChessLensNative.onError(String(m));}catch(ignore){}}"
            + "window.addEventListener('error',function(e){fail('Page JS: '+String(e.message||e.type));});"
            + "window.addEventListener('unhandledrejection',function(e){fail('Promise: '+String(e.reason));});"
            + "try{"
            + "const worker=new Worker('/engine/stockfish-18-single.js');"
            + "worker.onmessage=function(e){try{var d=e.data;ChessLensNative.onLine(String(d&&d.line!==undefined?d.line:d));}catch(x){fail(x);}};"
            + "worker.onerror=function(e){fail('Worker: '+String(e.message||'unknown')+' '+String(e.filename||''));};"
            + "worker.onmessageerror=function(){fail('Worker message could not be decoded');};"
            + "window.chesslensSend=function(command){try{worker.postMessage(String(command));}catch(e){fail('postMessage: '+e);}};"
            + "ChessLensNative.onReady();"
            + "}catch(e){fail('Worker construction: '+String(e));}"
            + "})();</script></body></html>";

    private static void checkMain() {
        if (Looper.myLooper() != Looper.getMainLooper())
            throw new IllegalStateException("WasmEngineHost must be managed on Android UI thread");
    }

    /** Practice board host. No Activity is allowed to steal the Service's worker. */
    public static synchronized void attach(Activity activity, ViewGroup parent) {
        checkMain();
        if (serviceOwned) return;
        if (webView == null) createWebView(activity.getApplicationContext());
        detachParent();
        parent.addView(webView, 0, new ViewGroup.LayoutParams(2, 2));
        webView.onResume();
        webView.resumeTimers();
        loadOnce();
    }

    /** Own a visible-to-Android, non-touchable WebView for the entire capture session. */
    public static synchronized void attachForService(Service service) {
        checkMain();
        if (serviceOwned && webView != null) return;
        resetHost(); // Discard any Activity-owned worker and stale responses.
        createWebView(service.getApplicationContext());
        WindowManager wm = (WindowManager) service.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) throw new IllegalStateException("WindowManager not available");
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                2, 2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        serviceOwned = true;
        serviceWindowManager = wm;
        try {
            wm.addView(webView, params);
            webView.onResume();
            webView.resumeTimers();
            loadOnce();
        } catch (RuntimeException e) {
            resetHost();
            throw e;
        }
    }

    /** Recovery after a real UCI handshake/Worker failure, not every screen frame. */
    public static synchronized void restartServiceHost(Service service) {
        checkMain();
        if (!serviceOwned) throw new IllegalStateException("No active Service-owned host to restart");
        resetHost();
        attachForService(service);
    }

    public static synchronized void releaseService() {
        checkMain();
        if (serviceOwned) resetHost();
    }

    public static boolean isServiceOwned() { return serviceOwned; }
    public static long generation() { return epoch; }
    public static String stage() { return diagnosticStage; }

    private static void createWebView(Context context) {
        appContext = context.getApplicationContext();
        long generation = ++epoch;
        engineError = null;
        diagnosticStage = "creating WebView";
        OUTPUT.clear();
        pageBootstrap = new CountDownLatch(1);
        pageStarted = false;
        WebView view = new WebView(appContext);
        view.setBackgroundColor(Color.TRANSPARENT);
        view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        view.addJavascriptInterface(new Bridge(generation), "ChessLensNative");
        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request) {
                return intercept(request.getUrl(), generation);
            }
            @SuppressWarnings("deprecation")
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, String url) {
                return intercept(Uri.parse(url), generation);
            }
        });
        webView = view;
    }

    private static void loadOnce() {
        if (!pageStarted && webView != null) {
            pageStarted = true;
            diagnosticStage = "loading Worker page";
            webView.loadUrl(BASE_URL + "index.html");
        }
    }

    private static void detachParent() {
        if (webView == null) return;
        if (serviceOwned && serviceWindowManager != null) {
            try { serviceWindowManager.removeViewImmediate(webView); } catch (Exception ignored) { }
            serviceWindowManager = null;
            serviceOwned = false;
        } else if (webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) webView.getParent()).removeView(webView);
        }
    }

    private static void resetHost() {
        ++epoch;
        WebView old = webView;
        if (old != null) {
            detachParent();
            try { old.stopLoading(); old.loadUrl("about:blank"); old.destroy(); } catch (Exception ignored) { }
        }
        webView = null;
        serviceOwned = false;
        serviceWindowManager = null;
        pageStarted = false;
        engineError = null;
        diagnosticStage = "reset";
        OUTPUT.clear();
        pageBootstrap = new CountDownLatch(1);
    }

    private static WebResourceResponse intercept(Uri uri, long generation) {
        if (uri == null || !HOST.equals(uri.getHost())) return null;
        String path = uri.getPath();
        try {
            if ("/".equals(path) || "/index.html".equals(path)) {
                return response("text/html", "UTF-8", new ByteArrayInputStream(HTML.getBytes(StandardCharsets.UTF_8)));
            }
            File file = null;
            String mime = null;
            if ("/engine/stockfish-18-single.js".equals(path)) {
                file = EngineInstaller.engineJsFile(appContext);
                mime = "application/javascript";
            } else if ("/engine/stockfish.wasm".equals(path)
                    || "/engine/stockfish-18-single.wasm".equals(path)
                    || "/stockfish.wasm".equals(path)
                    || "/stockfish-18-single.wasm".equals(path)) {
                file = EngineInstaller.engineWasmFile(appContext);
                mime = "application/wasm";
            }
            // Unknown requests such as /favicon.ico must not poison the engine.
            if (file == null) return notFound();
            if (!file.isFile()) {
                signalError(generation, "Missing Stockfish asset: " + path);
                return notFound();
            }
            return response(mime, null, new FileInputStream(file));
        } catch (Exception e) {
            signalError(generation, "Cannot open Stockfish asset: " + e.getMessage());
            return notFound();
        }
    }

    private static WebResourceResponse response(String mime, String encoding, java.io.InputStream stream) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, encoding, 200, "OK", headers, stream);
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<>(), new ByteArrayInputStream("Missing".getBytes(StandardCharsets.UTF_8)));
    }

    private static void signalError(long generation, String message) {
        if (generation != epoch) return;
        engineError = message;
        diagnosticStage = "error: " + message;
        OUTPUT.offer("__CHESSLENS_ERROR__" + message);
        pageBootstrap.countDown();
    }

    /** Page bootstrap only; UCI readiness is verified by UciEngine separately. */
    public static void awaitReady(long timeoutMs) throws Exception {
        if (webView == null) throw new IOException("Stockfish WebView not attached");
        if (!pageBootstrap.await(timeoutMs, TimeUnit.MILLISECONDS)) {
            throw new IOException(engineError != null ? engineError : "Stockfish page did not start (stage: " + stage() + ")");
        }
        if (engineError != null) throw new IOException(engineError);
    }

    public static void send(String command) throws IOException {
        if (webView == null) throw new IOException("Stockfish WebView not active");
        final String quoted = JSONObject.quote(command);
        final long requestEpoch = epoch;
        MAIN.post(() -> {
            WebView current = webView;
            if (current == null || requestEpoch != epoch) return;
            current.evaluateJavascript("window.chesslensSend && window.chesslensSend(" + quoted + ");", null);
        });
    }

    public static String pollLine(long timeoutMs) throws Exception {
        String line = OUTPUT.poll(Math.max(1, timeoutMs), TimeUnit.MILLISECONDS);
        if (line == null) {
            if (engineError != null) throw new IOException(engineError);
            return null;
        }
        if (line.startsWith("__CHESSLENS_ERROR__")) throw new IOException(line.substring("__CHESSLENS_ERROR__".length()));
        return line;
    }

    public static String nextLine(long timeoutMs) throws Exception {
        String line = pollLine(timeoutMs);
        if (line == null) throw new IOException("Stockfish did not respond; stage: " + stage());
        return line;
    }

    public static void clearOutput() { OUTPUT.clear(); }

    private static final class Bridge {
        private final long generation;
        Bridge(long generation) { this.generation = generation; }
        @JavascriptInterface public void onReady() {
            if (generation != epoch) return;
            diagnosticStage = "Worker created; waiting for UCI";
            pageBootstrap.countDown();
        }
        @JavascriptInterface public void onLine(String line) {
            if (generation != epoch || line == null) return;
            String output = line.trim();
            if (output.equals("uciok")) diagnosticStage = "uciok received";
            if (output.equals("readyok")) diagnosticStage = "readyok received";
            if (output.startsWith("bestmove ")) diagnosticStage = "bestmove received";
            OUTPUT.offer(line);
        }
        @JavascriptInterface public void onError(String message) {
            signalError(generation, message == null ? "Stockfish Worker error" : message);
        }
    }
}
