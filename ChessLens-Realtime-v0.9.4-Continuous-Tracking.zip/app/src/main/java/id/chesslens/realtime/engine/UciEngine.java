package id.chesslens.realtime.engine;

import java.io.IOException;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** UCI client backed by Stockfish 18 WebAssembly running in Android WebView. */
public final class UciEngine implements AutoCloseable {
    // A single process-wide UCI channel is shared by Practice and Overlay.
    // Serialize handshakes and searches so UCI output never crosses sessions.
    private static final Object UCI_LOCK = new Object();
    private volatile boolean closed;
    private final long hostGeneration;

    public interface ProgressListener {
        void onProgress(Evaluation provisional, int depth);
    }

    public static final class Evaluation {
        public final int cp;
        public final String bestMove, description;
        public final List<String> principalVariation;
        public Evaluation(int cp, String bestMove, String description, List<String> pv) {
            this.cp = cp;
            this.bestMove = bestMove;
            this.description = description;
            this.principalVariation = Collections.unmodifiableList(new ArrayList<>(pv));
        }
        public Evaluation(int cp, String bestMove, String description) {
            this(cp, bestMove, description, bestMove == null || bestMove.isEmpty()
                    ? Collections.emptyList() : Collections.singletonList(bestMove));
        }
        public String moveAt(int ply) {
            return ply >= 0 && ply < principalVariation.size() ? principalVariation.get(ply) : "";
        }
    }

    public UciEngine() throws Exception { this(null); }

    @Deprecated public UciEngine(String ignoredExecutablePath) throws Exception {
        synchronized (UCI_LOCK) {
        WasmEngineHost.awaitReady(45_000);
        hostGeneration = WasmEngineHost.generation();
        WasmEngineHost.clearOutput();
        send("uci");
        waitFor("uciok", 60_000);
        send("setoption name Threads value 1");
        // Keep the hash modest for phones with limited RAM; the NNUE network is already large.
        send("setoption name Hash value 8");
        send("setoption name MultiPV value 1");
        send("isready");
        waitFor("readyok", 45_000);
        WasmEngineHost.clearOutput();
        }
    }

    private void send(String command) throws IOException {
        if (closed) throw new IOException("Sesi engine sudah ditutup.");
        if (WasmEngineHost.generation() != hostGeneration)
            throw new IOException("Host Stockfish diganti; sesi UCI harus dibuat ulang.");
        WasmEngineHost.send(command);
    }

    private void waitFor(String expected, long timeoutMs) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        String last = "";
        while (System.currentTimeMillis() < deadline) {
            String line = WasmEngineHost.pollLine(Math.min(1000L, Math.max(1L, deadline - System.currentTimeMillis())));
            if (line == null) continue;
            last = line;
            if (expected.equals(line.trim())) return;
        }
        throw new IOException("Stockfish tidak mengirim " + expected + " saat inisialisasi. Respons terakhir: " + last);
    }

    /** Runs one serialized search. A ready barrier prevents stale bestmove lines crossing searches. */
    public Evaluation analyze(String fen, int milliseconds) throws Exception {
        return analyze(fen, milliseconds, null);
    }

    public Evaluation analyze(String fen, int milliseconds, ProgressListener progress) throws Exception {
        synchronized (UCI_LOCK) {
        if (closed) throw new IOException("Sesi engine sudah ditutup.");
        if (fen == null || fen.trim().isEmpty()) throw new IOException("FEN kosong; posisi papan belum valid.");

        send("isready");
        waitFor("readyok", 12_000);
        WasmEngineHost.clearOutput();

        int moveTime = Math.max(250, Math.min(10_000, milliseconds));
        send("startpos".equals(fen.trim()) ? "position startpos" : "position fen " + fen.trim());
        send("go movetime " + moveTime);

        int cp = 0;
        int bestDepth = -1;
        String best = "";
        String notation = "0.00";
        String lastLine = "";
        int receivedLines = 0;
        List<String> bestPv = new ArrayList<>();
        long lastProgressAt = 0L;
        int lastProgressDepth = -1;
        long started = System.currentTimeMillis();
        long deadline = started + Math.max(45_000L, moveTime * 12L + 15_000L);

        while (System.currentTimeMillis() < deadline) {
            String line = WasmEngineHost.pollLine(1000L);
            if (line == null) continue;
            receivedLines++;
            lastLine = line;
            if (line.startsWith("info ")) {
                String[] tokens = line.trim().split("\\s+");
                int depth = -1;
                int lineCp = cp;
                String lineNotation = notation;
                List<String> linePv = new ArrayList<>();
                for (int i = 0; i < tokens.length; i++) {
                    if ("depth".equals(tokens[i]) && i + 1 < tokens.length) {
                        try { depth = Integer.parseInt(tokens[i + 1]); } catch (NumberFormatException ignored) { }
                    }
                    if ("score".equals(tokens[i]) && i + 2 < tokens.length) {
                        try {
                            if ("cp".equals(tokens[i + 1])) {
                                lineCp = Integer.parseInt(tokens[i + 2]);
                                lineNotation = String.format(Locale.US, "%+.2f", lineCp / 100.0);
                            } else if ("mate".equals(tokens[i + 1])) {
                                int mate = Integer.parseInt(tokens[i + 2]);
                                lineCp = mate > 0 ? 20_000 - mate * 10 : -20_000 - mate * 10;
                                lineNotation = "M" + mate;
                            }
                        } catch (NumberFormatException ignored) { }
                    }
                    if ("pv".equals(tokens[i])) {
                        for (int j = i + 1; j < tokens.length; j++) {
                            if (!tokens[j].matches("[a-h][1-8][a-h][1-8][qrbn]?")) break;
                            linePv.add(tokens[j]);
                        }
                        break;
                    }
                }
                if (!linePv.isEmpty() && depth >= bestDepth) {
                    bestDepth = depth;
                    cp = lineCp;
                    notation = lineNotation;
                    bestPv = linePv;
                    long at = System.currentTimeMillis();
                    // Show an explicitly provisional arrow while the final bestmove
                    // is still being calculated; the caller validates UCI legality.
                    if (progress != null && depth > 0 &&
                            (lastProgressDepth < 0 || (depth > lastProgressDepth && at - lastProgressAt >= 250L))) {
                        try { progress.onProgress(new Evaluation(cp, linePv.get(0), notation + " (sementara)", linePv), depth); }
                        catch (RuntimeException ignored) { /* UI errors must never cancel a UCI search. */ }
                        lastProgressAt = at;
                        lastProgressDepth = depth;
                    }
                }
            }
            if (line.startsWith("bestmove ")) {
                String[] tokens = line.trim().split("\\s+");
                best = tokens.length > 1 ? tokens[1] : "";
                break;
            }
        }

        if (best.isEmpty()) {
            try { send("stop"); } catch (Exception ignored) { }
            throw new IOException("Stockfish tidak mengirim bestmove setelah "
                    + ((System.currentTimeMillis() - started) / 1000) + " detik. Baris diterima: "
                    + receivedLines + ". Respons terakhir: " + lastLine);
        }
        if ("(none)".equals(best) || "0000".equals(best))
            throw new IOException("Stockfish tidak menemukan langkah legal pada posisi ini.");
        if (bestPv.isEmpty() || !best.equals(bestPv.get(0))) {
            bestPv.clear();
            bestPv.add(best);
        }
        return new Evaluation(cp, best, notation, bestPv);
        }
    }

    public void stopSearch() {
        if (!closed && WasmEngineHost.generation() == hostGeneration) {
            try { WasmEngineHost.send("stop"); } catch (Exception ignored) { }
        }
    }

    @Override public void close() {
        stopSearch();
        closed = true;
    }
}
