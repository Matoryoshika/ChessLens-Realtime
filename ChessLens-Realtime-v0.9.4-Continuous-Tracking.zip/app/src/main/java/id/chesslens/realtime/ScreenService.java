package id.chesslens.realtime;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.*;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.view.WindowManager;

import id.chesslens.realtime.engine.*;
import id.chesslens.realtime.overlay.FloatingOverlay;
import id.chesslens.realtime.vision.*;

import java.nio.ByteBuffer;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** Opt-in on-device screen capture and chess-position recognition. */
public final class ScreenService extends Service {
    public static final String ACTION_STOP = "id.chesslens.realtime.STOP";
    private static final String CHANNEL = "chesslens_capture";

    private MediaProjection projection;
    private VirtualDisplay display;
    private volatile ImageReader reader;
    private final Object captureLock = new Object();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ThreadPoolExecutor analysisWorker = new ThreadPoolExecutor(
            1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(), runnable -> {
                Thread thread = new Thread(runnable, "ChessLens-Analysis");
                thread.setDaemon(true);
                return thread;
            });
    private final AtomicLong analysisGeneration = new AtomicLong(0);
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private FloatingOverlay overlay;
    private final BoardFinder finder = new BoardFinder();
    private final PositionTracker tracker = new PositionTracker();
    private PieceClassifier classifier;
    private volatile UciEngine engine;
    private android.content.SharedPreferences learningPrefs;
    private volatile boolean showMyBest = true;
    private volatile boolean showOpponentBest = true;
    private volatile boolean playerWhite = true;
    private volatile boolean playerSideKnown = false;
    private volatile boolean lastOrientationKnown = false;
    private volatile UciEngine.Evaluation lastEvaluation;
    private volatile UciEngine.Evaluation unknownWhiteEvaluation;
    private volatile UciEngine.Evaluation unknownBlackEvaluation;
    private volatile Rect lastAnalyzedBoard;
    private volatile int lastAnalyzedFrameWidth = 0;
    private volatile int lastAnalyzedFrameHeight = 0;
    private volatile String lastPlayedFrom = "", lastPlayedTo = "", lastMoveSymbol = "";
    private volatile String lastAnalysisPrefix = "";
    private final AtomicReference<String> engineHealth = new AtomicReference<>("belum diperiksa");
    private volatile long lastProgressShownAt = 0;
    private volatile long lastEngineRecoveryAt = 0;

    private volatile boolean paused = false;
    private volatile boolean forceRelock = false;
    private int width, height, thinkMs = 350;
    private Rect lastBoard, candidateBoard;
    private int boardMissCount = 0, candidateBoardCount = 0, emptyFrameCount = 0;
    private long lastCaptureDiagnosticAt = 0;
    private volatile String lastAnalyzedFen = "";
    private volatile long lastAnalysisFailedAt = 0;
    private long lastFullBoardScanAt = 0;
    private long lastRecognitionStatusAt = 0;
    private int lowConfidenceFrames = 0;
    private boolean awaitingLegalPosition = false;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!paused) capture();
            main.postDelayed(this, 400);
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;
        thinkMs = Math.max(150, Math.min(1500, intent.getIntExtra("thinkMs", 350)));
        try {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 26)
                manager.createNotificationChannel(new NotificationChannel(CHANNEL, "ChessLens screen analysis", NotificationManager.IMPORTANCE_LOW));
            PendingIntent home = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Intent end = new Intent(this, ScreenService.class).setAction(ACTION_STOP);
            PendingIntent endAction = PendingIntent.getService(this, 2, end,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification note = new Notification.Builder(this, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("ChessLens Realtime aktif")
                    .setContentText("Membaca posisi papan dan menjalankan Stockfish di perangkat.")
                    .setContentIntent(home).setOngoing(true)
                    .addAction(android.R.drawable.ic_delete, "Hentikan", endAction).build();
            if (Build.VERSION.SDK_INT >= 29) startForeground(13, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(13, note);
            if (!android.provider.Settings.canDrawOverlays(this)) throw new SecurityException("Izin overlay tidak aktif");

            learningPrefs = getSharedPreferences("chesslens_learning_mode", MODE_PRIVATE);
            showMyBest = learningPrefs.getBoolean("show_my_best", true);
            showOpponentBest = learningPrefs.getBoolean("show_opponent_best", true);
            overlay = new FloatingOverlay(this,
                    this::requestBoardRelock,
                    this::togglePause,
                    this::toggleMyBest,
                    this::toggleOpponentBest,
                    this::stopSelf);
            overlay.setAutoState(false, true, false, true);
            overlay.setLearningOptions(showMyBest, showOpponentBest);

            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            Rect bounds;
            if (Build.VERSION.SDK_INT >= 30) bounds = wm.getMaximumWindowMetrics().getBounds();
            else {
                android.graphics.Point point = new android.graphics.Point();
                wm.getDefaultDisplay().getRealSize(point);
                bounds = new Rect(0, 0, point.x, point.y);
            }
            width = bounds.width(); height = bounds.height();
            synchronized (captureLock) { reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2); }

            MediaProjectionManager projectionManager = getSystemService(MediaProjectionManager.class);
            int resultCode = intent.getIntExtra("result", Activity.RESULT_CANCELED);
            @SuppressWarnings("deprecation") Intent permission = intent.getParcelableExtra("data");
            projection = projectionManager.getMediaProjection(resultCode, permission);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(() -> stopSelf()); }
                @Override public void onCapturedContentResize(int newWidth, int newHeight) { main.post(() -> resize(newWidth, newHeight)); }
            }, main);
            display = projection.createVirtualDisplay("ChessLens", width, height,
                    getResources().getDisplayMetrics().densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, main);
            // The Activity moves to the background when the user plays elsewhere.
            // Keep the WASM WebView attached to the foreground Service instead.
            if (!EngineInstaller.isInstalled(this))
                throw new IllegalStateException("Engine belum terpasang; buka ChessLens dahulu");
            WasmEngineHost.attachForService(this);
            overlay.status("Mode Overlay: menguji Stockfish langsung tanpa kamera…");
            analysisWorker.submit(() -> {
                try {
                    ensureEngine();
                    com.github.bhlangonijr.chesslib.Board starting = new com.github.bhlangonijr.chesslib.Board();
                    UciEngine.Evaluation check = engine.analyze(starting.getFen(), 400);
                    if (legalPvMove(starting, check, 0).isEmpty())
                        throw new IllegalStateException("Self-test menghasilkan langkah tidak legal");
                    engineHealth.set("siap: " + check.bestMove + " | " + WasmEngineHost.stage());
                    overlay.status("Stockfish Overlay siap (FEN awal → " + check.bestMove
                            + "). Memulai pembacaan papan…");
                } catch (Exception error) {
                    engineHealth.set("gagal: " + error.getMessage() + " | " + WasmEngineHost.stage());
                    overlay.status("Uji mandiri engine gagal sebelum CV: " + engineHealth.get()
                            + "\nPapan tetap akan dibaca untuk diagnosis.");
                } finally {
                    main.postDelayed(ticker, 250);
                }
            });
        } catch (Exception error) {
            if (overlay != null) overlay.status("Tidak dapat memulai: " + error.getMessage());
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void requestBoardRelock() {
        forceRelock = true;
        lastFullBoardScanAt = 0;
        candidateBoard = null;
        candidateBoardCount = 0;
        overlay.clear();
        overlay.status("Mencari ulang batas papan. Posisi dan giliran tidak dihapus.");
    }

    private void togglePause() {
        paused = !paused;
        overlay.setPaused(paused);
        overlay.status(paused ? "⏸ Analisis dijeda." : "▶ Melanjutkan pembacaan papan…");
    }

    private void invalidateAnalysis() {
        analysisGeneration.incrementAndGet();
        if (engine != null) engine.stopSearch();
        analysisWorker.getQueue().clear();
        lastEvaluation = null;
        unknownWhiteEvaluation = null;
        unknownBlackEvaluation = null;
        lastAnalyzedBoard = null;
        lastAnalyzedFen = "";
        lastAnalysisFailedAt = 0;
        lastAnalysisPrefix = "";
        lastPlayedFrom = "";
        lastPlayedTo = "";
        lastMoveSymbol = "";
        if (overlay != null) overlay.clear();
    }

    private void syncAutomaticState() {
        boolean orientationKnown = tracker.isOrientationKnown();
        if (orientationKnown && !lastOrientationKnown) {
            invalidateAnalysis();
            if (overlay != null) overlay.status("Orientasi papan terkunci otomatis · "
                    + (tracker.isWhiteBottom() ? "Putih" : "Hitam") + " di bawah. "
                    + (tracker.isTurnKnown() ? "Giliran sudah diketahui." : "Giliran belum pasti; dua kemungkinan akan dianalisis."));
        }
        lastOrientationKnown = orientationKnown;
        playerSideKnown = orientationKnown;
        if (orientationKnown) playerWhite = tracker.isWhiteBottom();
        if (overlay != null) {
            overlay.setAutoState(orientationKnown, tracker.isWhiteBottom(),
                    tracker.isTurnKnown(), tracker.isWhiteToMove());
        }
    }

    private void submitLatestAnalysis(Runnable task) {
        analysisWorker.getQueue().clear();
        analysisWorker.submit(task);
    }

    private void toggleMyBest() {
        showMyBest = !showMyBest;
        if (learningPrefs != null) learningPrefs.edit().putBoolean("show_my_best", showMyBest).apply();
        overlay.setLearningOptions(showMyBest, showOpponentBest);
        if (!tracker.isTurnKnown() && unknownWhiteEvaluation != null) renderUnknownTurnAnalysis(
                "Analisis dua kemungkinan giliran", tracker.getFen().split(" ")[0] + " w - - 0 1",
                tracker.getFen().split(" ")[0] + " b - - 0 1");
        else renderCachedAnalysis();
    }

    private void toggleOpponentBest() {
        showOpponentBest = !showOpponentBest;
        if (learningPrefs != null) learningPrefs.edit().putBoolean("show_opponent_best", showOpponentBest).apply();
        overlay.setLearningOptions(showMyBest, showOpponentBest);
        if (!tracker.isTurnKnown() && unknownWhiteEvaluation != null) renderUnknownTurnAnalysis(
                "Analisis dua kemungkinan giliran", tracker.getFen().split(" ")[0] + " w - - 0 1",
                tracker.getFen().split(" ")[0] + " b - - 0 1");
        else renderCachedAnalysis();
    }

    private void resize(int newWidth, int newHeight) {
        if (newWidth < 200 || newHeight < 200 || display == null || (newWidth == width && newHeight == height)) return;
        ImageReader fresh = ImageReader.newInstance(newWidth, newHeight, PixelFormat.RGBA_8888, 2);
        synchronized (captureLock) {
            ImageReader old = reader;
            reader = fresh; width = newWidth; height = newHeight;
            display.resize(newWidth, newHeight, getResources().getDisplayMetrics().densityDpi);
            display.setSurface(fresh.getSurface());
            if (old != null) old.close();
        }
        lastBoard = null; candidateBoard = null; candidateBoardCount = 0; boardMissCount = 0;
        lastFullBoardScanAt = 0;
        lowConfidenceFrames = 0;
        invalidateAnalysis();
        tracker.resetPosition();
        syncAutomaticState();
        overlay.status("Ukuran layar berubah. Mencari papan kembali tanpa meminta posisi awal.");
    }

    private void capture() {
        if (!busy.compareAndSet(false, true)) return;
        Bitmap frame = null;
        synchronized (captureLock) {
            if (reader == null) { busy.set(false); return; }
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image != null) {
                    Image.Plane plane = image.getPlanes()[0];
                    ByteBuffer buffer = plane.getBuffer();
                    int rowStride = plane.getRowStride(), pixelStride = plane.getPixelStride();
                    int imageWidth = image.getWidth(), imageHeight = image.getHeight();
                    int paddedWidth = imageWidth + (rowStride - pixelStride * imageWidth) / pixelStride;
                    Bitmap padded = Bitmap.createBitmap(paddedWidth, imageHeight, Bitmap.Config.ARGB_8888);
                    padded.copyPixelsFromBuffer(buffer);
                    frame = Bitmap.createBitmap(padded, 0, 0, imageWidth, imageHeight);
                    padded.recycle();
                }
            } catch (Exception error) {
                long now = System.currentTimeMillis();
                if (overlay != null && now - lastCaptureDiagnosticAt > 2500) {
                    lastCaptureDiagnosticAt = now;
                    overlay.status("Gagal membaca frame: " + error.getClass().getSimpleName() + " — " + error.getMessage());
                }
            } finally { if (image != null) image.close(); }
        }
        if (frame == null) {
            emptyFrameCount++;
            long now = System.currentTimeMillis();
            if (overlay != null && now - lastCaptureDiagnosticAt > 3500) {
                lastCaptureDiagnosticAt = now;
                overlay.status("Belum menerima frame layar (" + emptyFrameCount + "). Hentikan sesi, mulai lagi, lalu setujui screen capture Android.");
            }
            busy.set(false); return;
        }
        emptyFrameCount = 0;
        Bitmap captured = frame;
        worker.submit(() -> {
            try { if (!paused) process(captured); }
            catch (Exception error) { if (overlay != null) overlay.status("Analisis gagal: " + error.getClass().getSimpleName() + " — " + error.getMessage()); }
            finally { captured.recycle(); busy.set(false); }
        });
    }

    private void process(Bitmap frame) throws Exception {
    long now = System.currentTimeMillis();
    boolean shouldScan = forceRelock
            || (lastBoard == null && (lastFullBoardScanAt == 0 || now - lastFullBoardScanAt >= 1200))
            || (lastBoard != null && now - lastFullBoardScanAt >= 2000);
    Rect detected = null;
    if (shouldScan) {
        lastFullBoardScanAt = now;
        detected = finder.find(frame);
        if (detected == null && forceRelock) forceRelock = false;
    } else if (candidateBoard != null) {
        detected = new Rect(candidateBoard);
    } else if (lastBoard != null) {
        detected = new Rect(lastBoard);
    }

    if (detected == null && lastBoard != null) detected = new Rect(lastBoard);
    if (detected == null) {
        if (now - lastRecognitionStatusAt > 1200) {
            lastRecognitionStatusAt = now;
            overlay.status("Mencari papan… pastikan seluruh papan terlihat.");
        }
        return;
    }

    Rect board = stabiliseBoard(detected);
    if (board == null) return;
    if (classifier == null) {
        overlay.status("Papan terkunci. Memuat model pengenal bidak…");
        classifier = new PieceClassifier(this);
    }

    PieceClassifier.Result result = classifier.classify(frame, board);
    syncAutomaticState();

    if (result.pieceCount < 4 || result.averageConfidence < 0.42f || result.lowConfidenceSquares > 22) {
        lowConfidenceFrames++;
        if (lowConfidenceFrames >= 8) {
            lastBoard = null;
            candidateBoard = null;
            candidateBoardCount = 0;
            lastFullBoardScanAt = 0;
            lowConfidenceFrames = 0;
        }
        if (now - lastRecognitionStatusAt > 1000) {
            lastRecognitionStatusAt = now;
            overlay.status("Papan terkunci · membaca bidak "
                    + String.format(java.util.Locale.US, "%.0f%%", result.averageConfidence * 100)
                    + " · kotak belum yakin " + result.lowConfidenceSquares);
        }
        return;
    }
    lowConfidenceFrames = 0;

    PositionTracker.Update update = tracker.observe(result);
    syncAutomaticState();
    if (update != null) {
        awaitingLegalPosition = false;
        handlePositionUpdate(update, board, result, frame.getWidth(), frame.getHeight());
    } else if (tracker.hasUnconfirmedPosition()) {
        // Prevent an outdated arrow from appearing on a newly changed board.
        if (!awaitingLegalPosition) {
            awaitingLegalPosition = true;
            overlay.clear();
            overlay.status("Perubahan papan terdeteksi · memverifikasi langkah legal…");
        }
        return;
    } else if (awaitingLegalPosition) {
        awaitingLegalPosition = false;
        if (tracker.isTurnKnown()) renderCachedAnalysis();
    }

    String fen = tracker.getFen();
    boolean retryFailedAnalysis = lastAnalysisFailedAt > 0
            && now - lastAnalysisFailedAt >= 10_000L;
    if (tracker.isOrientationKnown() && !tracker.isTurnKnown()
            && !fen.isEmpty() && (!fen.equals(lastAnalyzedFen) || retryFailedAnalysis) && update == null) {
        analyzeBothTurns(fen, board, frame.getWidth(), frame.getHeight(), result,
                "Giliran belum diketahui; menilai kedua kemungkinan");
    } else if (tracker.isOrientationKnown() && tracker.isTurnKnown()
            && !fen.isEmpty() && (!fen.equals(lastAnalyzedFen) || retryFailedAnalysis) && update == null) {
        analyzeCurrentPosition(fen, board, frame.getWidth(), frame.getHeight(),
                result, "Posisi stabil");
    }
}

/** Keeps the board lock through small movements and requires two frames for a large relocation. */
    private Rect stabiliseBoard(Rect found) {
        if (lastBoard == null || forceRelock) {
            lastBoard = new Rect(found);
            candidateBoard = null; candidateBoardCount = 0; forceRelock = false;
            overlay.status("Papan ditemukan dan dikunci. Membaca 64 kotak…");
            return new Rect(lastBoard);
        }
        int tolerance = Math.max(10, lastBoard.width() / 14);
        boolean near = Math.abs(found.left - lastBoard.left) <= tolerance
                && Math.abs(found.top - lastBoard.top) <= tolerance
                && Math.abs(found.width() - lastBoard.width()) <= tolerance
                && Math.abs(found.height() - lastBoard.height()) <= tolerance;
        if (near) {
            lastBoard = blend(lastBoard, found, 0.28f);
            candidateBoard = null; candidateBoardCount = 0;
            return new Rect(lastBoard);
        }
        if (candidateBoard != null && close(candidateBoard, found, tolerance)) candidateBoardCount++;
        else { candidateBoard = new Rect(found); candidateBoardCount = 1; }
        if (candidateBoardCount < 2) {
            overlay.status("Papan bergeser. Mengikuti posisi baru…");
            return null;
        }
        lastBoard = new Rect(found);
        candidateBoard = null; candidateBoardCount = 0;
        overlay.status("Posisi papan diperbarui. Kalibrasi tidak perlu diulang.");
        return new Rect(lastBoard);
    }

    private static boolean close(Rect a, Rect b, int tolerance) {
        return Math.abs(a.left - b.left) <= tolerance && Math.abs(a.top - b.top) <= tolerance
                && Math.abs(a.width() - b.width()) <= tolerance && Math.abs(a.height() - b.height()) <= tolerance;
    }

    private static Rect blend(Rect oldRect, Rect newRect, float weight) {
        return new Rect(Math.round(oldRect.left * (1f - weight) + newRect.left * weight),
                Math.round(oldRect.top * (1f - weight) + newRect.top * weight),
                Math.round(oldRect.right * (1f - weight) + newRect.right * weight),
                Math.round(oldRect.bottom * (1f - weight) + newRect.bottom * weight));
    }

    private void handlePositionUpdate(PositionTracker.Update update, Rect board,
                                      PieceClassifier.Result recognition,
                                      int frameWidth, int frameHeight) {
        // A new verified board invalidates every arrow from the previous board.
        if (overlay != null) overlay.clear();
        syncAutomaticState();
        if (!tracker.isOrientationKnown()) {
            invalidateAnalysis();
            overlay.status("Posisi terbaca, tetapi orientasi papan belum cukup yakin. Menunggu deteksi yang stabil…");
            return;
        }
        if (!tracker.isTurnKnown()) {
            String reason = update.resynchronised
                    ? "Posisi disinkronkan ulang; giliran belum dapat dipastikan."
                    : "Posisi tengah permainan tidak menyimpan informasi giliran.";
            analyzeBothTurns(update.fen, board, frameWidth, frameHeight, recognition, reason);
            return;
        }

        String turn = tracker.isWhiteToMove() ? "Putih" : "Hitam";
        if (update.move == null) {
            String prefix = update.recoveredPlies > 0
                    ? "Berhasil mengikuti " + update.recoveredPlies + " langkah legal otomatis"
                    : update.initialPosition ? "Posisi berhasil dibaca" : "Posisi papan disinkronkan ulang";
            String suffix = update.turnInferred
                    ? "\nGiliran otomatis berhasil dikenali dari perpindahan legal."
                    : "\nGiliran: " + turn + " · sisi pemain: " + (playerWhite ? "Putih" : "Hitam");
            lastPlayedFrom = "";
            lastPlayedTo = "";
            lastMoveSymbol = "";
            analyzeCurrentPosition(update.fen, board, frameWidth, frameHeight, recognition,
                    prefix + " · " + recognition.pieceCount + " bidak" + suffix);
            return;
        }

        String uci = update.move.toString();
        lastPlayedFrom = uci.substring(0, 2);
        lastPlayedTo = uci.substring(2, 4);
        lastMoveSymbol = "…";
        overlay.annotate(board, frameWidth, frameHeight, lastPlayedFrom, lastPlayedTo,
                "…", "", "", tracker.isWhiteBottom(), playerSideKnown);
        overlay.status("Langkah " + uci + " terbaca · giliran berikutnya " + turn
                + " · Stockfish sedang menilai…");

        final String beforeFen = update.before.getFen();
        final String afterFen = update.after.getFen();
        final long request = analysisGeneration.incrementAndGet();
        lastAnalyzedFen = afterFen;
        lastEvaluation = null;
        UciEngine active = engine;
        if (active != null) active.stopSearch();
        analysisWorker.getQueue().clear();

        submitLatestAnalysis(() -> {
            try {
                ensureEngine();
                if (request != analysisGeneration.get()) return;
                // Prioritise the live position so the recommended move is shown immediately.
                // Move grading is secondary; a slow pre-move search must never hide the current best move.
                UciEngine.Evaluation after = engine.analyze(afterFen, thinkMs,
                        (provisional, depth) -> showProvisional(request, afterFen, board,
                                frameWidth, frameHeight, provisional, depth));
                if (request != analysisGeneration.get()) return;
                lastEvaluation = after;
                lastAnalysisFailedAt = 0;
                lastAnalyzedBoard = new Rect(board);
                lastAnalyzedFrameWidth = frameWidth;
                lastAnalyzedFrameHeight = frameHeight;
                lastAnalysisPrefix = "Rekomendasi untuk posisi terbaru · Stockfish " + after.description;
                renderCachedAnalysis();

                try {
                    UciEngine.Evaluation before = engine.analyze(beforeFen, Math.max(250, thinkMs / 2));
                    if (request != analysisGeneration.get()) return;
                    MoveJudge.Result grade = MoveJudge.judge(update.before, update.after, update.move, before, after);
                    lastAnalysisPrefix = grade.symbol + " " + grade.name + " · langkah " + uci + "\n" + grade.note
                            + "\nCPL " + grade.centipawnsLost + " · Evaluasi posisi sekarang " + after.description;
                    lastMoveSymbol = grade.symbol;
                    renderCachedAnalysis();
                } catch (Exception gradingError) {
                    if (request == analysisGeneration.get()) {
                        lastAnalysisPrefix += "\nRekomendasi tersedia; penilaian langkah sebelumnya belum selesai: "
                                + gradingError.getMessage();
                        renderCachedAnalysis();
                    }
                }
            } catch (Exception error) {
                if (request == analysisGeneration.get()) {
                    lastAnalyzedFen = afterFen;
                    lastEvaluation = null;
                    lastAnalysisFailedAt = System.currentTimeMillis();
                    overlay.status("Posisi terbaca, Stockfish gagal: " + error.getMessage()
                            + "\nUCI: " + WasmEngineHost.stage() + " | self-test: " + engineHealth.get());
                    recoverEngineIfNeeded(error);
                }
            }
        });
    }

private void analyzeBothTurns(String fen, Rect board, int frameWidth, int frameHeight,
                               PieceClassifier.Result recognition, String prefix) {
    if (!tracker.isOrientationKnown() || tracker.isTurnKnown() || fen == null || fen.isEmpty()) return;
    final String placement = fen.split(" ")[0];
    final String whiteFen = placement + " w - - 0 1";
    final String blackFen = placement + " b - - 0 1";
    final long request = analysisGeneration.incrementAndGet();
    lastAnalyzedFen = tracker.getFen();
    lastAnalysisFailedAt = 0;
    lastEvaluation = null;
    unknownWhiteEvaluation = null;
    unknownBlackEvaluation = null;
    lastAnalyzedBoard = null;
    UciEngine active = engine;
    if (active != null) active.stopSearch();
    analysisWorker.getQueue().clear();
    overlay.status(prefix + "\nStockfish sedang menilai jika Putih atau Hitam yang jalan…");

    submitLatestAnalysis(() -> {
        UciEngine.Evaluation whiteEvaluation = null;
        UciEngine.Evaluation blackEvaluation = null;
        String whiteError = "", blackError = "";
        try {
            ensureEngine();
            if (request != analysisGeneration.get()) return;
            if (playerWhite) {
                try { whiteEvaluation = engine.analyze(whiteFen, thinkMs); }
                catch (Exception error) { whiteError = error.getMessage(); }
                if (request != analysisGeneration.get()) return;
                if (whiteEvaluation != null) {
                    unknownWhiteEvaluation = whiteEvaluation;
                    lastAnalyzedBoard = new Rect(board);
                    lastAnalyzedFrameWidth = frameWidth;
                    lastAnalyzedFrameHeight = frameHeight;
                    renderUnknownTurnAnalysis(prefix, whiteFen, blackFen);
                }
                try { blackEvaluation = engine.analyze(blackFen, thinkMs); }
                catch (Exception error) { blackError = error.getMessage(); }
            } else {
                try { blackEvaluation = engine.analyze(blackFen, thinkMs); }
                catch (Exception error) { blackError = error.getMessage(); }
                if (request != analysisGeneration.get()) return;
                if (blackEvaluation != null) {
                    unknownBlackEvaluation = blackEvaluation;
                    lastAnalyzedBoard = new Rect(board);
                    lastAnalyzedFrameWidth = frameWidth;
                    lastAnalyzedFrameHeight = frameHeight;
                    renderUnknownTurnAnalysis(prefix, whiteFen, blackFen);
                }
                try { whiteEvaluation = engine.analyze(whiteFen, thinkMs); }
                catch (Exception error) { whiteError = error.getMessage(); }
            }
            if (request != analysisGeneration.get()) return;
            if (whiteEvaluation == null && blackEvaluation == null) {
                throw new IllegalStateException("Analisis dua giliran gagal. Putih: " + whiteError + " · Hitam: " + blackError);
            }
            unknownWhiteEvaluation = whiteEvaluation;
            unknownBlackEvaluation = blackEvaluation;
            lastAnalyzedBoard = new Rect(board);
            lastAnalyzedFrameWidth = frameWidth;
            lastAnalyzedFrameHeight = frameHeight;
            lastAnalysisFailedAt = 0;
            renderUnknownTurnAnalysis(prefix, whiteFen, blackFen);
        } catch (Exception error) {
            if (request == analysisGeneration.get()) {
                lastAnalysisFailedAt = System.currentTimeMillis();
                overlay.status("Posisi terbaca, tetapi Stockfish belum berhasil menganalisis dua kemungkinan giliran: "
                        + error.getMessage());
                recoverEngineIfNeeded(error);
            }
        }
    });
}

private void renderUnknownTurnAnalysis(String prefix, String whiteFen, String blackFen) {
    if (overlay == null || !tracker.isOrientationKnown() || tracker.isTurnKnown()
            || lastAnalyzedBoard == null) return;
    UciEngine.Evaluation whiteEvaluation = unknownWhiteEvaluation;
    UciEngine.Evaluation blackEvaluation = unknownBlackEvaluation;
    String whiteMove = "", blackMove = "";
    if (whiteEvaluation != null) {
        com.github.bhlangonijr.chesslib.Board whiteBoard = new com.github.bhlangonijr.chesslib.Board();
        whiteBoard.loadFromFen(whiteFen);
        whiteMove = legalPvMove(whiteBoard, whiteEvaluation, 0);
    }
    if (blackEvaluation != null) {
        com.github.bhlangonijr.chesslib.Board blackBoard = new com.github.bhlangonijr.chesslib.Board();
        blackBoard.loadFromFen(blackFen);
        blackMove = legalPvMove(blackBoard, blackEvaluation, 0);
    }
    // Both-turn analysis is for diagnostics only. No speculative arrow may
    // masquerade as a recommendation while the actual turn is unknown.
    overlay.annotate(lastAnalyzedBoard, lastAnalyzedFrameWidth, lastAnalyzedFrameHeight,
            "", "", "", "", "", tracker.isWhiteBottom(), true);
    StringBuilder status = new StringBuilder(prefix);
    status.append("\nGiliran belum dipastikan — ChessLens tidak menebak.");
    status.append("\nJika Putih jalan: ").append(whiteMove.isEmpty() ? "rekomendasi belum tersedia" : whiteMove);
    if (whiteEvaluation != null) status.append(" ( ").append(whiteEvaluation.description).append(" )");
    status.append("\nJika Hitam jalan: ").append(blackMove.isEmpty() ? "rekomendasi belum tersedia" : blackMove);
    if (blackEvaluation != null) status.append(" ( ").append(blackEvaluation.description).append(" )");
    status.append("\nMenunggu transisi legal untuk memastikan giliran; panah disembunyikan.");
    overlay.status(status.toString());
}

private void analyzeCurrentPosition(String fen, Rect board, int frameWidth, int frameHeight,
                                    PieceClassifier.Result recognition, String prefix) {
    if (!tracker.isOrientationKnown() || !tracker.isTurnKnown()) return;
    final long request = analysisGeneration.incrementAndGet();
    lastAnalyzedFen = fen;
    lastAnalysisFailedAt = 0;
    lastEvaluation = null;
    lastAnalyzedBoard = null;
    UciEngine active = engine;
    if (active != null) active.stopSearch();
    analysisWorker.getQueue().clear();
    overlay.status(prefix + "\nStockfish menganalisis di latar belakang…");

    submitLatestAnalysis(() -> {
        try {
            ensureEngine();
            if (request != analysisGeneration.get()) return;
            UciEngine.Evaluation evaluation = engine.analyze(fen, thinkMs,
                    (provisional, depth) -> showProvisional(request, fen, board,
                            frameWidth, frameHeight, provisional, depth));
            if (request != analysisGeneration.get()) return;
            lastEvaluation = evaluation;
            lastAnalysisFailedAt = 0;
            lastAnalyzedBoard = new Rect(board);
            lastAnalyzedFrameWidth = frameWidth;
            lastAnalyzedFrameHeight = frameHeight;
            lastAnalysisPrefix = prefix + "\nEvaluasi " + evaluation.description
                    + " · Akurasi pengenalan "
                    + String.format(java.util.Locale.US, "%.0f%%", recognition.averageConfidence * 100);
            lastPlayedFrom = "";
            lastPlayedTo = "";
            lastMoveSymbol = "";
            renderCachedAnalysis();
        } catch (Exception error) {
            if (request == analysisGeneration.get()) {
                lastAnalysisFailedAt = System.currentTimeMillis();
                overlay.status(prefix + "\nStockfish belum siap: " + error.getMessage()
                        + "\nUCI: " + WasmEngineHost.stage() + " | self-test: " + engineHealth.get());
                recoverEngineIfNeeded(error);
            }
        }
    });
}

/** A temporary PV arrow is never promoted to a final recommendation without bestmove. */
private void showProvisional(long request, String fen, Rect board,
                             int frameWidth, int frameHeight,
                             UciEngine.Evaluation provisional, int depth) {
    if (request != analysisGeneration.get() || overlay == null || !tracker.isTurnKnown()) return;
    if (!fen.equals(tracker.getFen()) || tracker.hasUnconfirmedPosition()) return;
    long now = System.currentTimeMillis();
    if (now - lastProgressShownAt < 250L) return;
    lastProgressShownAt = now;
    com.github.bhlangonijr.chesslib.Board position = tracker.getBoardCopy();
    String legal = legalPvMove(position, provisional, 0);
    if (legal.isEmpty()) return;
    boolean ourTurn = tracker.isWhiteToMove() == playerWhite;
    String ownArrow = ourTurn && showMyBest ? legal : "";
    String oppositeArrow = !ourTurn && showOpponentBest ? legal : "";
    overlay.annotate(board, frameWidth, frameHeight, "", "", "", ownArrow,
            oppositeArrow, tracker.isWhiteBottom(), playerSideKnown);
    overlay.status("Saran sementara depth " + depth + ": " + legal
            + " · Evaluasi " + provisional.description
            + "\nMenunggu bestmove final dari Stockfish…");
}

/** Selects the user's move and the opponent's predicted reply from the same PV. */
private void renderCachedAnalysis() {
    UciEngine.Evaluation evaluation = lastEvaluation;
    Rect boardRect = lastAnalyzedBoard;
    if (evaluation == null || boardRect == null || overlay == null
            || !tracker.isOrientationKnown() || !tracker.isTurnKnown()) return;
    String currentFen = tracker.getFen();
    if (currentFen.isEmpty() || !currentFen.equals(lastAnalyzedFen)
            || tracker.hasUnconfirmedPosition()) return;

    com.github.bhlangonijr.chesslib.Board current = tracker.getBoardCopy();
    if (current == null || !current.getFen().equals(currentFen)) return;
    boolean whiteToMove = tracker.isWhiteToMove();
    boolean playerToMove = !playerSideKnown || whiteToMove == playerWhite;
    String legalBest = legalPvMove(current, evaluation, 0);
    // Draw only the best move for the ACTUAL current side. Never mix
    // the predicted reply (PV ply 1) with a live move recommendation.
    String myMove = playerToMove && showMyBest ? legalBest : "";
    String opponentMove = !playerToMove && showOpponentBest ? legalBest : "";
    overlay.annotate(boardRect, lastAnalyzedFrameWidth, lastAnalyzedFrameHeight,
            lastPlayedFrom, lastPlayedTo, lastMoveSymbol,
            myMove, opponentMove, tracker.isWhiteBottom(), playerSideKnown);

    StringBuilder status = new StringBuilder(lastAnalysisPrefix);
    status.append("\nGiliran: ").append(whiteToMove ? "Putih" : "Hitam");
    status.append(" · Langkah terbaik: ").append(legalBest.isEmpty() ? "belum tersedia" : legalBest);
    if (!legalBest.isEmpty() && ((playerToMove && !showMyBest)
            || (!playerToMove && !showOpponentBest)))
        status.append(" (panah dinonaktifkan)");
    status.append("\nPanah tunggal = asal → tujuan untuk giliran sekarang");
    overlay.status(status.toString());
}

/** Replays PV plies against the recognised board so only legal recommendations are drawn. */
private static String legalPvMove(com.github.bhlangonijr.chesslib.Board start,
                                  UciEngine.Evaluation evaluation, int targetPly) {
    if (start == null || targetPly < 0) return "";
    com.github.bhlangonijr.chesslib.Board position = new com.github.bhlangonijr.chesslib.Board();
    position.loadFromFen(start.getFen());
    for (int ply = 0; ply <= targetPly; ply++) {
        String uci = evaluation.moveAt(ply);
        if (uci == null || uci.isEmpty()) return "";
        com.github.bhlangonijr.chesslib.move.Move legal = null;
        for (com.github.bhlangonijr.chesslib.move.Move candidate : position.legalMoves()) {
            if (uci.equalsIgnoreCase(candidate.toString())) {
                legal = candidate;
                break;
            }
        }
        if (legal == null) return "";
        if (ply == targetPly) return legal.toString();
        if (!position.doMove(legal)) return "";
    }
    return "";
}

/** Reset only for transport errors, never for an uncertain FEN or failed CV. */
private void recoverEngineIfNeeded(Exception error) {
    String reason = error.getMessage() == null ? "" : error.getMessage().toLowerCase(java.util.Locale.ROOT);
    if (!reason.contains("readyok") && !reason.contains("uciok")
            && !reason.contains("bestmove") && !reason.contains("worker")
            && !reason.contains("webview") && !reason.contains("respons")) return;
    long now = System.currentTimeMillis();
    if (now - lastEngineRecoveryAt < 20_000L) return;
    lastEngineRecoveryAt = now;
    UciEngine previous = engine;
    engine = null;
    if (previous != null) previous.close();
    CountDownLatch reset = new CountDownLatch(1);
    main.post(() -> {
        try { if (WasmEngineHost.isServiceOwned()) WasmEngineHost.restartServiceHost(this); }
        catch (Exception ignored) { }
        finally { reset.countDown(); }
    });
    try { reset.await(8, TimeUnit.SECONDS); }
    catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
}

private void ensureEngine() throws Exception {
        if (engine != null) return;
        try {
            engine = new UciEngine();
        } catch (Exception first) {
            if (!WasmEngineHost.isServiceOwned()) throw first;
            engineHealth.set("restart UCI: " + first.getMessage());
            CountDownLatch reset = new CountDownLatch(1);
            AtomicReference<Exception> resetError = new AtomicReference<>();
            main.post(() -> {
                try { WasmEngineHost.restartServiceHost(this); }
                catch (Exception error) { resetError.set(error); }
                finally { reset.countDown(); }
            });
            if (!reset.await(8, TimeUnit.SECONDS))
                throw new IllegalStateException("Timeout restart WebView", first);
            if (resetError.get() != null) throw resetError.get();
            engine = new UciEngine();
        }
    }

    @Override public void onDestroy() {
        main.removeCallbacks(ticker);
        synchronized (captureLock) {
            if (display != null) { display.release(); display = null; }
            if (reader != null) { reader.close(); reader = null; }
        }
        if (projection != null) { MediaProjection closing = projection; projection = null; closing.stop(); }
        analysisGeneration.incrementAndGet();
        if (engine != null) engine.stopSearch();
        analysisWorker.shutdownNow();
        worker.shutdownNow();
        lastEvaluation = null;
        lastAnalyzedBoard = null;
        if (engine != null) { engine.close(); engine = null; }
        if (classifier != null) { classifier.close(); classifier = null; }
        if (overlay != null) { overlay.dispose(); overlay = null; }
        WasmEngineHost.releaseService();
        super.onDestroy();
    }
}
