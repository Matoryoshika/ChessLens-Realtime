#!/usr/bin/env python3
"""Static source guard. Real ChessLib logic is verified by Android unit tests."""
from pathlib import Path
base=Path(__file__).resolve().parents[1]
def source(p): return (base/p).read_text(encoding='utf-8')
tracker=source('app/src/main/java/id/chesslens/realtime/vision/PositionTracker.java')
service=source('app/src/main/java/id/chesslens/realtime/ScreenService.java')
arrow=source('app/src/main/java/id/chesslens/realtime/overlay/ArrowCanvas.java')
tests=source('app/src/test/java/id/chesslens/realtime/vision/PositionTrackerTest.java')
gradle=source('app/build.gradle')
assert "versionName '0.9.4'" in gradle and 'versionCode 12' in gradle
assert 'findMatchingTwoPlies(currentBoard, placement)' in tracker
assert 'recoverFromStart(placement)' in tracker
assert 'UNMATCHED_STABLE_FRAMES = 6' in tracker
assert 'hasUnconfirmedPosition()' in tracker
assert 'startingSetup = currentBoard == null && START_PLACEMENT.equals(placement)' in tracker
assert 'String legalBest = legalPvMove(current, evaluation, 0);' in service
assert 'findMatchingMove(currentBoard, placement)' in tracker
assert 'awaitingLegalPosition' in service
assert 'moveAt(ply)' in service
assert 'activeMove = valid(myMove) ? myMove : valid(opponentMove) ? opponentMove : ""' in arrow
assert 'playerToMove && showMyBest' in service
assert 'drawLine(start.x, start.y, end.x, end.y, paint)' in arrow
assert 'firstObservedE4AndE6CanRecoverTurnFromLegalOpening' in tests
assert 'differentMoveThanEngineSuggestionStillContinuesTracking' in tests
assert 'recoveringTwoSkippedMovesMustPreserveTurn' in tests
assert 'shortNoisySequenceMustNotDestroyKnownTurn' in tests
print('PASS v0.9.4 tracking guards, legal move independence, bootstrap, one centered arrow')
