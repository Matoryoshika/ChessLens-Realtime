# v0.9.4 validation

- Python static guards check branch/arrow behavior, not correctness of chess rules.
- Android Gradle JUnit tests execute ChessLib tracking cases, including alternate legal moves and two-ply recovery.
- Java UCI smoke test uses a fake Worker and does **not** prove real Stockfish WebAssembly on a phone.
- Real Android test must verify the WASM Worker lifecycle, legal moves after a different choice, live HUD arrows, and long sessions.
