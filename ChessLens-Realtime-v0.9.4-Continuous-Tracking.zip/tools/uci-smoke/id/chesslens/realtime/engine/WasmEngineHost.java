package id.chesslens.realtime.engine;

import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Test-only fake bridge; never packaged into the Android app. */
public final class WasmEngineHost {
    private static final LinkedBlockingQueue<String> OUTPUT = new LinkedBlockingQueue<>();
    public static void awaitReady(long timeoutMs) { }
    public static long generation() { return 1L; }
    public static void clearOutput() { OUTPUT.clear(); }
    public static void send(String command) throws IOException {
        if ("uci".equals(command)) OUTPUT.offer("uciok");
        else if ("isready".equals(command)) OUTPUT.offer("readyok");
        else if (command.startsWith("go ")) {
            OUTPUT.offer("info depth 8 seldepth 12 multipv 1 score cp 34 nodes 1200 pv e2e4 e7e5 g1f3 b8c6");
            OUTPUT.offer("info depth 9 seldepth 14 multipv 1 score cp 41 nodes 2400 pv e2e4 e7e5 g1f3 b8c6 f1c4");
            OUTPUT.offer("bestmove e2e4 ponder e7e5");
        }
    }
    public static String pollLine(long timeoutMs) throws Exception {
        return OUTPUT.poll(timeoutMs, TimeUnit.MILLISECONDS);
    }
    public static String nextLine(long timeoutMs) throws Exception {
        String line = pollLine(timeoutMs);
        if (line == null) throw new IOException("No fake UCI output");
        return line;
    }
}
