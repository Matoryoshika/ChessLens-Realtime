import id.chesslens.realtime.engine.UciEngine;

public final class TestUciEngine {
    public static void main(String[] args) throws Exception {
        UciEngine engine = new UciEngine();
        final int[] reports = {0};
        UciEngine.Evaluation result = engine.analyze("startpos", 700, (preview, depth) -> {
            if (depth < 1 || preview.bestMove.isEmpty()) throw new AssertionError("Invalid preview");
            reports[0]++;
        });
        if (reports[0] == 0) throw new AssertionError("No provisional PV received");
        if (!"e2e4".equals(result.bestMove)) throw new AssertionError("bestmove=" + result.bestMove);
        if (!"e7e5".equals(result.moveAt(1))) throw new AssertionError("PV=" + result.principalVariation);
        if (!"f1c4".equals(result.moveAt(4))) throw new AssertionError("PV=" + result.principalVariation);
        if (!"+0.41".equals(result.description)) throw new AssertionError("score=" + result.description);
        System.out.println("PASS: UCI bestmove + deepest PV + score: " + result.principalVariation);
    }
}
