# ChessLens Realtime v0.9.3 — Overlay Engine Architecture Diagnostics

## Verified source changes
- Version name 0.9.3, version code 11, ARM64 APK only.
- Stockfish WASM WebView ownership moves from the Activity to the foreground ScreenService for Overlay. A tiny non-touchable application overlay holds the WebView while other apps are in front.
- Resettable host bootstrap and per-epoch callbacks prevent stale WebView/Worker output from contaminating subsequent sessions.
- UCI handshake and active search share a process-wide lock between Practice and Overlay.
- The Overlay performs an actual on-device Stockfish opening-position self-test *before* processing screenshots; reports its result to the HUD. This is NOT an Android CI mock.
- One bounded WebView restart for initial handshake failures and rate-limited recovery after UCI/Worker transport errors.
- Early provisional PV arrow, clearly marked as temporary until final bestmove arrives. Move legality is validated by ChessLib.
- Starting-position occupancy recognition is conservative: a board after 1.e4 is no longer replaced with the full starting FEN.
- King-based orientation is only inferred for kings near opposite home ranks; no arbitrary king-rank heuristic for all endgames.
- Existing transparent arrows, optional Stockfish download, CV, and Papan Latihan are retained.

## Important limitations
- The ONNX recognition model has **not** been retrained for every external chess UI. A wrong piece map can still block reliable FEN or arrows.
- On-device WebView/Worker startup and uninterrupted background execution must be validated on real Android hardware. CI's UCI mock does not validate real Stockfish readiness.
- Captured positions starting midgame cannot reliably reconstruct side-to-move, castling rights, en passant, or entire move history from a screenshot alone.
- No promise of complete error-free game-review labels or Chess.com-equivalent evaluations.

## Test protocol
1. Start v0.9.3 Overlay and read **Stockfish Overlay siap (FEN awal → ...)**; this tests real background Worker before CV. If it fails, record the UCI diagnostic stage shown on screen.
2. Test the practice board on the same device, without Overlay running; compare results.
3. Test exact starting position, after 1.e4 (Black to move), middlegame, in-check FEN, flipped board.
4. Check that provisional arrow is labeled "sementara" and final arrow matches legal bestmove from the current FEN.
5. Watch memory, heat, and repeated on/off sessions. Send diagnostic logs if `readyok` fails.
