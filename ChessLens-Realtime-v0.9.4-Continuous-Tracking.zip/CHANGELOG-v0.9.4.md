# ChessLens Realtime v0.9.4 — Continuous Tracking & Centered Arrows

Compared with v0.9.3:

1. **Continue after any legal move**, including a move that differs from the Stockfish best move. The tracker follows observed legal positions, not bestmove expectations.
2. **Recover one or two missing plies** from the last verified ChessLib board, retaining actual side-to-move, rights and FEN metadata whenever legal sequences are unambiguous.
3. **Opening bootstrap** can infer the correct turn from the exact layout after one or two opening moves (e.g. 1.e4 or 1.e4 e6), without guessing turn in arbitrary middlegames.
4. **Protect turn history** from transient vision noise. A six-frame unmatched-position threshold replaces four; changes affecting only 1–2 squares require twelve stable frames before forced resynchronisation.
5. **Hide stale arrows** while a changed board is awaiting legal validation.
6. **Use one centered arrow** for the best legal move of the actual side to move, not an additional predicted reply. Softer lines, compact arrowhead, small origin dot, no badges or oversized rings.
7. **Unknown-turn analysis remains diagnostic only**; it never draws a speculative recommendation arrow.
8. **Reduce capture polling interval** from 500ms to 400ms, and board rediscovery from 2.5s to 2s.
9. Add ChessLib regression tests for alternative moves, two-ply recovery, opening bootstrap, and temporary bad detections.

Known limitations: exact side-to-move cannot generally be inferred from an arbitrary FEN without prior move history; a run of >2 missed plies may still need resynchronisation. Computer-vision accuracy remains dependent on model/theme. No APK or Android device test has been performed locally; GitHub Actions validates the Android build after upload. The existing Stockfish 18 on-demand design is retained.
