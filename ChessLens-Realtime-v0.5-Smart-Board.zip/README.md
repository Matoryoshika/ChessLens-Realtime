# ChessLens Realtime v0.5 — Smart Board Recognition

ChessLens Realtime v0.5 memperbarui deteksi area papan dan penentuan orientasi sisi putih/hitam. Aplikasi tetap berupa satu APK kecil; Stockfish 18 Full WASM diunduh dari dalam aplikasi setelah persetujuan pengguna.

## Perubahan v0.5

- BoardFinder mencari papan 8×8 pada rentang ukuran yang lebih luas, termasuk papan yang lebih kecil pada split-screen dan papan yang menyentuh tepi layar.
- BoardFinder tidak lagi me-recycle bitmap sumber ketika gambar tidak perlu di-resize.
- Orientasi putih/hitam diperkirakan dari kontras visual bidak dan posisi relatif bidak di layar.
- Floating HUD menampilkan sisi yang terdeteksi: **Putih di bawah** atau **Hitam di bawah**.
- Tombol **Sisi** pada HUD menjadi koreksi manual jika deteksi warna/orientasi tidak yakin.
- Panah langkah dan rekomendasi tetap menggunakan pemetaan koordinat yang mengikuti orientasi papan (normal atau terbalik 180°).
- Kalibrasi menolak posisi tengah permainan agar tracker tidak menganggap posisi tersebut sebagai posisi awal dan menghasilkan deteksi langkah palsu.

## Cara mencoba

1. Instal APK v0.5.
2. Buka ChessLens dan pastikan izin Floating Overlay aktif.
3. Buka aplikasi catur yang akan dianalisis.
4. Mulai sesi tangkap layar dan setujui dialog MediaProjection Android.
5. Untuk kalibrasi pertama, tampilkan posisi awal standar dengan 32 bidak sebelum langkah pertama.
6. ChessLens mencoba menentukan orientasi secara otomatis dan menampilkan hasilnya pada tombol **Sisi**.
7. Jika sisi salah atau tidak yakin, tekan **Sisi** untuk mengganti antara Putih di bawah dan Hitam di bawah.
8. Tekan **Kalibrasi**. Setelah berhasil, langkah legal akan dilacak dan dianalisis Stockfish.

## Batasan yang perlu diketahui

- Versi ini tetap memakai template visual yang dipelajari dari posisi awal standar. Kalibrasi overlay **belum mendukung posisi tengah permainan secara langsung**. Mulai capture sebelum langkah pertama. Jika sudah berada di tengah permainan, tracker harus dikalibrasi ulang dari posisi awal; dukungan impor FEN ke overlay belum tersedia.
- Deteksi papan memakai pola kotak terang/gelap, bukan model computer vision universal. Tema papan yang sangat polos, 3D, transparan, animasi, atau tertutup panel dapat membuat deteksi gagal.
- Deteksi orientasi menggunakan kontras warna bidak. Jika tema bidak atau efek layar membuat warna tidak jelas, gunakan tombol **Sisi** sebagai koreksi manual.
- BoardFinder dan orientasi perlu diuji pada screenshot nyata dari perangkat pengguna. Lulus build tidak membuktikan deteksi bekerja pada semua aplikasi catur.
- MediaProjection memerlukan persetujuan Android untuk setiap sesi. Aplikasi tidak boleh melewati layar `FLAG_SECURE` dari aplikasi lain.
- Gambar layar diproses di perangkat dan tidak diunggah ke server.
- Simbol `!!`, `★`, `!`, `!?`, `?!`, `?`, `??` merupakan klasifikasi heuristik, bukan label resmi Chess.com.

## Struktur utama

```
app/src/main/java/id/chesslens/realtime/
├── MainActivity.java
├── ScreenService.java
├── engine/
│   ├── EngineInstaller.java
│   ├── WasmEngineHost.java
│   ├── UciEngine.java
│   └── MoveJudge.java
├── vision/
│   ├── BoardFinder.java
│   └── PositionTracker.java
├── overlay/
│   ├── FloatingOverlay.java
│   └── ArrowCanvas.java
└── practice/PracticeActivity.java
```

## Build

Gunakan workflow `.github/workflows/build-android-v0.5.yml`. Workflow mengambil source ZIP `ChessLens-Realtime-v0.5-Smart-Board.zip`, mengunduh paket Stockfish 18.0.5 dari npm registry untuk mem-pin SHA-256, lalu membangun APK debug yang tetap tidak membundel engine WASM.

APK yang dibuat oleh GitHub Actions harus diuji pada HP fisik. Pengujian minimum: board detection, orientasi putih/hitam, koreksi tombol Sisi, kalibrasi posisi awal, deteksi satu langkah legal, panah pada kedua orientasi, serta tombol jeda/stop.

## Lisensi

Kode aplikasi yang ditulis untuk proyek ini memakai MIT (lihat `LICENSE`). Stockfish 18 berlisensi GPL-3.0; distribusi dan perubahan komponen Stockfish harus mengikuti kewajiban lisensinya. chesslib memakai Apache-2.0.
