# ChessLens Realtime v0.5 — Build & QA checklist

## Implementasi source
- [x] BoardFinder memperluas rentang ukuran kandidat dan mengizinkan board menyentuh tepi layar.
- [x] BoardFinder menghindari recycle bitmap input jika tidak ada resize.
- [x] PositionTracker memperkirakan warna bidak dari kontras lokal dan centroid posisi di layar.
- [x] Orientasi yang tidak meyakinkan ditandai sebagai tidak andal; tidak dipaksakan menjadi hasil otomatis.
- [x] Floating HUD menyediakan tombol koreksi sisi Putih/Hitam.
- [x] ArrowCanvas tetap memetakan kotak secara 180° saat Hitam berada di bawah.
- [x] Kalibrasi menolak posisi yang tidak menyerupai posisi awal standar.
- [x] Nomor versi aplikasi dinaikkan ke versionCode 4 / versionName 0.5.0.

## Pemeriksaan yang belum dapat diklaim tanpa perangkat
- [ ] Full Gradle/Android build pada GitHub Actions.
- [ ] BoardFinder diuji pada screenshot Chess.com / Lichess dari HP pengguna.
- [ ] Orientasi otomatis diuji pada Putih di bawah dan Hitam di bawah.
- [ ] Tombol Sisi diuji sebagai override manual.
- [ ] Kalibrasi 32 bidak dan deteksi langkah legal diuji pada permainan nyata.
- [ ] Panah langkah dan rekomendasi diverifikasi pada kedua orientasi.
- [ ] Kinerja, suhu, dan penggunaan baterai diuji selama sesi panjang.

Penting: keberhasilan kompilasi APK tidak sama dengan keberhasilan computer vision pada semua tema atau aplikasi catur.
