package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

/** Native system overlay: touch-through arrows and movable, user-controlled HUD. */
public final class FloatingOverlay {
  private final WindowManager wm;
  private final ArrowCanvas arrows;
  private final LinearLayout panel;
  private final TextView status,small;
  private final Button toggle;
  private final Button orientationButton;
  private final WindowManager.LayoutParams params;
  private float touchX,touchY;private int beginX,beginY;
  public FloatingOverlay(Context ctx,Runnable calibrate,Runnable togglePause,Runnable flipOrientation,Runnable stop){
    wm=(WindowManager)ctx.getSystemService(Context.WINDOW_SERVICE);
    arrows=new ArrowCanvas(ctx);
    WindowManager.LayoutParams canvasParams=new WindowManager.LayoutParams(-1,-1,
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_SECURE,PixelFormat.TRANSLUCENT);
    canvasParams.gravity=Gravity.TOP|Gravity.LEFT;
    wm.addView(arrows,canvasParams);
    panel=new LinearLayout(ctx);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(18,13,18,11);
    GradientDrawable backdrop=new GradientDrawable();backdrop.setColor(0xee111a2c);backdrop.setCornerRadius(24);panel.setBackground(backdrop);
    status=new TextView(ctx);status.setText("♟ ChessLens: belum dikalibrasi");status.setTextSize(13);status.setTextColor(Color.WHITE);status.setMaxLines(5);
    status.setMinWidth(dp(ctx,235));panel.addView(status);
    small=new TextView(ctx);small.setText("Panah warna = langkah • biru putus = rekomendasi");small.setTextSize(10);small.setTextColor(0xffb7c5d9);panel.addView(small);
    LinearLayout controls=new LinearLayout(ctx);controls.setOrientation(LinearLayout.HORIZONTAL);
    Button cal=button(ctx,"Kalibrasi",calibrate);controls.addView(cal);
    orientationButton=button(ctx,"Sisi: Putih bawah",flipOrientation);controls.addView(orientationButton);
    toggle=button(ctx,"Jeda",togglePause);controls.addView(toggle);
    Button close=button(ctx,"Stop",stop);controls.addView(close);panel.addView(controls);
    params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_SECURE,PixelFormat.TRANSLUCENT);
    params.gravity=Gravity.TOP|Gravity.LEFT;params.x=14;params.y=90;
    wm.addView(panel,params);
    // Drag by long touch on status label; buttons remain interactive.
    status.setOnTouchListener((v,event)->{
      if(event.getAction()==MotionEvent.ACTION_DOWN){touchX=event.getRawX();touchY=event.getRawY();beginX=params.x;beginY=params.y;return true;}
      if(event.getAction()==MotionEvent.ACTION_MOVE){params.x=beginX+(int)(event.getRawX()-touchX);params.y=beginY+(int)(event.getRawY()-touchY);wm.updateViewLayout(panel,params);return true;}
      return true;
    });
  }
  private static Button button(Context c,String title,Runnable callback){
    Button b=new Button(c);b.setText(title);b.setTextSize(11);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);
    b.setPadding(dp(c,8),0,dp(c,8),0);b.setOnClickListener(v->callback.run());return b;
  }
  private static int dp(Context c,int d){return (int)(d*c.getResources().getDisplayMetrics().density+.5f);}
  public void status(String s){status.post(()->status.setText(s));}
  public void setPaused(boolean paused){toggle.post(()->toggle.setText(paused?"Lanjut":"Jeda"));}
  public void setOrientation(boolean whiteBottom,boolean manual){
    String label=whiteBottom?"Putih ↓":"Hitam ↓";
    orientationButton.post(()->orientationButton.setText(label+(manual?" *":"")));
  }
  public void annotate(Rect r,String f,String t,String symbol,String best,boolean white){arrows.post(()->arrows.update(r,f,t,symbol,best,white));}
  public void clear(){arrows.post(()->arrows.update(null,"","","","",true));}
  public void dispose(){try{wm.removeView(arrows);}catch(Exception ignored){}try{wm.removeView(panel);}catch(Exception ignored){}}
}
