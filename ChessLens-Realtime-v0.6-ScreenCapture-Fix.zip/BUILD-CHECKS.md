# ChessLens Realtime v0.6 — Build & QA

## Source checks
- [x] Removed FLAG_SECURE from fullscreen transparent arrow overlay.
- [x] Removed FLAG_SECURE from Floating HUD panel.
- [x] MediaProjection null-frame and image decode failures now produce HUD diagnostics.
- [x] BoardFinder exposes candidate score and size for diagnosis.
- [x] Version updated to 0.6.0 / versionCode 5.

## Must test on the user's phone
- [ ] Android system screenshot works while the ChessLens HUD is visible.
- [ ] MediaProjection receives frames from a chess app and from Gallery displaying a flat chessboard image.
- [ ] HUD reports frame dimensions instead of remaining stuck.
- [ ] BoardFinder locates boards in supported flat, axis-aligned themes.
- [ ] Starting-position calibration and White/Black orientation work.
- [ ] Midgame position support remains out of scope until FEN/manual board calibration is added.
