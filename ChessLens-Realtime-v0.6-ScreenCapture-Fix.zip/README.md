# ChessLens Realtime v0.6 — Screen Capture Fix & Diagnostics

## Important v0.6 fix

The previous v0.5 FloatingOverlay applied `FLAG_SECURE` to a fullscreen transparent ArrowCanvas window and to the HUD panel. Android treats secure windows as protected from screenshots and screen capture. Because the ArrowCanvas covers the full display, this could prevent screenshots and interfere with MediaProjection seeing the chessboard beneath it. v0.6 removes `FLAG_SECURE` from both overlay windows.

This only removes ChessLens's own screenshot protection. It does not bypass secure screens from other applications.

## Diagnostics

- ScreenService now reports if MediaProjection has not delivered any frame.
- Frame decoding exceptions are shown in the HUD instead of being silently ignored.
- If a frame arrives but BoardFinder cannot locate an 8×8 pattern, the HUD reports frame dimensions and candidate score.
- If a board is found, the HUD reports the detected board dimensions before calibration.

## Usage

1. Install v0.6 and start a new MediaProjection session.
2. Approve Android's screen-capture dialog.
3. Open a chessboard or a flat image of a chessboard.
4. Check the HUD status: it should report that screen capture is active, then either a frame was received or an exact capture error.
5. For template calibration, the current tracker still requires the standard starting position with all 32 pieces visible before the first move.
6. Take a normal Android screenshot while ChessLens is active. ChessLens's own overlay no longer blocks screenshots.

## Current limitations

- BoardFinder detects axis-aligned square checkerboard patterns. A strongly perspective-skewed real-life photograph may still need manual quadrilateral calibration, which is not yet implemented.
- PositionTracker learns piece templates from the standard initial position; arbitrary midgame setup / FEN calibration is not yet implemented.
- Build success does not prove that all device screen-capture pipelines and board themes work. Test on the target phone.

## Build

Use `.github/workflows/build-android-v0.6.yml`. It unpacks `ChessLens-Realtime-v0.6-ScreenCapture-Fix.zip`, downloads pinned Stockfish 18.0.5 WASM assets from npm, patches their runtime URLs and SHA-256 values, builds the debug APK, verifies the signature, and checks that the engine is not bundled in the installer.
