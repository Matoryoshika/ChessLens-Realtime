package id.chesslens.realtime.engine;

import java.io.IOException;
import java.util.Locale;

/** UCI client backed by Stockfish 18 WebAssembly running in Android WebView. */
public final class UciEngine implements AutoCloseable {
    private boolean closed;

    public static final class Evaluation {
        public final int cp;
        public final String bestMove, description;
        public Evaluation(int cp, String bestMove, String description) {
            this.cp = cp;
            this.bestMove = bestMove;
            this.description = description;
        }
    }

    public UciEngine() throws Exception { this(null); }

    /** The old path argument is ignored for compatibility; WASM assets are served by WebView. */
    @Deprecated public UciEngine(String ignoredExecutablePath) throws Exception {
        WasmEngineHost.awaitReady(45_000);
        WasmEngineHost.clearOutput();
        send("uci");
        waitFor("uciok", 60_000);
        send("setoption name Threads value 1");
        send("setoption name Hash value 16");
        send("setoption name MultiPV value 1");
        send("isready");
        waitFor("readyok", 30_000);
    }

    private void send(String command) throws IOException {
        if (closed) throw new IOException("Sesi engine sudah ditutup.");
        WasmEngineHost.send(command);
    }

    private void waitFor(String expected, long timeoutMs) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            String line = WasmEngineHost.nextLine(Math.max(1, deadline - System.currentTimeMillis()));
            if (expected.equals(line.trim())) return;
        }
        throw new IOException("Stockfish tidak mengirim " + expected + ".");
    }

    public synchronized Evaluation analyze(String fen, int milliseconds) throws Exception {
        if (closed) throw new IOException("Sesi engine sudah ditutup.");
        send("position fen " + fen);
        send("go movetime " + Math.max(100, Math.min(10_000, milliseconds)));
        int cp = 0;
        String best = "";
        String notation = "0.00";
        long deadline = System.currentTimeMillis() + Math.max(15_000L, milliseconds + 10_000L);
        while (System.currentTimeMillis() < deadline) {
            String line = WasmEngineHost.nextLine(Math.max(1, deadline - System.currentTimeMillis()));
            if (line.startsWith("info ")) {
                String[] tokens = line.trim().split("\\s+");
                for (int i = 0; i + 2 < tokens.length; i++) {
                    if (!"score".equals(tokens[i])) continue;
                    try {
                        if ("cp".equals(tokens[i + 1])) {
                            cp = Integer.parseInt(tokens[i + 2]);
                            notation = String.format(Locale.US, "%+.2f", cp / 100.0);
                        } else if ("mate".equals(tokens[i + 1])) {
                            int mate = Integer.parseInt(tokens[i + 2]);
                            cp = mate > 0 ? 20_000 - mate * 10 : -20_000 - mate * 10;
                            notation = "M" + mate;
                        }
                    } catch (NumberFormatException ignored) { }
                }
            }
            if (line.startsWith("bestmove ")) {
                String[] tokens = line.trim().split("\\s+");
                best = tokens.length > 1 ? tokens[1] : "";
                break;
            }
        }
        if (best.isEmpty()) throw new IOException("Stockfish WASM tidak mengirim bestmove.");
        return new Evaluation(cp, best, notation);
    }

    @Override public void close() {
        // Stop any in-flight search but keep the WebView worker alive for the next analysis session.
        if (!closed) {
            try { WasmEngineHost.send("stop"); } catch (Exception ignored) { }
        }
        closed = true;
    }
}
