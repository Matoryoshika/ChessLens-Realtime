package id.chesslens.realtime.vision;

import android.graphics.Bitmap;
import android.graphics.Rect;
import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.move.Move;
import java.util.*;

/**
 * Learns piece silhouettes from the standard starting position, then matches
 * only legal next positions. It also estimates board orientation from piece
 * color contrast; uncertain estimates are deliberately rejected.
 */
public final class PositionTracker {
  private static final String START = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR";
  private static final int N = 12;
  private static final float COLOR_THRESHOLD = 6.5f;
  private final Map<Character, List<float[]>> models = new HashMap<>();
  private final Board board = new Board();
  private boolean calibrated = false, whiteBottom = true;
  private String candidateMove = "";
  private int stableCount = 0;

  private static final class Features { float[][] cells = new float[64][]; }

  public static final class OrientationResult {
    public final boolean whiteBottom;
    public final boolean reliable;
    public final float whiteMeanRow, blackMeanRow, confidence;
    public final int whiteSamples, blackSamples;
    OrientationResult(boolean whiteBottom, boolean reliable, float whiteMeanRow, float blackMeanRow,
                      float confidence, int whiteSamples, int blackSamples) {
      this.whiteBottom = whiteBottom; this.reliable = reliable;
      this.whiteMeanRow = whiteMeanRow; this.blackMeanRow = blackMeanRow;
      this.confidence = confidence; this.whiteSamples = whiteSamples; this.blackSamples = blackSamples;
    }
    public String label() { return whiteBottom ? "Putih di bawah" : "Hitam di bawah"; }
  }

  public static final class Detected {
    public final Board before, after;
    public final Move move;
    Detected(Board before, Board after, Move move) { this.before = before; this.after = after; this.move = move; }
  }

  public boolean isReady() { return calibrated; }
  public String getFen() { return board.getFen(); }
  public boolean isWhiteBottom() { return whiteBottom; }

  public void reset() {
    calibrated = false; models.clear(); board.loadFromFen(new Board().getFen());
    candidateMove = ""; stableCount = 0;
  }

  /**
   * Estimates orientation from the screen positions of visually light and dark
   * pieces. This works best with the normal starting position. During a game,
   * pieces may cross the center; a low-confidence result must use manual override.
   */
  public OrientationResult detectOrientation(Bitmap image, Rect rect) {
    if (image == null || image.isRecycled() || rect == null || rect.width() < 160 || rect.height() < 160) {
      return new OrientationResult(true, false, 0, 0, 0, 0, 0);
    }

    double whiteRowSum = 0, whiteWeightSum = 0, blackRowSum = 0, blackWeightSum = 0;
    int whiteCount = 0, blackCount = 0;
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        float contrast = pieceContrast(image, rect, row, col);
        if (contrast > COLOR_THRESHOLD) {
          double weight = contrast - COLOR_THRESHOLD;
          whiteRowSum += row * weight; whiteWeightSum += weight; whiteCount++;
        } else if (contrast < -COLOR_THRESHOLD) {
          double weight = -contrast - COLOR_THRESHOLD;
          blackRowSum += row * weight; blackWeightSum += weight; blackCount++;
        }
      }
    }

    if (whiteCount < 2 || blackCount < 2 || whiteWeightSum <= 0 || blackWeightSum <= 0) {
      return new OrientationResult(true, false, 0, 0, 0, whiteCount, blackCount);
    }
    float whiteMean = (float) (whiteRowSum / whiteWeightSum);
    float blackMean = (float) (blackRowSum / blackWeightSum);
    float separation = whiteMean - blackMean;
    float balance = Math.min(1f, Math.min(whiteCount, blackCount) / 5f);
    float confidence = Math.min(1f, Math.abs(separation) / 3f) * balance;
    boolean reliable = Math.abs(separation) >= 1.15f && confidence >= 0.35f;
    return new OrientationResult(separation > 0, reliable, whiteMean, blackMean,
        confidence, whiteCount, blackCount);
  }

  /**
   * A conservative check that the screen shows the standard initial position.
   * This tracker learns silhouettes from that position; accepting a middlegame
   * here would silently seed the wrong FEN and produce false move detections.
   */
  public boolean looksLikeStartingPosition(Bitmap image, Rect rect) {
    if (image == null || image.isRecycled() || rect == null || rect.width() < 160) return false;
    int homePieces = 0, middlePieces = 0;
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        if (Math.abs(pieceContrast(image, rect, row, col)) < 5.0f) continue;
        if (row <= 1 || row >= 6) homePieces++;
        else middlePieces++;
      }
    }
    return homePieces >= 12 && middlePieces <= 4;
  }

  /** The screenshot must show the standard starting position (all 32 pieces). */
  public boolean calibrate(Bitmap image, Rect rect, boolean whiteAtBottom) {
    if (image == null || image.isRecycled() || rect == null || rect.width() < 160 || rect.height() < 160) return false;
    this.whiteBottom = whiteAtBottom;
    models.clear();
    Features features = read(image, rect);
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        int screen = row * 8 + col;
        int canonical = (whiteBottom ? row : 7 - row) * 8 + (whiteBottom ? col : 7 - col);
        char piece = START.charAt(canonical);
        models.computeIfAbsent(piece, key -> new ArrayList<>()).add(features.cells[screen]);
      }
    }
    board.loadFromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    calibrated = true; candidateMove = ""; stableCount = 0;
    return true;
  }

  /** Returns a move only after consecutive matching frames, rejecting sliding animations. */
  public Detected inspect(Bitmap image, Rect rect) {
    if (!calibrated || image == null || image.isRecycled() || rect == null) return null;
    Features features = read(image, rect);
    double base = cost(board.getFen(), features);
    Move bestMove = null;
    double best = base;
    for (Move move : board.legalMoves()) {
      Board copy = copy(board);
      if (!copy.doMove(move)) continue;
      double candidateCost = cost(copy.getFen(), features);
      if (candidateCost < best) { best = candidateCost; bestMove = move; }
    }
    if (bestMove == null || base - best < 1300 || (base > 0 && (base - best) / base < 0.035)) {
      candidateMove = ""; stableCount = 0; return null;
    }
    String id = bestMove.toString();
    if (!candidateMove.equals(id)) { candidateMove = id; stableCount = 1; return null; }
    stableCount++;
    if (stableCount < 2) return null;
    Board previous = copy(board);
    board.doMove(bestMove);
    Board next = copy(board);
    candidateMove = ""; stableCount = 0;
    return new Detected(previous, next, bestMove);
  }

  private float pieceContrast(Bitmap bitmap, Rect bounds, int row, int col) {
    float cell = bounds.width() / 8f;
    float left = bounds.left + col * cell, top = bounds.top + row * cell;
    float background = 0;
    background += patchLuma(bitmap, left + cell * 0.08f, top + cell * 0.08f, cell * 0.055f);
    background += patchLuma(bitmap, left + cell * 0.92f, top + cell * 0.08f, cell * 0.055f);
    background += patchLuma(bitmap, left + cell * 0.08f, top + cell * 0.92f, cell * 0.055f);
    background += patchLuma(bitmap, left + cell * 0.92f, top + cell * 0.92f, cell * 0.055f);
    background /= 4f;
    float center = patchLuma(bitmap, left + cell * 0.28f, top + cell * 0.28f, cell * 0.44f);
    return center - background;
  }

  private float patchLuma(Bitmap bitmap, float left, float top, float size) {
    int x0 = clamp(Math.round(left), bitmap.getWidth());
    int y0 = clamp(Math.round(top), bitmap.getHeight());
    int x1 = clamp(Math.round(left + size), bitmap.getWidth());
    int y1 = clamp(Math.round(top + size), bitmap.getHeight());
    if (x1 <= x0 || y1 <= y0) return luma(bitmap, x0, y0);
    long total = 0; int count = 0;
    int stepX = Math.max(1, (x1 - x0) / 4), stepY = Math.max(1, (y1 - y0) / 4);
    for (int y = y0; y < y1; y += stepY) {
      for (int x = x0; x < x1; x += stepX) { total += luma(bitmap, x, y); count++; }
    }
    return count == 0 ? 0 : total / (float) count;
  }

  private static Board copy(Board source) { Board result = new Board(); result.loadFromFen(source.getFen()); return result; }

  private double cost(String fen, Features actual) {
    String placement = fen.split(" ")[0];
    char[] expected = new char[64]; int index = 0;
    for (char value : placement.toCharArray()) {
      if (value == '/') continue;
      if (value >= '1' && value <= '8') {
        for (int j = 0; j < value - '0'; j++) expected[index++] = '.';
      } else expected[index++] = value;
    }
    double result = 0;
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        int screen = row * 8 + col;
        int canonical = (whiteBottom ? row : 7 - row) * 8 + (whiteBottom ? col : 7 - col);
        List<float[]> templates = models.get(expected[canonical]);
        if (templates == null || templates.isEmpty()) { result += 3000; continue; }
        float[] actualCell = actual.cells[screen]; double minimum = Double.POSITIVE_INFINITY;
        for (float[] template : templates) {
          double distance = 0;
          for (int j = 0; j < actualCell.length; j++) distance += Math.abs(actualCell[j] - template[j]);
          if (distance < minimum) minimum = distance;
        }
        result += minimum;
      }
    }
    return result;
  }

  private Features read(Bitmap bitmap, Rect bounds) {
    Features features = new Features();
    float cell = bounds.width() / 8f;
    int width = bitmap.getWidth(), height = bitmap.getHeight();
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        float x = bounds.left + col * cell, y = bounds.top + row * cell;
        float background = (luma(bitmap, clamp((int) (x + cell * .09f), width), clamp((int) (y + cell * .09f), height))
            + luma(bitmap, clamp((int) (x + cell * .91f), width), clamp((int) (y + cell * .09f), height))
            + luma(bitmap, clamp((int) (x + cell * .09f), width), clamp((int) (y + cell * .91f), height))
            + luma(bitmap, clamp((int) (x + cell * .91f), width), clamp((int) (y + cell * .91f), height))) / 4f;
        float[] output = new float[N * N];
        for (int a = 0; a < N; a++) for (int b = 0; b < N; b++) {
          float px = x + cell * (0.14f + (b + .5f) * .72f / N);
          float py = y + cell * (0.14f + (a + .5f) * .72f / N);
          output[a * N + b] = luma(bitmap, clamp((int) px, width), clamp((int) py, height)) - background;
        }
        features.cells[row * 8 + col] = output;
      }
    }
    return features;
  }

  private static int clamp(int value, int limit) { return Math.min(limit - 1, Math.max(0, value)); }
  private static int luma(Bitmap bitmap, int x, int y) {
    int color = bitmap.getPixel(x, y);
    return ((color >> 16 & 255) * 77 + (color >> 8 & 255) * 150 + (color & 255) * 29) >> 8;
  }
}
