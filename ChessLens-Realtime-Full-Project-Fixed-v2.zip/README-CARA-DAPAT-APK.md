# Cara membuat APK ChessLens Realtime

1. Upload file `ChessLens-Realtime-Full-Project-Fixed.zip` ke ROOT repository GitHub (jangan masuk ke `.github` atau `.github/workflows`).
2. Buka `.github/workflows/build-android.yml`, pilih Edit, lalu ganti seluruh isinya dengan file `build-android.yml` yang disediakan terpisah pada paket ini. Commit.
3. Workflow akan mengekstrak ZIP di root, mengunduh Stockfish 18, dan mencoba build APK.
4. Jika sukses, buka Actions → run terbaru → Artifacts → `ChessLens-Realtime-APK`.

Struktur ZIP ini sudah memiliki `app/`, `settings.gradle`, `build.gradle`, dan `gradle.properties` pada root.

Catatan: keberhasilan build belum membuktikan seluruh fungsi deteksi papan/overlay bekerja sempurna di setiap perangkat; uji di HP setelah APK dihasilkan.
