Stockfish executable is NOT included in the source ZIP.
The GitHub Actions workflow downloads official Stockfish 18, verifies its SHA256, and copies
it here as libstockfish.so before building. Stockfish is GPL-3.0-or-later.
Source: https://github.com/official-stockfish/Stockfish/tree/sf_18
