package id.chesslens.realtime;

import android.app.Activity;
import android.content.*;
import android.media.projection.MediaProjectionManager;
import android.media.projection.MediaProjectionConfig;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import id.chesslens.realtime.practice.PracticeActivity;

/** Launcher: explicit recording permission, on-device training board, and simple controls. */
public final class MainActivity extends Activity {
  private static final int CAPTURE=100;
  private CheckBox whiteBottom;
  private SeekBar think;
  private TextView duration;
  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    if(Build.VERSION.SDK_INT>=21)getWindow().setStatusBarColor(0xff14213c);
    ScrollView sc=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
    int pad=(int)(22*getResources().getDisplayMetrics().density);
    body.setPadding(pad,pad,pad,pad);body.setBackgroundColor(0xfff3f6fb);sc.addView(body);setContentView(sc);
    TextView title=label("♟ ChessLens Realtime",26,0xff0e203b);body.addView(title);
    body.addView(label("Stockfish 18 · panel mengambang · analisis di perangkat",14,0xff51627a));
    body.addView(label("MODE PRAKTIK",16,0xff102743));
    body.addView(label("Gunakan papan latihan, Editor FEN, simpan posisi, dan Riwayat, tanpa merekam layar.",14,0xff405068));
    button(body,"Buka Papan Latihan + FEN + Riwayat",()->startActivity(new Intent(this,PracticeActivity.class)));
    body.addView(label("MODE OVERLAY LAYAR",16,0xff102743));
    body.addView(label("Bekerja di atas aplikasi lain menggunakan izin Android. Mulai dari posisi awal 32 buah, lalu kalibrasi setelah membuka papan. Gunakan saat studi atau analisis yang diperbolehkan.",14,0xff405068));
    whiteBottom=new CheckBox(this);whiteBottom.setText("Bidak putih di bawah");whiteBottom.setChecked(getPreferences(0).getBoolean("white",true));
    whiteBottom.setOnCheckedChangeListener((v,on)->getPreferences(0).edit().putBoolean("white",on).apply());body.addView(whiteBottom);
    duration=label("Waktu berpikir: 700 ms / posisi",14,0xff30435a);body.addView(duration);
    think=new SeekBar(this);think.setMax(6);think.setProgress(getPreferences(0).getInt("think",2));body.addView(think);
    think.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar b,int p,boolean user){duration.setText("Waktu berpikir: "+thinkMs(p)+" ms / posisi");if(user)getPreferences(0).edit().putInt("think",p).apply();}
      public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
    });duration.setText("Waktu berpikir: "+thinkMs(think.getProgress())+" ms / posisi");
    button(body,"1 · Izinkan overlay sistem",()->{
      if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
      else toast("Izin overlay sudah diberikan");
    });
    button(body,"2 · Mulai tangkap layar + analisis",()->{
      if(!Settings.canDrawOverlays(this)){toast("Aktifkan izin overlay dulu");return;}
      MediaProjectionManager manager=getSystemService(MediaProjectionManager.class);
      Intent request=Build.VERSION.SDK_INT>=34
        ?manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        :manager.createScreenCaptureIntent();
      startActivityForResult(request,CAPTURE);
    });
    button(body,"Hentikan analisis layar",()->stopService(new Intent(this,ScreenService.class)));
    body.addView(label("Panah penuh menunjukkan langkah terakhir; panah biru putus-putus adalah rekomendasi berikutnya. Simbol !! adalah perkiraan heuristik, bukan penilaian resmi Chess.com. Android wajib meminta persetujuan tangkap layar per sesi. Tidak dapat menangkap konten yang dilindungi.",13,0xff5b6a7f));
  }
  private int thinkMs(int pos){return new int[]{200,400,700,1000,1500,2200,3000}[Math.max(0,Math.min(pos,6))];}
  private TextView label(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,10,0,14);return v;}
  private void button(LinearLayout root,String title,Runnable action){Button b=new Button(this);b.setAllCaps(false);b.setText(title);root.addView(b);b.setOnClickListener(v->action.run());}
  private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request!=CAPTURE)return;
    if(result!=RESULT_OK||data==null){toast("Izin tangkap layar tidak diberikan");return;}
    Intent service=new Intent(this,ScreenService.class);
    service.putExtra("result",result);service.putExtra("data",data);
    service.putExtra("white",whiteBottom.isChecked());service.putExtra("thinkMs",thinkMs(think.getProgress()));
    if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
    moveTaskToBack(true);
  }
}
