import id.chesslens.realtime.overlay.ArrowGeometry;

public final class TestArrowGeometry {
    private static void eq(float actual, float expected) {
        if (Math.abs(actual - expected) > 0.002f)
            throw new AssertionError("Expected " + expected + ", got " + actual);
    }
    private static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        // 8x8 800px; white bottom: h1 is light, king e1, rook a1.
        float[] a1 = ArrowGeometry.center(0, 400, 800, 800, "a1", true);
        float[] c1 = ArrowGeometry.center(0, 400, 800, 800, "c1", true);
        eq(a1[0],50); eq(a1[1],1150);
        eq(c1[0],250); eq(c1[1],1150);
        float[] c3=ArrowGeometry.center(0,400,800,800,"c3",true);
        float[] b5=ArrowGeometry.center(0,400,800,800,"b5",true);
        eq(c3[0],250); eq(c3[1],950);
        eq(b5[0],150); eq(b5[1],750);
        float[] h1Black = ArrowGeometry.center(0, 400, 800, 800, "h1", false);
        eq(h1Black[0],50); eq(h1Black[1],450);
        float[] a8Black = ArrowGeometry.center(0, 400, 800, 800, "a8", false);
        eq(a8Black[0],750); eq(a8Black[1],1150);
        // One-rank accidental lock; align should find true checker at y=440.
        final int trueY = 440;
        ArrowGeometry.PixelReader synthetic = (x, y) -> {
            if (x < 0 || x >= 800 || y < trueY || y >= trueY + 800) return 0xff242322;
            int row=(y-trueY)/100, col=x/100;
            return ((row + col)&1)==0 ? 0xffa8a8a8 : 0xff323232;
        };
        int[] fixed=ArrowGeometry.align(synthetic,800,1450,0,340,800,800);
        check(Math.abs(fixed[1]-trueY)<=10, "one-rank drift corrected: "+fixed[1]);
        int[] stable=ArrowGeometry.align(synthetic,800,1450,0,trueY,800,800);
        check(Math.abs(stable[1]-trueY)<=3, "correct rectangle preserved: "+stable[1]);
        // A screen without a checkerboard must NOT trigger arbitrary relocation.
        int[] flat=ArrowGeometry.align((x,y)->0xff555555,800,1450,0,340,800,800);
        check(flat[1]==340, "flat background must not move arrow");
        System.out.println("PASS v1.0 arrow geometry: origin/destination centres, black flip, drift + stale-board guard");
    }
}
