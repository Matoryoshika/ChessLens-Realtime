#!/usr/bin/env python3
"""v1.0 regression guard: keep engine/tracking while fixing arrow positioning."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(s): return (root/s).read_text(encoding="utf-8")
arrow=read("app/src/main/java/id/chesslens/realtime/overlay/ArrowCanvas.java")
engine=read("app/src/main/java/id/chesslens/realtime/engine/UciEngine.java")
service=read("app/src/main/java/id/chesslens/realtime/ScreenService.java")
geom=read("app/src/main/java/id/chesslens/realtime/overlay/ArrowGeometry.java")
gradle=read("app/build.gradle")
assert "versionName '1.0'" in gradle and 'versionCode 13' in gradle
assert 'float[] point = ArrowGeometry.center' in arrow
assert 'canvas.drawLine(start.x, start.y, end.x, end.y, paint);' in arrow
assert 'ArrowGeometry.align(frame::getPixel' in service
assert 'handlePositionUpdate(update, arrowBoard,' in service
assert 'analyzeCurrentPosition(fen, arrowBoard,' in service
assert 'lowConfidenceFrames == 1) overlay.clear()' in service
assert '|| !recognitionValid' in service
assert 'renderCachedAnalysis()' in service
assert 'moveAt(ply)' in service
assert 'findMatchingTwoPlies(currentBoard, placement)' in read('app/src/main/java/id/chesslens/realtime/vision/PositionTracker.java')
assert 'analyze(String fen' in engine
assert 'PixelReader' in geom and 'checkerScore' in geom
print('PASS v1.0 correct centering, corrected checker geometry, stale-arrow cleanup, tracking preserved')
