package id.chesslens.realtime.overlay;

/**
 * Exact 8x8 square-centre geometry and an optional image-based correction for
 * board-detection drift. No Android dependencies: safe to regression-test with
 * synthetic boards. The correction changes ONLY the arrow rectangle, never the
 * ChessLib position, Stockfish input or the classifier crop.
 */
public final class ArrowGeometry {
    private ArrowGeometry() { }

    @FunctionalInterface
    public interface PixelReader { int pixel(int x, int y); }

    /** Coordinate in the image/overlay, NOT an offset from the piece glyph. */
    public static float[] center(float left, float top, float width, float height,
                                 String square, boolean whiteBottom) {
        if (square == null || !square.matches("[a-h][1-8]"))
            throw new IllegalArgumentException("Invalid chess square: " + square);
        int file = square.charAt(0) - 'a';
        int row = '8' - square.charAt(1);
        if (!whiteBottom) { file = 7 - file; row = 7 - row; }
        return new float[] { left + (file + 0.5f) * (width / 8f),
                             top + (row + 0.5f) * (height / 8f) };
    }

    /**
     * Snap an approximate 8x8 board rectangle to the checker pattern.
     * The sliding board detector can intermittently lock ~one rank too high;
     * that makes an a1-c1 arrow render on a2-c2 even with correct centre math.
     *
     * Only accept a relocation if checker-pattern evidence improves clearly;
     * otherwise retain the previously detected rectangle. Never modify FEN.
     */
    public static int[] align(PixelReader pixels, int frameWidth, int frameHeight,
                              int left, int top, int boardWidth, int boardHeight) {
        int[] fallback = {left, top, boardWidth, boardHeight};
        if (pixels == null || frameWidth < 96 || frameHeight < 96
                || boardWidth < 96 || boardHeight < 96) return fallback;
        if (left < 0 || top < 0 || left + boardWidth > frameWidth
                || top + boardHeight > frameHeight) return fallback;

        final float cell = Math.min(boardWidth, boardHeight) / 8f;
        final int coarseStep = Math.max(4, Math.round(cell * 0.14f));
        final int limitX = Math.round(cell * 0.65f);
        final int limitY = Math.round(cell * 1.20f);
        final double baseline = checkerScore(pixels, frameWidth, frameHeight,
                left, top, boardWidth, boardHeight);
        double best = baseline;
        int bestX = left, bestY = top;

        for (int iy = -Math.round(limitY / (float) coarseStep);
                 iy <= Math.round(limitY / (float) coarseStep); iy++) {
            for (int ix = -Math.round(limitX / (float) coarseStep);
                     ix <= Math.round(limitX / (float) coarseStep); ix++) {
                int dx = ix * coarseStep, dy = iy * coarseStep;
                int x = left + dx, y = top + dy;
                if (x < 0 || y < 0 || x + boardWidth > frameWidth
                        || y + boardHeight > frameHeight) continue;
                double score = checkerScore(pixels, frameWidth, frameHeight,
                        x, y, boardWidth, boardHeight);
                if (score > best) { best = score; bestX = x; bestY = y; }
            }
        }
        // Refine around the strongest alignment at small increments.
        int refineStep = Math.max(1, coarseStep / 4);
        int coarseX = bestX, coarseY = bestY;
        for (int iy = -Math.round(coarseStep / (float) refineStep);
                 iy <= Math.round(coarseStep / (float) refineStep); iy++) {
            for (int ix = -Math.round(coarseStep / (float) refineStep);
                     ix <= Math.round(coarseStep / (float) refineStep); ix++) {
                int dx = ix * refineStep, dy = iy * refineStep;
                int x = coarseX + dx, y = coarseY + dy;
                if (x < 0 || y < 0 || x + boardWidth > frameWidth
                        || y + boardHeight > frameHeight
                        || Math.abs(x - left) > limitX
                        || Math.abs(y - top) > limitY) continue;
                double score = checkerScore(pixels, frameWidth, frameHeight,
                        x, y, boardWidth, boardHeight);
                if (score > best) { best = score; bestX = x; bestY = y; }
            }
        }
        // A large checker contrast by itself is insufficient: a one-rank-shifted
        // checkerboard also scores strongly. Require a meaningful improvement.
        // Preserve the original detection when the board theme is ambiguous.
        if (best < 14.0 || best - baseline < Math.max(5.0, Math.abs(baseline) * 0.10))
            return fallback;
        return new int[] {bestX, bestY, boardWidth, boardHeight};
    }

    private static double checkerScore(PixelReader pixels, int frameWidth, int frameHeight,
                                       int x, int y, int w, int h) {
        double total = 0, squares = 0;
        double[] rows = new double[8];
        for (int rank = 0; rank < 8; rank++) {
            double light = 0, dark = 0;
            for (int file = 0; file < 8; file++) {
                int a = sample(pixels, x, y, w, h, file, rank, .22f, .22f);
                int b = sample(pixels, x, y, w, h, file, rank, .78f, .22f);
                int c = sample(pixels, x, y, w, h, file, rank, .22f, .78f);
                int d = sample(pixels, x, y, w, h, file, rank, .78f, .78f);
                double middle = (a + b + c + d
                        - Math.min(Math.min(a, b), Math.min(c, d))
                        - Math.max(Math.max(a, b), Math.max(c, d))) / 2.0;
                if (((rank + file) & 1) == 0) light += middle;
                else dark += middle;
                squares++;
            }
            rows[rank] = (light - dark) / 4.0;
            total += rows[rank];
        }
        double mean = total / 8.0;
        double var = 0;
        for (double diff : rows) var += (diff - mean) * (diff - mean);
        // Penalize rows that do not belong to the checkerboard, e.g. the black
        // UI band immediately above the chess board after an off-by-one lock.
        double score = Math.abs(mean) - 0.10 * Math.sqrt(var / 8.0);
        // A checker pattern has a periodic ambiguity: a row of squares may
        // score almost as well 15px off. Snap against the seven INTERNAL row
        // and column boundaries, using pixels just across each border.
        // This targets the physical square centre, not just the correct rank.
        float cellX = w / 8f, cellY = h / 8f;
        int marginX = Math.max(2, Math.round(cellX * 0.046f));
        int marginY = Math.max(2, Math.round(cellY * 0.046f));
        double horizontal = 0, vertical = 0;
        int countHorizontal = 0, countVertical = 0;
        for (int row = 1; row < 8; row++) {
            int edgeY = y + Math.round(row * cellY);
            for (int file = 0; file < 8; file++) {
                int px = x + Math.round((file + .20f) * cellX);
                horizontal += Math.abs(luma(pixels.pixel(px, edgeY - marginY))
                        - luma(pixels.pixel(px, edgeY + marginY)));
                countHorizontal++;
            }
        }
        for (int file = 1; file < 8; file++) {
            int edgeX = x + Math.round(file * cellX);
            for (int row = 0; row < 8; row++) {
                int py = y + Math.round((row + .20f) * cellY);
                vertical += Math.abs(luma(pixels.pixel(edgeX - marginX, py))
                        - luma(pixels.pixel(edgeX + marginX, py)));
                countVertical++;
            }
        }
        return score + .23 * (horizontal / countHorizontal + vertical / countVertical);
    }

    private static int luma(int rgb) {
        return (((rgb >>> 16) & 255) * 77
                + ((rgb >>> 8) & 255) * 150 + (rgb & 255) * 29) >> 8;
    }

    private static int sample(PixelReader pixels, int x, int y, int w, int h,
                              int file, int rank, float fx, float fy) {
        int px = x + Math.round((file + fx) * (w / 8f));
        int py = y + Math.round((rank + fy) * (h / 8f));
        int rgb = pixels.pixel(px, py);
        return luma(rgb);
    }
}
