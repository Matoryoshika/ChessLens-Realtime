# ChessLens Realtime v1.0 — Arrow Anchor & Alignment Fix

## Changed
- **One accurate arrow**: tail originates at the exact centre of the source piece's square; arrow tip reaches the exact centre of the destination square (UCI a1c1 maps to the a1 and c1 centres).
- **Checkerboard-aware overlay alignment**: a lightweight local checkerboard-pattern refinement corrects transient board-rectangle shifts, including the one-rank drift observed in screenshots. Applied **only to the arrow rectangle** — never to computer vision, FEN, ChessLib, Stockfish, or turn tracking.
- **No stale arrows**: if classifier reports implausible board recognition (e.g. 100% confidence with very few pieces), the old arrow is immediately removed and queued evaluations cannot restore it until the board is valid again.
- **Move arrows with the board**: while FEN stays valid, refresh the arrow position when the visual chessboard moves or is re-locked without restarting the engine.
- **Better origin marker**: small high-contrast origin dot exactly at the source square centre and small destination-centre dot.
- **Preserved engine/tracking**: same Stockfish 18 WASM architecture, same ChessLib and ONNX model, same v0.9.4 multi-ply recovery and UCI logic.

## Checks
- Run `python3 tools/test_v10_features.py` and `python3 tools/test_v094_features.py`.
- Run standalone Java source geometry smoke-test: `javac -d /tmp/chesslens-arrows app/src/main/java/id/chesslens/realtime/overlay/ArrowGeometry.java tools/arrow-geometry-test/TestArrowGeometry.java && java -cp /tmp/chesslens-arrows TestArrowGeometry`.
- The GitHub Actions workflow builds an ARM64 APK and runs the Android/ChessLib unit tests. Runtime alignment still requires confirmation on a real Android phone.
