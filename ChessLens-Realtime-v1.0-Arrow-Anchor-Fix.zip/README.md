# ChessLens Realtime v1.0

Android ARM64 chess position recognition and locally downloaded Stockfish 18 WASM engine, with a practice board and an opt-in screen-capture overlay.

## What's new in v1.0

Since v0.9.3, the Overlay attaches its 2×2 non-touchable WebView Worker to the foreground `ScreenService`, rather than relying on an Activity that is backgrounded when another chess app is shown. Stockfish sessions are serialized across modes, with an independent Android on-device self-test, diagnostic UCI stages, engine restart on transport failure, and provisional (clearly labeled) PV arrows before final `bestmove`. v0.9.4 strengthened legal move tracking; v1.0 keeps it and fixes overlay arrow alignment and stale arrows. The position tracker no longer guesses a starting board after a pawn has moved to the center.

See `CHANGELOG-v1.0.md` and `tools/README-v094-tests.md` for exact changes, tests, and limitations.

## Build using GitHub Actions

1. Upload `ChessLens-Realtime-v1.0-Arrow-Anchor-Fix.zip` to repository root. The filename can end in `(1)` or `(2)`; the workflow selects the most recently committed matching ZIP.
2. Upload `build-android-v1.0.yml` to `.github/workflows/`. Suffixes such as `(1)` are accepted by `push.paths` glob.
3. Commit both files on `main`. The workflow automatically builds an ARM64 debug APK and uploads `ChessLens-Realtime-v1.0-ARM64-APK`.

The workflow downloads the pinned ONNX piece classifier, Stockfish 18 WASM package, verifies assets and runs static checks, JVM UCI parser smoke tests and Android/ChessLib unit tests. **Android device validation is still required**: a successful build and fake UCI smoke test cannot prove the real WebView Worker stays responsive on your phone.

## Usage and diagnostics

Install and permit floating overlay plus Android screen capture. Before classifying captured frames, `ScreenService` sends a real starting FEN to Stockfish; HUD should show `Stockfish Overlay siap (FEN awal → ...)`. If this fails, note the UCI stage (`Worker`, `uciok`, `readyok`) and compare to Papan Latihan **with Overlay stopped**. Check behavior on initial position, after 1.e4, middlegame, check and flipped boards.

In midgame, a screenshot alone cannot reveal the side to move, all castling/en-passant rights or move history; this application does not invent those facts. The recognition model has not been retrained for every 3D piece theme, and panah/analysis still depend on a correct observed board.

Use on games and platforms only when assistance is permitted.

## v1.0: Accurate arrow geometry
- Exact source-piece centre to destination-square centre, including a1→c1 and c3→b5.
- Calibrate the overlay arrow rectangle to the visible 8×8 checkerboard if detection drifts vertically.
- Hide old arrows immediately while board recognition is invalid; restore valid recommendations automatically.
- Keep the proven v0.9.4 Stockfish and tracking unchanged.
- Run `python tools/test_v10_features.py` and `gradle testDebugUnitTest` for regression checks.
