# Cara build APK ChessLens Realtime v0.4

1. Upload `ChessLens-Realtime-v0.4-WASM-Engine.zip` to the root of `Matoryoshika/ChessLens-Realtime` (Add file → Upload files).
2. Upload `build-android-wasm.yml` into `.github/workflows/` (Add file → Upload files). Keep the old workflows for now; this one has a unique filename.
3. Commit the changes.
4. Open Actions → **Build ChessLens Realtime v0.4 (Stockfish 18 WASM)**.
5. Wait until all steps are green. Download the `ChessLens-Realtime-v0.4-APK` artifact.

The installer APK is small. On first launch the app downloads the full single-threaded Stockfish 18 WASM engine (about 113 MB) inside the app. It includes a Cancel button. No second APK or storage permission is required for the engine download.

Important: this APK build still needs a physical-device test. The Android build alone does not prove that the WebView worker runs correctly on every phone.
