package id.chesslens.realtime;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import id.chesslens.realtime.engine.EngineInstaller;
import id.chesslens.realtime.engine.WasmEngineHost;
import id.chesslens.realtime.practice.PracticeActivity;

/** First-run setup, on-demand Stockfish installation, and the ChessLens dashboard. */
public final class MainActivity extends Activity {
    private static final int CAPTURE = 100;
    private static final int NOTIFICATIONS = 101;
    private static final String SETUP_PREFS = "chesslens_setup";
    private static final String NOTIFICATION_ASKED = "notification_permission_asked";
    private static final String SKIP_OVERLAY = "skip_overlay_for_now";
    private static final String MOBILE_DATA_ACCEPTED = "mobile_data_download_accepted";

    private SharedPreferences setupPrefs;
    private LinearLayout body;
    private TextView statusText;
    private ProgressBar downloadProgress;
    private boolean downloadRunning = false;
    private boolean dashboardVisible = false;
    private boolean waitingForNotificationResult = false;
    private CheckBox whiteBottom;
    private SeekBar think;
    private TextView duration;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setupPrefs = getSharedPreferences(SETUP_PREFS, MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 21) getWindow().setStatusBarColor(0xff102a43);
        if (EngineInstaller.isInstalled(this)) renderDashboard();
        else renderSetup();
    }

    @Override protected void onResume() {
        super.onResume();
        if (downloadRunning) return;
        if (EngineInstaller.isInstalled(this)) {
            if (!dashboardVisible) renderDashboard();
            if (body != null) WasmEngineHost.attach(this, body);
            return;
        }
        if (dashboardVisible) renderSetup();
        if (Settings.canDrawOverlays(this) || setupPrefs.getBoolean(SKIP_OVERLAY, false)) {
            continueFirstRunSetup();
        }
    }

    private void renderSetup() {
        dashboardVisible = false;
        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(28), dp(22), dp(28));
        body.setBackgroundColor(0xfff3f6fb);
        scroll.addView(body);
        setContentView(scroll);

        addText("♟ ChessLens Realtime", 27, 0xff102a43, true);
        addText("Persiapan pertama kali", 18, 0xff176b72, true);
        addText("Selesaikan panduan izin. ChessLens akan mengunduh Stockfish 18 langsung di dalam aplikasi—tidak perlu memasang APK atau engine kedua.", 14, 0xff465b70, false);

        addStep("1 · Floating Overlay", Settings.canDrawOverlays(this)
                ? "✓ Izin overlay sudah aktif"
                : "Diperlukan agar panel ChessLens dapat tampil di atas aplikasi lain.");
        if (!Settings.canDrawOverlays(this)) {
            addButton("Izinkan Floating Overlay", () -> {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            });
            addButtonSecondary("Lewati sementara (mode latihan tetap tersedia)", () -> {
                setupPrefs.edit().putBoolean(SKIP_OVERLAY, true).apply();
                continueFirstRunSetup();
            });
        }

        boolean notificationGranted = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        addStep("2 · Notifikasi", notificationGranted
                ? "✓ Izin notifikasi tersedia atau tidak diperlukan pada versi Android ini."
                : "Disarankan agar status proses analisis layar terlihat jelas.");
        if (Build.VERSION.SDK_INT >= 33 && !notificationGranted) {
            addButtonSecondary("Izinkan notifikasi sekarang", () -> requestNotificationPermission());
        }

        addStep("3 · Mesin Stockfish 18 Full", "Dipilih otomatis sesuai arsitektur prosesor. File disimpan di penyimpanan internal aplikasi dan diverifikasi sebelum dijalankan.");
        statusText = addText(downloadRunning ? "Mengunduh dan menyiapkan Stockfish…" : "Menunggu izin awal…", 14, 0xff334e68, true);
        downloadProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        downloadProgress.setMax(100);
        downloadProgress.setProgress(0);
        body.addView(downloadProgress, new LinearLayout.LayoutParams(-1, dp(12)));
        if (downloadRunning) {
            statusText.setText("Download Stockfish sedang berjalan. Kamu bisa membatalkannya kapan saja.");
            addButtonSecondary("Batalkan unduhan", this::cancelEngineDownload);
        } else if (EngineInstaller.isInstalled(this)) {
            statusText.setText("✓ Stockfish 18 Full sudah siap.");
        } else {
            addText("Stockfish 18 Full (single-threaded WASM) akan diunduh sekitar 113 MB langsung di dalam aplikasi. Setelah selesai, engine tersimpan dan analisis dapat berjalan offline. Unduhan bisa dibatalkan kapan saja.", 12, 0xff627d98, false);
            addButtonSecondary("Buka papan latihan tanpa Stockfish dulu", () -> startActivity(new Intent(this, PracticeActivity.class)));
            if (Settings.canDrawOverlays(this) || setupPrefs.getBoolean(SKIP_OVERLAY, false)) {
                addButton("Lanjutkan persiapan dan unduh Stockfish", this::continueFirstRunSetup);
            } else {
                addText("Aktifkan izin overlay atau pilih lewati sementara untuk melanjutkan unduhan.", 12, 0xff627d98, false);
            }
        }
        addText("Izin tangkap layar tidak diminta sekarang. Android akan menampilkan persetujuan resmi setiap kali kamu memulai sesi Floating Overlay, sesuai aturan keamanan Android.", 12, 0xff627d98, false);
    }

    private void continueFirstRunSetup() {
        if (downloadRunning || EngineInstaller.isInstalled(this)) {
            if (EngineInstaller.isInstalled(this)) renderDashboard();
            return;
        }
        if (!Settings.canDrawOverlays(this) && !setupPrefs.getBoolean(SKIP_OVERLAY, false)) {
            renderSetup();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !setupPrefs.getBoolean(NOTIFICATION_ASKED, false)) {
            requestNotificationPermission();
            return;
        }
        if (!hasNetwork()) {
            showRetryDialog("Tidak ada koneksi internet", "Hubungkan perangkat ke Wi-Fi atau data seluler, lalu coba lagi.");
            return;
        }
        if (isMeteredNetwork() && !setupPrefs.getBoolean(MOBILE_DATA_ACCEPTED, false)) {
            new AlertDialog.Builder(this)
                    .setTitle("Unduh Stockfish 18?")
                    .setMessage("Stockfish 18 Full membutuhkan unduhan sekitar 113 MB. Koneksi saat ini menggunakan data seluler atau jaringan berkuota. Lanjutkan?")
                    .setNegativeButton("Nanti", (d, w) -> renderSetup())
                    .setPositiveButton("Unduh", (d, w) -> {
                        setupPrefs.edit().putBoolean(MOBILE_DATA_ACCEPTED, true).apply();
                        startEngineDownload();
                    }).show();
            return;
        }
        startEngineDownload();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) { continueFirstRunSetup(); return; }
        setupPrefs.edit().putBoolean(NOTIFICATION_ASKED, true).apply();
        waitingForNotificationResult = true;
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATIONS);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATIONS) {
            waitingForNotificationResult = false;
            // Notifications are recommended but not required to download or use the practice board.
            continueFirstRunSetup();
        }
    }

    private void startEngineDownload() {
        if (downloadRunning || EngineInstaller.isInstalled(this)) { renderDashboard(); return; }
        downloadRunning = true;
        renderSetup();
        if (statusText != null) statusText.setText("Menghubungkan ke server Stockfish 18 Full…");
        EngineInstaller.download(this, new EngineInstaller.Listener() {
            @Override public void onProgress(long downloaded, long total, String phase) {
                if (isFinishing()) return;
                if (statusText != null) {
                    String amount = formatBytes(downloaded);
                    String size = total > 0 ? " / " + formatBytes(total) : "";
                    statusText.setText(phase + "\n" + amount + size);
                }
                if (downloadProgress != null && total > 0) {
                    downloadProgress.setIndeterminate(false);
                    downloadProgress.setProgress((int)Math.min(100, downloaded * 100L / total));
                } else if (downloadProgress != null) downloadProgress.setIndeterminate(true);
            }
            @Override public void onComplete(java.io.File engineDirectory) {
                downloadRunning = false;
                Toast.makeText(MainActivity.this, "Stockfish 18 Full WASM berhasil diunduh dan diperiksa.", Toast.LENGTH_LONG).show();
                renderDashboard();
                WasmEngineHost.attach(MainActivity.this, body);
            }
            @Override public void onError(String message) {
                downloadRunning = false;
                renderSetup();
                if (statusText != null) statusText.setText("Download atau verifikasi gagal: " + message);
                addText("Periksa koneksi internet, lalu coba lagi. File yang gagal diverifikasi tidak akan digunakan.", 12, 0xff9b2c2c, false);
            }
            @Override public void onCancelled() {
                downloadRunning = false;
                renderSetup();
                if (statusText != null) statusText.setText("Unduhan dibatalkan. File sementara dibersihkan; kamu bisa melanjutkan kapan saja.");
            }
        });
    }

    private void cancelEngineDownload() {
        if (!downloadRunning) return;
        if (statusText != null) statusText.setText("Membatalkan unduhan dan membersihkan file sementara…");
        EngineInstaller.cancelDownload();
    }

    private void renderDashboard() {
        dashboardVisible = true;
        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(24), dp(22), dp(24));
        body.setBackgroundColor(0xfff3f6fb);
        scroll.addView(body);
        setContentView(scroll);

        addText("♟ ChessLens Realtime", 27, 0xff102a43, true);
        addText("Stockfish 18 Full · analisis di perangkat", 14, 0xff52677d, false);
        addText("✓ Mesin Stockfish 18 Full siap digunakan secara offline.", 15, 0xff176b55, true);
        addButton("Buka Papan Latihan + FEN + Riwayat", () -> startActivity(new Intent(this, PracticeActivity.class)));
        addText("FLOATING OVERLAY", 16, 0xff102a43, true);
        addText("Panel mengambang dapat digunakan di atas aplikasi lain. Android akan meminta izin tangkap layar setiap kali sesi baru dimulai.", 13, 0xff52677d, false);

        if (!Settings.canDrawOverlays(this)) {
            addButton("Aktifkan izin Floating Overlay", () -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()))));
        }
        whiteBottom = new CheckBox(this);
        whiteBottom.setText("Bidak putih di bawah");
        whiteBottom.setTextColor(0xff243b53);
        whiteBottom.setChecked(getPreferences(0).getBoolean("white", true));
        whiteBottom.setOnCheckedChangeListener((v, on) -> getPreferences(0).edit().putBoolean("white", on).apply());
        body.addView(whiteBottom);

        duration = addText("Waktu berpikir: 700 ms / posisi", 14, 0xff334e68, false);
        think = new SeekBar(this);
        think.setMax(6);
        think.setProgress(getPreferences(0).getInt("think", 2));
        body.addView(think);
        think.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                duration.setText("Waktu berpikir: " + thinkMs(p) + " ms / posisi");
                if (user) getPreferences(0).edit().putInt("think", p).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        duration.setText("Waktu berpikir: " + thinkMs(think.getProgress()) + " ms / posisi");

        addButton("Mulai tangkap layar + analisis", this::startScreenCapture);
        addButtonSecondary("Hentikan analisis layar", () -> stopService(new Intent(this, ScreenService.class)));
        addText("Privasi: gambar layar diproses di perangkat dan tidak diunggah ke server. Gunakan engine hanya untuk latihan atau analisis yang diperbolehkan.", 12, 0xff627d98, false);
        if (EngineInstaller.isInstalled(this)) WasmEngineHost.attach(this, body);
    }

    private void startScreenCapture() {
        if (!EngineInstaller.isInstalled(this)) { renderSetup(); return; }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin Floating Overlay terlebih dahulu.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        MediaProjectionManager manager = getSystemService(MediaProjectionManager.class);
        Intent request = Build.VERSION.SDK_INT >= 34
                ? manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                : manager.createScreenCaptureIntent();
        startActivityForResult(request, CAPTURE);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CAPTURE) return;
        if (result != RESULT_OK || data == null) {
            Toast.makeText(this, "Izin tangkap layar tidak diberikan.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent service = new Intent(this, ScreenService.class);
        service.putExtra("result", result);
        service.putExtra("data", data);
        service.putExtra("white", whiteBottom != null && whiteBottom.isChecked());
        service.putExtra("thinkMs", thinkMs(think == null ? 2 : think.getProgress()));
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        moveTaskToBack(true);
    }

    private boolean hasNetwork() {
        ConnectivityManager manager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return false;
        Network network = manager.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities caps = manager.getNetworkCapabilities(network);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private boolean isMeteredNetwork() {
        ConnectivityManager manager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        return manager != null && manager.isActiveNetworkMetered();
    }

    private void showRetryDialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
                .setPositiveButton("Coba lagi", (d, w) -> continueFirstRunSetup())
                .setNegativeButton("Nanti", (d, w) -> renderSetup()).show();
    }

    private int thinkMs(int pos) {
        int[] values = {200, 400, 700, 1000, 1500, 2200, 3000};
        return values[Math.max(0, Math.min(pos, values.length - 1))];
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "";
        if (bytes < 1024L * 1024L) return (bytes / 1024L) + " KB";
        return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private TextView addText(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setPadding(0, dp(8), 0, dp(10));
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        if (body != null) body.addView(view);
        return view;
    }

    private void addStep(String title, String description) {
        TextView heading = addText(title, 16, 0xff102a43, true);
        heading.setPadding(0, dp(18), 0, dp(2));
        addText(description, 13, 0xff52677d, false);
    }

    private void addButton(String title, Runnable action) { addButtonInternal(title, action, true); }
    private void addButtonSecondary(String title, Runnable action) { addButtonInternal(title, action, false); }
    private void addButtonInternal(String title, Runnable action, boolean primary) {
        Button button = new Button(this);
        button.setText(title);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52));
        params.topMargin = dp(5);
        params.bottomMargin = dp(5);
        body.addView(button, params);
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
}
