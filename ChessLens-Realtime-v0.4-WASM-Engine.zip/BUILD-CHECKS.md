# Build checks — ChessLens Realtime v0.4

## Changes from v0.3

- Removed `ProcessBuilder` execution of Stockfish from the writable app data directory.
- Uses Stockfish 18 full single-threaded WebAssembly through Android WebView Worker.
- Downloads the JS loader and approximately 113 MB WASM engine in-app after first launch.
- The build workflow computes and injects SHA-256 values for the pinned npm 18.0.5 JS/WASM assets. The app verifies both hashes, WASM magic bytes, minimum size, and HTTP Content-Length before marking the engine installed.
- Adds a cancel-download action that closes the connection and cleans partial `.part` files.
- Completed assets are retained and reused on retry.

## Verification still required

- GitHub Actions Android build.
- WebView worker/WASM UCI smoke test on a physical Android device.
- Confirm cancellation during both loader and large WASM downloads.
- Confirm Stockfish analysis continues while the foreground screen-capture service is active.

A successful APK compilation alone does not prove device runtime behavior.
