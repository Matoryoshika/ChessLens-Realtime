# ChessLens Realtime v0.4

Android chess training and post-game analysis prototype.

## Important engine architecture change

Stockfish 18 is delivered as a single-threaded WebAssembly engine and downloaded into app-private storage after installation. It runs inside Android WebView as a Web Worker. The app does **not** try to execute a downloaded ELF binary from `/data/user/0/.../files`, which Android 10+ blocks for apps targeting API 29+.

The selected engine is the **full Stockfish 18 single-threaded WASM build** (`stockfish@18.0.5`), not the reduced lite NNUE build. The WASM download is approximately 113 MB. The APK installer remains small; the engine is downloaded once in-app and can then run offline.

The setup page includes a **Batalkan unduhan** button. Cancellation closes the HTTP stream and connection, deletes incomplete `.part` files, and retains any already completed verified asset so a later retry can reuse it.

## First launch

1. Grant Floating Overlay permission in Android Settings.
2. Optionally grant notifications (not required to download).
3. Approve the engine download when using a metered network.
4. ChessLens downloads the JS loader and Stockfish 18 full WASM file.
5. The WebView worker loads the engine locally; no second APK or external engine installation is required.
6. Screen capture permission is requested by Android only when a new capture session starts.

## Components

- Android Java UI and floating overlay.
- Screen capture with MediaProjection.
- Board detection and FEN tracking.
- Stockfish 18 full single-threaded WASM through WebView Worker.
- UCI adapter, move labels, and practice board.

## Build

Use the GitHub Actions workflow in `.github/workflows/build-android-wasm.yml`. Upload this source archive to the repository root as `ChessLens-Realtime-v0.4-WASM-Engine.zip`.

## License

Stockfish and the Stockfish.js WebAssembly port are GPL-3.0. See `LICENSE` and the upstream Stockfish.js project for corresponding source and notices.
