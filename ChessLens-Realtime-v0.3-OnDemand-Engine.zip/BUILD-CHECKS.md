# v0.3 build checks

The GitHub Actions workflow should:

- Compile `assembleDebug` using JDK 17, Android API 34, and Gradle 8.7.
- Verify the APK signature with `apksigner`.
- Confirm that no `libstockfish` binary is bundled in the APK.
- Upload `ChessLens-Realtime-v0.3-debug.apk` as the `ChessLens-Realtime-v0.3-APK` artifact.

On a physical ARM64 or ARMv7 NEON Android device, verify:

1. First launch displays the setup flow.
2. Overlay permission returns to the setup flow correctly.
3. Android 13+ notification permission can be granted or denied without blocking setup.
4. Metered network download asks for confirmation; unmetered network starts download automatically after permissions.
5. Download progress updates; interruption shows retry; no partial file is marked installed.
6. SHA-256 verification passes and UCI smoke test returns a legal best move.
7. Relaunch does not download the engine again.
8. Practice mode uses the downloaded engine.
9. Starting screen analysis asks for MediaProjection consent each session.
