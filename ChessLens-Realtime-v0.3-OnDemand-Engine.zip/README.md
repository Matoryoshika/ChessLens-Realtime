# ChessLens Realtime v0.3 — On-Demand Stockfish 18

ChessLens Realtime is an experimental Android chess-training and screen-analysis app. Version 0.3 changes installation architecture: **the APK no longer bundles the large Stockfish executable**. On first launch, the app guides the user through Android permissions, then downloads the official Stockfish 18 binary for the device ABI, verifies SHA-256, marks it read-only/executable, and runs a UCI smoke test. The engine is stored in app-private internal storage and reused offline after successful installation.

## First-launch experience

1. Open the single ChessLens APK.
2. The setup screen explains and guides the user to grant Floating Overlay permission. This permission is needed for the HUD over other apps; users can skip it temporarily to use the in-app practice board.
3. On Android 13+, the app asks for notification permission. This is recommended for visible foreground-service status but is not required for downloading or practice mode.
4. On an unmetered network, Stockfish download starts automatically after the setup permissions. On a metered/mobile connection, the app asks for confirmation first.
5. The app selects ARM64 (`arm64-v8a`) or ARMv7 NEON (`armeabi-v7a`), downloads the official Stockfish 18 archive over HTTPS, extracts only the required executable, verifies its pinned SHA-256, makes it read-only/executable, and runs a short UCI test.
6. When the engine is ready, the app opens the dashboard. No second APK, browser, or manual engine installation is required.

Android intentionally requires the user to approve screen capture through the system MediaProjection dialog **each time a new screen-analysis session starts**. The app does not request this one-session token during onboarding because it cannot be silently reused later. Overlay access is a separate Android special permission. Notification permission is optional.

## Engine download details

- Official Stockfish 18 release: https://github.com/official-stockfish/Stockfish/releases/tag/sf_18
- ARM64 archive: `stockfish-android-armv8.tar`
- ARMv7 NEON archive: `stockfish-android-armv7-neon.tar`
- SHA-256 is pinned in `EngineInstaller.java` and checked before execution.
- Engine files are kept under app-private `files/engine/`; they are not written to shared storage and are not uploaded anywhere.
- After first successful download, engine analysis works offline. Clearing app data or reinstalling the app removes the downloaded engine and requires downloading it again.

## Features

- In-app practice board, legal move handling, FEN editor, and local saved-position history.
- Floating overlay with explicit Android screen-capture consent, pause, stop, calibration, move arrows, and Stockfish analysis.
- Heuristic move annotations (`!!`, `★`, `!`, `!?`, `?!`, `?`, `??`). These are not Chess.com official labels.
- Screen frames are processed locally in RAM; this app does not upload screen images.

## Build APK using GitHub Actions

1. Upload the contents of this project to the root of `Matoryoshika/ChessLens-Realtime`, including the hidden `.github/` folder, or upload `ChessLens-Realtime-v0.3-OnDemand-Engine.zip` to the repository root.
2. Ensure `.github/workflows/build-android.yml` is the workflow from this v0.3 project.
3. Open **Actions → Build ChessLens Realtime (On-Demand Stockfish 18)** and run the workflow, or push a commit to `main`.
4. Download artifact `ChessLens-Realtime-v0.3-APK` or the APK asset from the release created by a manual workflow run.
5. Install the single APK. Stockfish is downloaded from inside the app on first launch.

The APK is signed as a debug build by GitHub Actions. For future seamless in-place upgrades, use a stable release signing keystore and store its credentials as GitHub Actions secrets; a newly generated debug key on a fresh runner may differ between builds.

## Important limitations

- This source and workflow are prepared for a new build; the resulting APK still requires physical-device testing.
- Executing a downloaded native binary from app-private storage can behave differently across Android versions and vendor firmware. The installer performs a UCI smoke test and reports a clear error if the device refuses to execute it.
- Supported engine ABIs are ARM64 and ARMv7 NEON. x86/x86_64 devices are not supported by this build.
- Board recognition remains experimental and requires calibration from the standard initial position.
- MediaProjection capture is user-approved per session and cannot read protected `FLAG_SECURE` content.
- Use engine analysis only for study, puzzles, or games where external assistance is allowed.

## License

The app-specific source is MIT licensed. Stockfish 18 is GPLv3; if redistributed, comply with its source and license requirements. chesslib is Apache-2.0.
