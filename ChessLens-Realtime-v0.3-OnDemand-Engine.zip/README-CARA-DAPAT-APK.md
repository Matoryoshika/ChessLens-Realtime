# Cara mendapatkan APK ChessLens Realtime v0.3

Paket ini adalah source project, bukan APK. Build APK kecil dilakukan lewat GitHub Actions; Stockfish 18 tidak dimasukkan ke APK, melainkan diunduh dari dalam aplikasi saat pertama kali dibuka.

## Urutan penting

1. Buka repository `Matoryoshika/ChessLens-Realtime`.
2. **Ganti workflow terlebih dahulu**: buka `.github/workflows/build-android.yml`, tekan Edit, lalu ganti seluruh isinya dengan file `build-android.yml` yang disertakan dalam paket v0.3. Commit perubahan ini.
3. Setelah workflow baru tersimpan, unggah file `ChessLens-Realtime-v0.3-OnDemand-Engine.zip` ke root repository. Jangan ubah nama ZIP. Commit perubahan.
4. Buka **Actions**. Workflow **Build ChessLens Realtime (On-Demand Stockfish 18)** akan berjalan otomatis.
5. Jika workflow berstatus hijau, buka run tersebut dan unduh artifact `ChessLens-Realtime-v0.3-APK`. Ekstrak ZIP artifact untuk memperoleh `ChessLens-Realtime-v0.3-debug.apk`.
6. Pasang APK di Android. Buka ChessLens, ikuti izin Floating Overlay dan notifikasi (notifikasi opsional), lalu Stockfish akan diunduh langsung di aplikasi. Jika jaringan berkuota, aplikasi meminta persetujuan terlebih dahulu.

## Penting

- Jangan jalankan workflow lama yang masih mengunduh dan memasukkan Stockfish ke APK.
- Screen capture diminta Android setiap kali pengguna memulai sesi overlay. Izin ini tidak dapat disimpan dan digunakan ulang diam-diam.
- APK ini perlu diuji di perangkat fisik. Jika Android menolak eksekusi binary yang diunduh, layar setup akan menampilkan error; kirim pesan error tersebut untuk diperbaiki.
- Untuk update APK berikutnya tanpa uninstall, perlu signing key rilis yang sama. Build debug GitHub Actions dapat memiliki kunci berbeda antar-run.
