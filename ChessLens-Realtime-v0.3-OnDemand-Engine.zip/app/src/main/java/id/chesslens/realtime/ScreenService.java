package id.chesslens.realtime;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.*;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.view.WindowManager;
import id.chesslens.realtime.engine.*;
import id.chesslens.realtime.overlay.FloatingOverlay;
import id.chesslens.realtime.vision.*;
import java.nio.ByteBuffer;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Opt-in on-device screen capture. No images are written to disk or transmitted. */
public final class ScreenService extends Service {
  public static final String ACTION_STOP="id.chesslens.realtime.STOP";
  private static final String CHANNEL="chesslens_capture";
  private MediaProjection projection;
  private VirtualDisplay display;
  private volatile ImageReader reader;
  private final Object captureLock=new Object();
  private final Handler main=new Handler(Looper.getMainLooper());
  private final ExecutorService worker=Executors.newSingleThreadExecutor();
  private final AtomicBoolean busy=new AtomicBoolean(false);
  private FloatingOverlay overlay;
  private final BoardFinder finder=new BoardFinder();
  private final PositionTracker tracker=new PositionTracker();
  private UciEngine engine;
  private volatile boolean calibrate=false,reset=false,paused=false;
  private boolean whiteBottom=true;
  private int width,height,thinkMs=700;
  private Rect lastBoard;
  private final Runnable ticker=new Runnable(){@Override public void run(){if(!paused)capture();main.postDelayed(this,1150);}};
  @Override public IBinder onBind(Intent i){return null;}
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(intent==null)return START_NOT_STICKY;
    if(ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
    if(projection!=null)return START_NOT_STICKY;
    whiteBottom=intent.getBooleanExtra("white",true);
    thinkMs=Math.max(150,Math.min(3000,intent.getIntExtra("thinkMs",700)));
    try{
      NotificationManager nm=getSystemService(NotificationManager.class);
      if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"ChessLens screen analysis",NotificationManager.IMPORTANCE_LOW));
      PendingIntent home=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      Intent end=new Intent(this,ScreenService.class).setAction(ACTION_STOP);
      PendingIntent endAction=PendingIntent.getService(this,2,end,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      Notification note=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_view)
        .setContentTitle("ChessLens Realtime aktif")
        .setContentText("Berbagi layar berjalan. Buka panel untuk menjeda atau hentikan.")
        .setContentIntent(home).setOngoing(true).addAction(android.R.drawable.ic_delete,"Hentikan",endAction).build();
      if(Build.VERSION.SDK_INT>=29)startForeground(13,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
      else startForeground(13,note);
      if(!android.provider.Settings.canDrawOverlays(this))throw new SecurityException("Izin overlay tidak aktif");
      overlay=new FloatingOverlay(this,
        ()->{calibrate=true;reset=true;paused=false;overlay.setPaused(false);overlay.clear();overlay.status("Siapkan papan awal untuk kalibrasi…");},
        ()->{paused=!paused;overlay.setPaused(paused);overlay.status(paused?"⏸ Dijeda. Tekan Lanjut.":"▶ Menganalisis kembali…");},
        this::stopSelf);
      WindowManager w=(WindowManager)getSystemService(WINDOW_SERVICE);
      Rect bounds;
      if(Build.VERSION.SDK_INT>=30)bounds=w.getMaximumWindowMetrics().getBounds();
      else {android.graphics.Point p=new android.graphics.Point();w.getDefaultDisplay().getRealSize(p);bounds=new Rect(0,0,p.x,p.y);}
      width=bounds.width();height=bounds.height();
      synchronized(captureLock){reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);}
      MediaProjectionManager manager=getSystemService(MediaProjectionManager.class);
      int code=intent.getIntExtra("result",Activity.RESULT_CANCELED);
      @SuppressWarnings("deprecation") Intent permission=intent.getParcelableExtra("data");
      projection=manager.getMediaProjection(code,permission);
      projection.registerCallback(new MediaProjection.Callback(){
        @Override public void onStop(){main.post(()->stopSelf());}
        @Override public void onCapturedContentResize(int newWidth,int newHeight){main.post(()->resize(newWidth,newHeight));}
      },main);
      display=projection.createVirtualDisplay("ChessLens",width,height,getResources().getDisplayMetrics().densityDpi,
        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,main);
      overlay.status("Siapkan posisi awal, lalu tekan Kalibrasi.");
      main.postDelayed(ticker,1000);
    }catch(Exception e){if(overlay!=null)overlay.status("Tidak dapat memulai: "+e.getMessage());stopSelf();}
    return START_NOT_STICKY;
  }
  private void resize(int w,int h){
    if(w<200||h<200||display==null||(w==width&&h==height))return;
    ImageReader fresh=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
    synchronized(captureLock){
      ImageReader old=reader;reader=fresh;width=w;height=h;
      display.resize(w,h,getResources().getDisplayMetrics().densityDpi);
      display.setSurface(fresh.getSurface());
      if(old!=null)old.close();
    }
    reset=true;calibrate=false;lastBoard=null;
    if(overlay!=null){overlay.clear();overlay.status("Ukuran layar berubah. Kalibrasi ulang papan awal.");}
  }
  private void capture(){
    if(!busy.compareAndSet(false,true))return;
    Bitmap frame=null;
    synchronized(captureLock){
      if(reader==null){busy.set(false);return;}
      Image img=null;
      try{
        img=reader.acquireLatestImage();
        if(img!=null){
          Image.Plane plane=img.getPlanes()[0];ByteBuffer buffer=plane.getBuffer();
          int rowStride=plane.getRowStride(),pixelStride=plane.getPixelStride();
          int imageWidth=img.getWidth(),imageHeight=img.getHeight();
          Bitmap padded=Bitmap.createBitmap(imageWidth+(rowStride-pixelStride*imageWidth)/pixelStride,imageHeight,Bitmap.Config.ARGB_8888);
          padded.copyPixelsFromBuffer(buffer);
          frame=Bitmap.createBitmap(padded,0,0,imageWidth,imageHeight);padded.recycle();
        }
      }catch(Exception ignored){}finally{if(img!=null)img.close();}
    }
    if(frame==null){busy.set(false);return;}
    Bitmap image=frame;
    worker.submit(()->{
      try{if(!paused)process(image);}
      catch(Exception ex){if(overlay!=null)overlay.status("Cek kalibrasi: "+ex.getMessage());}
      finally{image.recycle();busy.set(false);}
    });
  }
  private void process(Bitmap frame) throws Exception{
    if(reset){tracker.reset();lastBoard=null;reset=false;}
    Rect found=finder.find(frame);
    if(found==null){overlay.status("Papan tidak ditemukan. Periksa layar dan tema papan.");return;}
    if(lastBoard!=null){
      int tolerance=Math.max(12,lastBoard.width()/7);
      if(Math.abs(found.left-lastBoard.left)>tolerance||Math.abs(found.top-lastBoard.top)>tolerance){
        overlay.clear();lastBoard=found;overlay.status("Papan berpindah. Periksa posisi atau kalibrasi ulang.");return;
      }
    }
    lastBoard=found;
    if(!tracker.isReady()){
      if(calibrate){
        calibrate=false;
        if(tracker.calibrate(frame,found,whiteBottom)){
          overlay.status("✓ Kalibrasi selesai, mengevaluasi posisi awal…");
          try{
            if(engine==null)engine=new UciEngine(EngineInstaller.enginePath(this));
            UciEngine.Evaluation opening=engine.analyze(tracker.getFen(),thinkMs);
            overlay.annotate(found,"","","",opening.bestMove,whiteBottom);
            overlay.status("✓ Posisi awal terbaca. Saran: "+opening.bestMove+" · "+opening.description+"\nMenunggu langkah stabil…");
          }catch(Exception ex){overlay.status("✓ Kalibrasi aktif. Engine belum siap: "+ex.getMessage());}
        } else overlay.status("Kalibrasi gagal — tampilkan posisi awal dengan 32 buah.");
      } else overlay.status("Papan terdeteksi. Tekan Kalibrasi pada posisi awal.");
      return;
    }
    PositionTracker.Detected moved=tracker.inspect(frame,found);
    if(moved==null)return;
    String uci=moved.move.toString();
    overlay.annotate(found,uci.substring(0,2),uci.substring(2,4),"…","",whiteBottom);
    overlay.status("Langkah "+uci+" • Stockfish sedang mengevaluasi…");
    try{
      if(engine==null)engine=new UciEngine(EngineInstaller.enginePath(this));
      UciEngine.Evaluation pre=engine.analyze(moved.before.getFen(),thinkMs);
      UciEngine.Evaluation post=engine.analyze(moved.after.getFen(),thinkMs);
      MoveJudge.Result result=MoveJudge.judge(moved.before,moved.after,moved.move,pre,post);
      // Solid arrow = played move, dashed cyan arrow = best next response from Stockfish.
      overlay.annotate(found,uci.substring(0,2),uci.substring(2,4),result.symbol,post.bestMove,whiteBottom);
      overlay.status(result.symbol+" "+result.name+" · "+uci+"\n"+
        result.note+"\nCPL "+result.centipawnsLost+" • Saran selanjutnya: "+post.bestMove);
    }catch(Exception ex){overlay.status("Langkah "+uci+" tercatat; engine belum siap:\n"+ex.getMessage());}
  }
  @Override public void onDestroy(){
    main.removeCallbacks(ticker);
    synchronized(captureLock){
      if(display!=null){display.release();display=null;}
      if(reader!=null){reader.close();reader=null;}
    }
    if(projection!=null){MediaProjection closing=projection;projection=null;closing.stop();}
    worker.shutdownNow();
    if(engine!=null){engine.close();engine=null;}
    if(overlay!=null){overlay.dispose();overlay=null;}
    super.onDestroy();
  }
}
