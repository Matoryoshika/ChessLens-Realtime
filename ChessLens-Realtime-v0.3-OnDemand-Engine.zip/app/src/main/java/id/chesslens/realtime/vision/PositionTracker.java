package id.chesslens.realtime.vision;

import android.graphics.*;
import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.move.Move;
import java.util.*;

/** Learns piece silhouettes from the beginning position, then matches ONLY legal next positions. */
public final class PositionTracker {
  private static final String START="rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR";
  private static final int N=12; // 12x12 luminance differences per cell
  private final Map<Character,List<float[]>> models=new HashMap<>();
  private final Board board=new Board();
  private boolean calibrated=false, whiteBottom=true;
  private String candidateMove="";
  private int stableCount=0;
  private static class Features {float[][] cells=new float[64][];}
  public static class Detected {
    public final Board before,after; public final Move move;
    Detected(Board b,Board a,Move m){before=b;after=a;move=m;}
  }
  public boolean isReady(){return calibrated;}
  public String getFen(){return board.getFen();}
  public void reset(){calibrated=false;models.clear();board.loadFromFen(new Board().getFen());candidateMove="";stableCount=0;}
  /** The screenshot MUST show the standard start, including all pawns and back-rank pieces. */
  public boolean calibrate(Bitmap image,Rect rect,boolean whiteAtBottom){
    if(rect==null||rect.width()<160)return false;
    this.whiteBottom=whiteAtBottom;models.clear();
    Features f=read(image,rect);
    for(int r=0;r<8;r++)for(int c=0;c<8;c++){
      int screen=r*8+c,canonical=(whiteBottom?r:7-r)*8+(whiteBottom?c:7-c);
      char piece=START.charAt(canonical);
      models.computeIfAbsent(piece,k->new ArrayList<>()).add(f.cells[screen]);
    }
    board.loadFromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    calibrated=true;candidateMove="";stableCount=0;return true;
  }
  /** Returns a move only after consecutive matching frames, rejecting sliding animations. */
  public Detected inspect(Bitmap image,Rect rect){
    if(!calibrated||rect==null)return null;
    Features f=read(image,rect);
    double base=cost(board.getFen(),f);
    Move bestMove=null;double best=base;
    for(Move move:board.legalMoves()){
      Board copy=copy(board);
      if(!copy.doMove(move))continue;
      double cost=cost(copy.getFen(),f);
      if(cost<best){best=cost;bestMove=move;}
    }
    // A move needs a distinct enough silhouette change, not just highlighted squares.
    if(bestMove==null || base-best < 1300 || (base>0 && (base-best)/base < 0.035)){
      candidateMove="";stableCount=0;return null;
    }
    String id=bestMove.toString();
    if(!candidateMove.equals(id)){candidateMove=id;stableCount=1;return null;}
    stableCount++;
    if(stableCount<2)return null;
    Board prev=copy(board);
    board.doMove(bestMove);
    Board next=copy(board);
    candidateMove="";stableCount=0;
    return new Detected(prev,next,bestMove);
  }
  private static Board copy(Board src){Board c=new Board();c.loadFromFen(src.getFen());return c;}
  private double cost(String fen,Features actual){
    String placement=fen.split(" ")[0];char[] expected=new char[64];int k=0;
    for(char v:placement.toCharArray()){if(v=='/')continue;if(v>='1'&&v<='8'){for(int j=0;j<v-'0';j++)expected[k++]='.';}else expected[k++]=v;}
    double result=0;
    for(int r=0;r<8;r++)for(int c=0;c<8;c++){
      int screen=r*8+c,canonical=(whiteBottom?r:7-r)*8+(whiteBottom?c:7-c);
      List<float[]> templates=models.get(expected[canonical]);
      if(templates==null||templates.isEmpty()){result+=3000;continue;}
      float[] x=actual.cells[screen]; double min=Double.POSITIVE_INFINITY;
      for(float[] templ:templates){double d=0;
        for(int j=0;j<x.length;j++)d+=Math.abs(x[j]-templ[j]);
        if(d<min)min=d;
      }
      result+=min;
    }
    return result;
  }
  private Features read(Bitmap bitmap,Rect bounds){
    Features f=new Features();
    float cell=bounds.width()/8f;
    int w=bitmap.getWidth(),h=bitmap.getHeight();
    for(int row=0;row<8;row++)for(int col=0;col<8;col++){
      float x=bounds.left+col*cell,y=bounds.top+row*cell;
      // Background from four extreme corners; relative luminance handles board-theme changes.
      float bg=(luma(bitmap,clamp((int)(x+cell*.09f),w),clamp((int)(y+cell*.09f),h))
          +luma(bitmap,clamp((int)(x+cell*.91f),w),clamp((int)(y+cell*.09f),h))
          +luma(bitmap,clamp((int)(x+cell*.09f),w),clamp((int)(y+cell*.91f),h))
          +luma(bitmap,clamp((int)(x+cell*.91f),w),clamp((int)(y+cell*.91f),h)))/4f;
      float[] out=new float[N*N];
      for(int a=0;a<N;a++)for(int b=0;b<N;b++){
        float px=x+cell*(0.14f+(b+.5f)*.72f/N);
        float py=y+cell*(0.14f+(a+.5f)*.72f/N);
        out[a*N+b]=luma(bitmap,clamp((int)px,w),clamp((int)py,h))-bg;
      }
      f.cells[row*8+col]=out;
    }
    return f;
  }
  private static int clamp(int x,int limit){return Math.min(limit-1,Math.max(0,x));}
  private static int luma(Bitmap b,int x,int y){int c=b.getPixel(x,y);return ((c>>16&255)*77+(c>>8&255)*150+(c&255)*29)>>8;}
}
