package id.chesslens.realtime.engine;
import java.io.*;
import java.util.*;

/** Single-threaded synchronous UCI client. Only call from worker executor. */
public final class UciEngine implements AutoCloseable {
  private Process process; private BufferedReader input; private BufferedWriter output;
  public static final class Evaluation {
    public final int cp; public final String bestMove, description;
    public Evaluation(int cp,String bestMove,String description){this.cp=cp;this.bestMove=bestMove;this.description=description;}
  }
  public UciEngine(String executable) throws Exception {
    File f = new File(executable);
    if(!f.isFile()) throw new FileNotFoundException("File Stockfish tidak ada: " + executable);
    process=new ProcessBuilder(executable).redirectErrorStream(true).start();
    input=new BufferedReader(new InputStreamReader(process.getInputStream()));
    output=new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
    send("uci"); waitFor("uciok"); send("setoption name Threads value 2");
    send("setoption name Hash value 24"); send("setoption name MultiPV value 1");
    send("isready");waitFor("readyok");
  }
  private void send(String s) throws IOException {output.write(s);output.newLine();output.flush();}
  private void waitFor(String mark) throws IOException {
    for(String line;(line=input.readLine())!=null;){if(line.equals(mark))return;}
    throw new EOFException("Engine terputus saat menunggu " + mark);
  }
  public synchronized Evaluation analyze(String fen,int ms) throws IOException {
    send("position fen " + fen); send("go movetime " + ms);
    int cp=0; String best="", notation="0.00";
    for(String l;(l=input.readLine())!=null;){
      if(l.startsWith("info ")) {
        String[] t=l.split("\\s+");
        for(int i=0;i+2<t.length;i++)if(t[i].equals("score")){
          try {if(t[i+1].equals("cp")){cp=Integer.parseInt(t[i+2]);notation=String.format(Locale.US,"%+.2f",cp/100.0);} 
          else if(t[i+1].equals("mate")){int mate=Integer.parseInt(t[i+2]);cp=mate>0?20000-mate*10:-20000-mate*10;notation="M"+mate;}}catch(NumberFormatException ignored){} 
        }
      }
      if(l.startsWith("bestmove ")){String[] t=l.split("\\s+");best=t.length>1?t[1]:"";break;}
    }
    if(best.isEmpty())throw new EOFException("Tidak ada bestmove dari Stockfish");
    return new Evaluation(cp,best,notation);
  }
  @Override public void close(){try{send("quit");}catch(Exception ignored){} if(process!=null)process.destroy();}
}
