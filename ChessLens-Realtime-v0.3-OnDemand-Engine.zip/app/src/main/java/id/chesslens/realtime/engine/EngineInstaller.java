package id.chesslens.realtime.engine;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.system.Os;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads the official Stockfish 18 executable on first launch, verifies it, and stores it privately. */
public final class EngineInstaller {
    public static final String VERSION = "18";
    private static final String PREFS = "chesslens_engine";
    private static final String PREF_READY = "stockfish_ready";
    private static final String PREF_VERSION = "stockfish_version";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int BUFFER_SIZE = 64 * 1024;

    private EngineInstaller() {}

    public interface Listener {
        void onProgress(long downloadedBytes, long totalBytes, String phase);
        void onComplete(File engine);
        void onError(String message);
    }

    private static final class EngineAsset {
        final String suffix;
        final String sha256;
        EngineAsset(String suffix, String sha256) { this.suffix = suffix; this.sha256 = sha256; }
    }

    public static File engineFile(Context context) {
        return new File(new File(context.getFilesDir(), "engine"), "stockfish-" + VERSION);
    }

    public static String enginePath(Context context) {
        return engineFile(context).getAbsolutePath();
    }

    public static boolean isInstalled(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        File file = engineFile(context);
        return prefs.getBoolean(PREF_READY, false)
                && VERSION.equals(prefs.getString(PREF_VERSION, ""))
                && file.isFile() && file.length() > 30_000_000L && file.canExecute();
    }

    public static void forgetInstalled(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(PREF_READY, false).apply();
        File file = engineFile(context);
        if (file.exists()) file.delete();
    }

    public static void download(Context context, Listener listener) {
        final Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            File temp = null;
            HttpURLConnection connection = null;
            try {
                EngineAsset asset = chooseAsset();
                File directory = new File(app.getFilesDir(), "engine");
                if (!directory.exists() && !directory.mkdirs()) throw new IOException("Tidak dapat membuat folder engine.");
                temp = new File(directory, "stockfish-" + VERSION + ".download");
                if (temp.exists() && !temp.delete()) throw new IOException("Tidak dapat membersihkan unduhan lama.");

                String archive = "stockfish-android-" + asset.suffix + ".tar";
                URL url = new URL("https://github.com/official-stockfish/Stockfish/releases/download/sf_18/" + archive);
                connection = (HttpURLConnection) url.openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(25_000);
                connection.setReadTimeout(90_000);
                connection.setRequestProperty("User-Agent", "ChessLens-Realtime/0.3 Android");
                connection.setRequestProperty("Accept", "application/octet-stream");
                connection.connect();
                int response = connection.getResponseCode();
                if (response < 200 || response >= 300) throw new IOException("Server Stockfish merespons HTTP " + response + ".");

                long total = connection.getContentLengthLong();
                inputLastReported[0] = 0;
                String memberName = "stockfish-android-" + asset.suffix;
                postProgress(listener, 0, total, "Mengunduh Stockfish 18 untuk " + asset.suffix + "…");
                try (InputStream raw = new BufferedInputStream(connection.getInputStream(), BUFFER_SIZE)) {
                    CountingInputStream input = new CountingInputStream(raw, count -> {
                        if (count - inputLastReported[0] >= 1024 * 1024) {
                            inputLastReported[0] = count;
                            postProgress(listener, count, total, "Mengunduh Stockfish 18…");
                        }
                    });
                    extractTarMember(input, temp, memberName);
                    postProgress(listener, input.getCount(), total, "Memverifikasi integritas Stockfish…");
                }

                if (!temp.isFile() || temp.length() < 30_000_000L) throw new IOException("Binary Stockfish tidak ditemukan atau ukurannya tidak wajar.");
                String actualHash = sha256(temp);
                if (!asset.sha256.equalsIgnoreCase(actualHash)) {
                    throw new IOException("Verifikasi SHA-256 gagal. File unduhan dihapus demi keamanan.");
                }

                // Android 14 requires dynamically loaded code files to be read-only before execution.
                try { Os.chmod(temp.getAbsolutePath(), 0500); }
                catch (Exception ignored) { temp.setReadable(true, true); temp.setWritable(false, true); temp.setExecutable(true, true); }

                postProgress(listener, total > 0 ? total : temp.length(), total, "Menguji Stockfish 18…");
                UciEngine smokeTest = null;
                try {
                    smokeTest = new UciEngine(temp.getAbsolutePath());
                    smokeTest.analyze("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", 250);
                } finally {
                    if (smokeTest != null) smokeTest.close();
                }

                try { Os.chmod(temp.getAbsolutePath(), 0500); }
                catch (Exception ignored) { temp.setReadable(true, true); temp.setWritable(false, false); temp.setExecutable(true, true); }
                File destination = engineFile(app);
                if (destination.exists() && !destination.delete()) throw new IOException("Tidak dapat mengganti engine lama.");
                if (!temp.renameTo(destination)) {
                    copyFile(temp, destination);
                    temp.delete();
                    try { Os.chmod(destination.getAbsolutePath(), 0500); } catch (Exception ignored) { destination.setExecutable(true, true); }
                }
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putBoolean(PREF_READY, true).putString(PREF_VERSION, VERSION).apply();
                File installed = destination;
                MAIN.post(() -> listener.onComplete(installed));
            } catch (Exception error) {
                if (temp != null && temp.exists()) temp.delete();
                String message = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
                MAIN.post(() -> listener.onError(message));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    // A single-element holder keeps the progress callback allocation Java 8 compatible.
    private static final long[] inputLastReported = new long[]{0};

    private interface CountListener { void onCount(long count); }
    private static final class CountingInputStream extends FilterInputStream {
        private long count;
        private final CountListener listener;
        CountingInputStream(InputStream in, CountListener listener) { super(in); this.listener = listener; }
        long getCount() { return count; }
        @Override public int read() throws IOException {
            int value = super.read();
            if (value >= 0) { count++; listener.onCount(count); }
            return value;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            int n = super.read(b, off, len);
            if (n > 0) { count += n; listener.onCount(count); }
            return n;
        }
        @Override public long skip(long amount) throws IOException {
            long skipped = super.skip(amount);
            if (skipped > 0) { count += skipped; listener.onCount(count); }
            return skipped;
        }
    }

    private static void postProgress(Listener listener, long downloaded, long total, String phase) {
        MAIN.post(() -> listener.onProgress(downloaded, total, phase));
    }

    private static EngineAsset chooseAsset() throws IOException {
        if (Build.SUPPORTED_ABIS != null) {
            for (String abi : Build.SUPPORTED_ABIS) {
                if ("arm64-v8a".equals(abi)) {
                    return new EngineAsset("armv8", "cc3b3b74466b6d85cdc0f8cfdad4111c6a44bd0698f4eab96fea7b359a54d3d4");
                }
            }
            for (String abi : Build.SUPPORTED_ABIS) {
                if ("armeabi-v7a".equals(abi)) {
                    return new EngineAsset("armv7-neon", "672fbd7533d15fc70dae82df52c1185236975d059a585aa65eda960f1a3266ea");
                }
            }
        }
        throw new IOException("Arsitektur perangkat belum didukung. ChessLens saat ini memerlukan ARM64 atau ARMv7.");
    }

    private static void extractTarMember(InputStream input, File destination, String wantedName) throws IOException {
        byte[] header = new byte[512];
        boolean found = false;
        while (true) {
            int headerBytes = readFully(input, header, 512);
            if (headerBytes == 0) break;
            if (headerBytes != 512) throw new IOException("Arsip Stockfish terpotong.");
            if (isZeroBlock(header)) break;
            String name = readString(header, 0, 100);
            String prefix = readString(header, 345, 155);
            if (!prefix.isEmpty()) name = prefix + "/" + name;
            long size = parseOctal(header, 124, 12);
            int type = header[156] & 0xff;
            String base = name.substring(name.lastIndexOf('/') + 1);
            boolean regular = type == 0 || type == '0';
            if (regular && wantedName.equals(base)) {
                try (OutputStream output = new BufferedOutputStream(new FileOutputStream(destination), BUFFER_SIZE)) {
                    copyExactly(input, output, size);
                }
                long padding = (512 - (size % 512)) % 512;
                skipExactly(input, padding);
                found = true;
                break;
            } else {
                skipExactly(input, size);
                long padding = (512 - (size % 512)) % 512;
                skipExactly(input, padding);
            }
        }
        if (!found) throw new IOException("File engine " + wantedName + " tidak ditemukan di arsip resmi.");
    }

    private static int readFully(InputStream input, byte[] buffer, int length) throws IOException {
        int offset = 0;
        while (offset < length) {
            int n = input.read(buffer, offset, length - offset);
            if (n < 0) break;
            offset += n;
        }
        return offset;
    }

    private static void copyExactly(InputStream input, OutputStream output, long length) throws IOException {
        byte[] buffer = new byte[BUFFER_SIZE];
        long remaining = length;
        while (remaining > 0) {
            int n = input.read(buffer, 0, (int)Math.min(buffer.length, remaining));
            if (n < 0) throw new IOException("Data engine terpotong saat diekstrak.");
            output.write(buffer, 0, n);
            remaining -= n;
        }
        output.flush();
    }

    private static void skipExactly(InputStream input, long length) throws IOException {
        byte[] buffer = new byte[BUFFER_SIZE];
        long remaining = length;
        while (remaining > 0) {
            long skipped = input.skip(remaining);
            if (skipped > 0) { remaining -= skipped; continue; }
            int n = input.read(buffer, 0, (int)Math.min(buffer.length, remaining));
            if (n < 0) throw new IOException("Arsip Stockfish terpotong saat dilewati.");
            remaining -= n;
        }
    }

    private static boolean isZeroBlock(byte[] bytes) {
        for (byte value : bytes) if (value != 0) return false;
        return true;
    }

    private static String readString(byte[] bytes, int offset, int length) {
        int end = offset;
        while (end < offset + length && bytes[end] != 0) end++;
        return new String(bytes, offset, end - offset, java.nio.charset.StandardCharsets.UTF_8).trim();
    }

    private static long parseOctal(byte[] bytes, int offset, int length) throws IOException {
        long value = 0;
        int end = offset + length;
        int i = offset;
        while (i < end && (bytes[i] == 0 || bytes[i] == ' ')) i++;
        for (; i < end && bytes[i] != 0 && bytes[i] != ' '; i++) {
            int digit = bytes[i] - '0';
            if (digit < 0 || digit > 7) throw new IOException("Header TAR tidak valid.");
            value = (value << 3) + digit;
        }
        return value;
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            for (int n; (n = input.read(buffer)) >= 0;) if (n > 0) digest.update(buffer, 0, n);
        }
        StringBuilder result = new StringBuilder();
        for (byte value : digest.digest()) result.append(String.format(Locale.US, "%02x", value & 0xff));
        return result.toString();
    }

    private static void copyFile(File source, File destination) throws IOException {
        try (InputStream input = new FileInputStream(source); OutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            for (int n; (n = input.read(buffer)) >= 0;) if (n > 0) output.write(buffer, 0, n);
            output.flush();
        }
    }
}
