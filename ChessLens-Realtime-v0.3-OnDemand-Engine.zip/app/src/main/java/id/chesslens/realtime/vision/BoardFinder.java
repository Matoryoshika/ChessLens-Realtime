package id.chesslens.realtime.vision;
import android.graphics.*;

/** Finds a near-square 8x8 alternating-color region; recalibration may be necessary for unusual themes. */
public final class BoardFinder {
  private static final int LIMIT=340;
  private static class Candidate {int x,y,size;double score;Candidate(int a,int b,int c,double d){x=a;y=b;size=c;score=d;}}
  public Rect find(Bitmap original) {
    float ratio=Math.min(1f, (float)LIMIT / Math.min(original.getWidth(),original.getHeight()));
    int w=Math.max(8,Math.round(original.getWidth()*ratio)),h=Math.max(8,Math.round(original.getHeight()*ratio));
    Bitmap scaled=Bitmap.createScaledBitmap(original,w,h,true);
    int[] rgb=new int[w*h]; scaled.getPixels(rgb,0,w,0,0,w,h);
    int[] gray=new int[rgb.length];
    for(int i=0;i<rgb.length;i++){int v=rgb[i];gray[i]=((v>>16&255)*77+(v>>8&255)*150+(v&255)*29)>>8;}
    Candidate best=new Candidate(0,0,0,-1);
    int min=(int)(Math.min(w,h)*0.52),max=(int)(Math.min(w,h)*0.995);
    for(int size=min;size<=max;size+=Math.max(6,(max-min)/14)) {
      int step=Math.max(9,size/24);
      for(int y=0;y+size<h;y+=step){for(int x=0;x+size<w;x+=step){
        double s=score(gray,w,x,y,size);
        if(s>best.score)best=new Candidate(x,y,size,s);
      }}
    }
    if(best.size==0 || best.score<15){scaled.recycle();return null;}
    Candidate fine=best;
    for(int size=Math.max(min,best.size-15);size<=Math.min(max,best.size+15);size+=3)
      for(int y=Math.max(0,best.y-18);y+size<=h&&y<=best.y+18;y+=3)
        for(int x=Math.max(0,best.x-18);x+size<=w&&x<=best.x+18;x+=3){
          double s=score(gray,w,x,y,size);
          if(s>fine.score) fine=new Candidate(x,y,size,s);
        }
    scaled.recycle();
    float k=1f/ratio;
    return new Rect(Math.round(fine.x*k),Math.round(fine.y*k),Math.round((fine.x+fine.size)*k),Math.round((fine.y+fine.size)*k));
  }
  private double score(int[] g,int w,int x,int y,int size){
    double a=0,b=0,a2=0,b2=0;
    for(int r=0;r<8;r++) for(int c=0;c<8;c++){
      // Four samples away from each piece's center, median robust to piece edges.
      int sx=x+Math.round((c+0.5f)*size/8f), sy=y+Math.round((r+0.5f)*size/8f);
      int d=Math.max(2,size/8*34/100);
      int[] z=new int[]{g[(sy-d)*w+sx-d],g[(sy-d)*w+sx+d],g[(sy+d)*w+sx-d],g[(sy+d)*w+sx+d]};
      java.util.Arrays.sort(z);double v=(z[1]+z[2])/2.0;
      if((r+c)%2==0){a+=v;a2+=v*v;}else{b+=v;b2+=v*v;}
    }
    double ma=a/32,mb=b/32;
    double va=Math.max(0,a2/32-ma*ma),vb=Math.max(0,b2/32-mb*mb);
    double diff=ma-mb;
    return diff*diff/(5+Math.sqrt(va)+Math.sqrt(vb));
  }
}
