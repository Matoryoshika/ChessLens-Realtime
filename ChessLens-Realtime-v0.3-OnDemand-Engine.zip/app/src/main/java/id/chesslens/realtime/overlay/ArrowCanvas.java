package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Draws arrows directly above the selected board; never intercepts touches. */
public final class ArrowCanvas extends View {
  private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  private Rect boardRect;
  private String playedFrom="", playedTo="", recommendedFrom="", recommendedTo="", symbol="";
  private boolean whiteBottom=true;
  public ArrowCanvas(Context context){ super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
  public void update(Rect r,String from,String to,String mark,String suggestion,boolean white){
    boardRect=r==null?null:new Rect(r);playedFrom=from;playedTo=to;symbol=mark;
    recommendedFrom=suggestion!=null&&suggestion.matches("[a-h][1-8][a-h][1-8][qrbn]?")?suggestion.substring(0,2):"";
    recommendedTo=suggestion!=null&&suggestion.matches("[a-h][1-8][a-h][1-8][qrbn]?")?suggestion.substring(2,4):"";
    whiteBottom=white;invalidate();
  }
  @Override protected void onDraw(Canvas c){
    super.onDraw(c);
    if(boardRect==null)return;
    if(!playedFrom.isEmpty()&&!playedTo.isEmpty()){
      int col=("??".equals(symbol)||"?".equals(symbol))?0xffed5965:
        ("?!".equals(symbol)||"!?".equals(symbol))?0xffe7a23a:0xff32c886;
      arrow(c,playedFrom,playedTo,col,false);
      if(!symbol.isEmpty()&&!"…".equals(symbol))badge(c,playedTo,symbol,col);
    }
    if(!recommendedFrom.isEmpty()&&!recommendedTo.isEmpty())
      arrow(c,recommendedFrom,recommendedTo,0xff35b5ee,true);
  }
  private void arrow(Canvas c,String from,String to,int color,boolean dashed){
    PointF a=center(from),b=center(to);float width=Math.max(7,boardRect.width()/75f);
    double angle=Math.atan2(b.y-a.y,b.x-a.x);
    float trim=Math.max(width*1.4f,boardRect.width()/45f);
    PointF end=new PointF(b.x-(float)Math.cos(angle)*trim,b.y-(float)Math.sin(angle)*trim);
    p.reset();p.setAntiAlias(true);p.setColor(color);p.setStrokeWidth(width);p.setStrokeCap(Paint.Cap.ROUND);p.setStyle(Paint.Style.STROKE);
    if(dashed)p.setPathEffect(new DashPathEffect(new float[]{width*2,width*1.4f},0));
    c.drawLine(a.x,a.y,end.x,end.y,p);p.setPathEffect(null);
    float length=width*2.8f;
    Path tip=new Path();tip.moveTo(b.x,b.y);
    tip.lineTo(b.x-(float)Math.cos(angle-.51)*length,b.y-(float)Math.sin(angle-.51)*length);
    tip.lineTo(b.x-(float)Math.cos(angle+.51)*length,b.y-(float)Math.sin(angle+.51)*length);
    tip.close();p.setStyle(Paint.Style.FILL);c.drawPath(tip,p);
  }
  private void badge(Canvas c,String square,String mark,int bg){
    PointF dest=center(square);float tile=boardRect.width()/8f;
    float rad=Math.max(15,tile*.22f),bx=dest.x+tile*.28f,by=dest.y-tile*.27f;
    p.reset();p.setAntiAlias(true);p.setColor(bg);p.setStyle(Paint.Style.FILL);c.drawCircle(bx,by,rad,p);
    p.setColor(Color.WHITE);p.setTextSize(rad*.98f);p.setTextAlign(Paint.Align.CENTER);
    p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
    c.drawText(mark,bx,by+rad*.34f,p);
  }
  private PointF center(String s){
    int file=s.charAt(0)-'a', rank=8-(s.charAt(1)-'0');
    if(!whiteBottom){file=7-file;rank=7-rank;}
    float cell=boardRect.width()/8f;
    return new PointF(boardRect.left+(file+.5f)*cell,boardRect.top+(rank+.5f)*cell);
  }
}
