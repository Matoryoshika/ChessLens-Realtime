package id.chesslens.realtime.engine;

import java.io.IOException;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** UCI client backed by Stockfish 18 WebAssembly running in Android WebView. */
public final class UciEngine implements AutoCloseable {
    private boolean closed;

    public static final class Evaluation {
        public final int cp;
        public final String bestMove, description;
        public final List<String> principalVariation;
        public Evaluation(int cp, String bestMove, String description, List<String> pv) {
            this.cp = cp;
            this.bestMove = bestMove;
            this.description = description;
            this.principalVariation = Collections.unmodifiableList(new ArrayList<>(pv));
        }
        public Evaluation(int cp, String bestMove, String description) {
            this(cp, bestMove, description, bestMove == null || bestMove.isEmpty()
                    ? Collections.emptyList() : Collections.singletonList(bestMove));
        }
        /** UCI move at a zero-based ply in Stockfish's principal variation. */
        public String moveAt(int ply) {
            return ply >= 0 && ply < principalVariation.size() ? principalVariation.get(ply) : "";
        }
    }

    public UciEngine() throws Exception { this(null); }

    /** The old path argument is ignored for compatibility; WASM assets are served by WebView. */
    @Deprecated public UciEngine(String ignoredExecutablePath) throws Exception {
        WasmEngineHost.awaitReady(45_000);
        WasmEngineHost.clearOutput();
        send("uci");
        waitFor("uciok", 60_000);
        send("setoption name Threads value 1");
        send("setoption name Hash value 16");
        send("setoption name MultiPV value 1");
        send("isready");
        waitFor("readyok", 30_000);
    }

    private void send(String command) throws IOException {
        if (closed) throw new IOException("Sesi engine sudah ditutup.");
        WasmEngineHost.send(command);
    }

    private void waitFor(String expected, long timeoutMs) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            String line = WasmEngineHost.nextLine(Math.max(1, deadline - System.currentTimeMillis()));
            if (expected.equals(line.trim())) return;
        }
        throw new IOException("Stockfish tidak mengirim " + expected + ".");
    }

    public synchronized Evaluation analyze(String fen, int milliseconds) throws Exception {
        if (closed) throw new IOException("Sesi engine sudah ditutup.");
        send("position fen " + fen);
        send("go movetime " + Math.max(100, Math.min(10_000, milliseconds)));
        int cp = 0;
        int bestDepth = -1;
        String best = "";
        String notation = "0.00";
        List<String> bestPv = new ArrayList<>();
        long deadline = System.currentTimeMillis() + Math.max(15_000L, milliseconds + 10_000L);
        while (System.currentTimeMillis() < deadline) {
            String line = WasmEngineHost.nextLine(Math.max(1, deadline - System.currentTimeMillis()));
            if (line.startsWith("info ")) {
                String[] tokens = line.trim().split("\\s+");
                int depth = -1;
                int lineCp = cp;
                String lineNotation = notation;
                List<String> linePv = new ArrayList<>();
                for (int i = 0; i < tokens.length; i++) {
                    if ("depth".equals(tokens[i]) && i + 1 < tokens.length) {
                        try { depth = Integer.parseInt(tokens[i + 1]); } catch (NumberFormatException ignored) { }
                    }
                    if ("score".equals(tokens[i]) && i + 2 < tokens.length) {
                        try {
                            if ("cp".equals(tokens[i + 1])) {
                                lineCp = Integer.parseInt(tokens[i + 2]);
                                lineNotation = String.format(Locale.US, "%+.2f", lineCp / 100.0);
                            } else if ("mate".equals(tokens[i + 1])) {
                                int mate = Integer.parseInt(tokens[i + 2]);
                                lineCp = mate > 0 ? 20_000 - mate * 10 : -20_000 - mate * 10;
                                lineNotation = "M" + mate;
                            }
                        } catch (NumberFormatException ignored) { }
                    }
                    if ("pv".equals(tokens[i])) {
                        for (int j = i + 1; j < tokens.length; j++) {
                            if (!tokens[j].matches("[a-h][1-8][a-h][1-8][qrbn]?")) break;
                            linePv.add(tokens[j]);
                        }
                        break;
                    }
                }
                // Keep the deepest MultiPV-1 line; it contains our move and the opponent's predicted reply.
                if (!linePv.isEmpty() && depth >= bestDepth) {
                    bestDepth = depth;
                    cp = lineCp;
                    notation = lineNotation;
                    bestPv = linePv;
                }
            }
            if (line.startsWith("bestmove ")) {
                String[] tokens = line.trim().split("\\s+");
                best = tokens.length > 1 ? tokens[1] : "";
                break;
            }
        }
        if (best.isEmpty() || "(none)".equals(best) || "0000".equals(best))
            throw new IOException("Stockfish tidak menemukan langkah legal pada posisi ini.");
        if (bestPv.isEmpty() || !best.equals(bestPv.get(0))) {
            // Do not treat an older PV's first move as the opponent reply if the final bestmove changed.
            bestPv.clear();
            bestPv.add(best);
        }
        return new Evaluation(cp, best, notation, bestPv);
    }

    public void stopSearch() {
        if (!closed) {
            try { WasmEngineHost.send("stop"); } catch (Exception ignored) { }
        }
    }

    @Override public void close() {
        stopSearch();
        closed = true;
    }
}
