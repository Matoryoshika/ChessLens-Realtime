package id.chesslens.realtime.vision;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Side;
import com.github.bhlangonijr.chesslib.move.Move;

/** Tracks stable board positions and infers the side to move from observed legal transitions. */
public final class PositionTracker {
    private static final String START_PLACEMENT =
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

    private boolean whiteBottom = true;
    private boolean orientationLocked = false;
    private boolean whiteToMove = true;
    private boolean turnKnown = false;
    private String currentPlacement = "";
    private String pendingPlacement = "";
    private int stableFrames = 0;
    private Board currentBoard;

    public static final class Update {
        public final Board before;
        public final Board after;
        public final Move move;
        public final boolean initialPosition;
        public final boolean resynchronised;
        public final boolean turnKnown;
        public final boolean turnInferred;
        public final String fen;

        Update(Board before, Board after, Move move, boolean initial, boolean resync,
               boolean known, boolean inferred) {
            this.before = before;
            this.after = after;
            this.move = move;
            this.initialPosition = initial;
            this.resynchronised = resync;
            this.turnKnown = known;
            this.turnInferred = inferred;
            this.fen = after.getFen();
        }
    }

    private static final class Match {
        final Board before;
        final Board after;
        final Move move;
        Match(Board before, Board after, Move move) {
            this.before = before;
            this.after = after;
            this.move = move;
        }
    }

    public synchronized boolean isReady() { return currentBoard != null; }
    public synchronized boolean isWhiteBottom() { return whiteBottom; }
    public synchronized boolean isOrientationKnown() { return orientationLocked; }
    public synchronized boolean isTurnKnown() { return turnKnown; }
    public synchronized boolean isWhiteToMove() { return whiteToMove; }
    public synchronized String getFen() { return currentBoard == null ? "" : currentBoard.getFen(); }
    public synchronized Board getBoardCopy() { return currentBoard == null ? null : copy(currentBoard); }

    public synchronized void resetPosition() {
        currentPlacement = "";
        pendingPlacement = "";
        stableFrames = 0;
        currentBoard = null;
        whiteToMove = true;
        turnKnown = false;
    }

    /**
     * Applies a stable model result. Two matching frames are required for a move.
     * If the app starts mid-game, the turn is deliberately unknown until a legal
     * one-ply transition is observed; piece placement alone cannot reveal whose
     * turn it is. A standard starting position is the one safe exception.
     */
    public synchronized Update observe(PieceClassifier.Result result) {
        if (result == null || result.pieceCount < 2 || result.averageConfidence < 0.52f
                || result.lowConfidenceSquares > 12) return null;

        boolean orientationChanged = false;
        if (!orientationLocked && result.orientationReliable) {
            boolean nextWhiteBottom = result.suggestedWhiteBottom;
            orientationChanged = currentBoard != null && whiteBottom != nextWhiteBottom;
            whiteBottom = nextWhiteBottom;
            orientationLocked = true;
            if (orientationChanged) resetPosition();
        }

        String placement = result.toFenPlacement(whiteBottom);
        if (!isSanePlacement(placement)) return null;

        if (!placement.equals(pendingPlacement)) {
            pendingPlacement = placement;
            stableFrames = 1;
            return null;
        }
        stableFrames++;
        if (stableFrames < 2 || placement.equals(currentPlacement)) return null;

        if (currentBoard == null) {
            currentPlacement = placement;
            whiteToMove = true;
            turnKnown = START_PLACEMENT.equals(placement);
            currentBoard = boardFromPlacement(placement, whiteToMove);
            pendingPlacement = placement;
            return new Update(null, copy(currentBoard), null, true, false, turnKnown, false);
        }

        if (turnKnown) {
            Match currentSide = findMatchingMove(currentPlacement, whiteToMove, placement);
            if (currentSide != null) return accept(currentSide, placement, false);

            // Recover if an earlier recognition error left the remembered turn one ply behind.
            Match otherSide = findMatchingMove(currentPlacement, !whiteToMove, placement);
            if (otherSide != null) return accept(otherSide, placement, true);
        } else {
            Match whiteCandidate = findMatchingMove(currentPlacement, true, placement);
            Match blackCandidate = findMatchingMove(currentPlacement, false, placement);
            if (whiteCandidate != null && blackCandidate == null)
                return accept(whiteCandidate, placement, true);
            if (blackCandidate != null && whiteCandidate == null)
                return accept(blackCandidate, placement, true);
        }

        // Do not resynchronise on a brief drag/animation frame. Wait for four
        // identical classifications before accepting a non-one-ply position.
        if (stableFrames < 4) return null;

        Board before = copy(currentBoard);
        currentPlacement = placement;
        whiteToMove = true; // placeholder only; turnKnown prevents engine use.
        turnKnown = false;
        currentBoard = boardFromPlacement(placement, whiteToMove);
        pendingPlacement = placement;
        return new Update(before, copy(currentBoard), null, false, true, false, false);
    }

    private Update accept(Match match, String placement, boolean inferred) {
        currentBoard = match.after;
        currentPlacement = placement;
        whiteToMove = currentBoard.getSideToMove() == Side.WHITE;
        turnKnown = true;
        pendingPlacement = placement;
        return new Update(copy(match.before), copy(currentBoard), match.move,
                false, false, true, inferred);
    }

    private static Match findMatchingMove(String placement, boolean sideWhite, String targetPlacement) {
        Board before = boardFromPlacement(placement, sideWhite);
        for (Move move : before.legalMoves()) {
            Board after = copy(before);
            if (after.doMove(move) && placementOf(after).equals(targetPlacement))
                return new Match(before, after, move);
        }
        return null;
    }

    private static Board boardFromPlacement(String placement, boolean whiteToMove) {
        Board board = new Board();
        board.loadFromFen(placement + (whiteToMove ? " w " : " b ") + "- - 0 1");
        return board;
    }

    private static String placementOf(Board board) {
        return board.getFen().split(" ")[0];
    }

    private static Board copy(Board source) {
        Board result = new Board();
        result.loadFromFen(source.getFen());
        return result;
    }

    private static boolean isSanePlacement(String placement) {
        int whiteKings = 0, blackKings = 0, pieces = 0;
        for (int i = 0; i < placement.length(); i++) {
            char p = placement.charAt(i);
            if (p == 'K') whiteKings++;
            else if (p == 'k') blackKings++;
            else if (p >= 'A' && p <= 'Z' || p >= 'a' && p <= 'z') pieces++;
        }
        return whiteKings == 1 && blackKings == 1 && pieces + whiteKings + blackKings <= 32;
    }
}
