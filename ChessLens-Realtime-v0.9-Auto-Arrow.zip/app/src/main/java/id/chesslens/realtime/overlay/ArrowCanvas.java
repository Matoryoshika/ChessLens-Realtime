package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;

/** High-contrast move arrows with a glowing origin and a clear destination marker. */
public final class ArrowCanvas extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Rect sourceBoardRect;
    private Rect drawBoardRect;
    private int sourceWidth;
    private int sourceHeight;
    private String playedFrom = "", playedTo = "", myFrom = "", myTo = "";
    private String opponentFrom = "", opponentTo = "", symbol = "";
    private boolean whiteBottom = true;
    private boolean playerSideKnown = true;

    public ArrowCanvas(Context context) {
        super(context);
        setWillNotDraw(false);
    }

    public void update(Rect rect, int frameWidth, int frameHeight,
                       String from, String to, String mark,
                       String myMove, String opponentMove, boolean white,
                       boolean playerKnown) {
        sourceBoardRect = rect == null ? null : new Rect(rect);
        sourceWidth = frameWidth;
        sourceHeight = frameHeight;
        playedFrom = from == null ? "" : from;
        playedTo = to == null ? "" : to;
        symbol = mark == null ? "" : mark;
        myFrom = square(myMove, 0);
        myTo = square(myMove, 2);
        opponentFrom = square(opponentMove, 0);
        opponentTo = square(opponentMove, 2);
        whiteBottom = white;
        playerSideKnown = playerKnown;
        invalidate();
    }

    private static String square(String move, int offset) {
        if (move == null || !move.matches("[a-h][1-8][a-h][1-8][qrbn]?")) return "";
        return move.substring(offset, offset + 2);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (sourceBoardRect == null || getWidth() <= 0 || getHeight() <= 0) return;

        float sx = sourceWidth > 0 ? (float) getWidth() / sourceWidth : 1f;
        float sy = sourceHeight > 0 ? (float) getHeight() / sourceHeight : 1f;
        drawBoardRect = new Rect(
                Math.round(sourceBoardRect.left * sx),
                Math.round(sourceBoardRect.top * sy),
                Math.round(sourceBoardRect.right * sx),
                Math.round(sourceBoardRect.bottom * sy));
        if (drawBoardRect.width() < 8 || drawBoardRect.height() < 8) return;

        // Actual last move is kept visually distinct from engine recommendations.
        if (!playedFrom.isEmpty() && !playedTo.isEmpty()) {
            int color = ("??".equals(symbol) || "?".equals(symbol)) ? 0xffef5364
                    : ("?!".equals(symbol) || "!?".equals(symbol)) ? 0xfff0a13b
                    : 0xff38bdf8;
            drawMoveArrow(canvas, playedFrom, playedTo, color, false, "", 0f);
            if (!symbol.isEmpty() && !"…".equals(symbol)) drawBadge(canvas, playedTo, symbol, color);
        }

        // Draw the opponent first so the user's/current-side recommendation remains prominent.
        if (!opponentFrom.isEmpty() && !opponentTo.isEmpty()) {
            drawMoveArrow(canvas, opponentFrom, opponentTo, 0xffffa126, true, "L", 0f);
        }
        if (!myFrom.isEmpty() && !myTo.isEmpty()) {
            drawMoveArrow(canvas, myFrom, myTo, 0xff22c55e, false,
                    playerSideKnown ? "S" : "B", 0f);
        }
    }

    private void drawMoveArrow(Canvas canvas, String from, String to,
                               int color, boolean dashed, String marker, float laneOffset) {
        PointF origin = center(from);
        PointF destination = center(to);
        float cell = Math.min(drawBoardRect.width() / 8f, drawBoardRect.height() / 8f);
        float dx = destination.x - origin.x;
        float dy = destination.y - origin.y;
        float length = (float) Math.hypot(dx, dy);
        if (length < 1f) return;
        float ux = dx / length, uy = dy / length;
        float px = -uy, py = ux;
        float offsetX = px * cell * laneOffset;
        float offsetY = py * cell * laneOffset;

        float shaftWidth = Math.max(5.5f, cell * 0.155f);
        float startTrim = cell * 0.30f;
        float endTrim = cell * 0.38f;
        float sx = origin.x + ux * startTrim + offsetX;
        float sy = origin.y + uy * startTrim + offsetY;
        float tx = destination.x - ux * endTrim + offsetX;
        float ty = destination.y - uy * endTrim + offsetY;
        Path shaft = new Path();
        shaft.moveTo(sx, sy);
        shaft.lineTo(tx, ty);
        DashPathEffect dash = dashed
                ? new DashPathEffect(new float[]{shaftWidth * 1.65f, shaftWidth * 1.05f}, 0f)
                : null;

        // Three passes create a readable halo, a dark outline, and a saturated core.
        strokePath(canvas, shaft, withAlpha(color, 0x42), shaftWidth * 2.8f, dash);
        strokePath(canvas, shaft, 0xdd101827, shaftWidth * 1.75f, dash);
        strokePath(canvas, shaft, color, shaftWidth, dash);
        if (!dashed) strokePath(canvas, shaft, withAlpha(Color.WHITE, 0x62), shaftWidth * 0.20f, null);

        float headLength = cell * 0.40f;
        float headHalfWidth = cell * 0.25f;
        float tipX = destination.x + offsetX;
        float tipY = destination.y + offsetY;
        float baseX = tipX - ux * headLength;
        float baseY = tipY - uy * headLength;
        Path head = new Path();
        head.moveTo(tipX, tipY);
        head.lineTo(baseX + px * headHalfWidth, baseY + py * headHalfWidth);
        head.lineTo(baseX - px * headHalfWidth, baseY - py * headHalfWidth);
        head.close();
        paint.reset();
        paint.setAntiAlias(true);
        paint.setColor(0xdd101827);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1.5f, cell * 0.045f));
        canvas.drawPath(head, paint);
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(head, paint);

        drawOriginMarker(canvas, origin, color, cell);
        drawDestinationMarker(canvas, destination, color, cell);
        if (!marker.isEmpty()) drawBadge(canvas, to, marker, color);
    }

    private void strokePath(Canvas canvas, Path path, int color, float width, DashPathEffect dash) {
        paint.reset();
        paint.setAntiAlias(true);
        paint.setColor(color);
        paint.setStrokeWidth(width);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStyle(Paint.Style.STROKE);
        paint.setPathEffect(dash);
        canvas.drawPath(path, paint);
        paint.setPathEffect(null);
    }

    private void drawOriginMarker(Canvas canvas, PointF point, int color, float cell) {
        float radius = cell * 0.29f;
        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(color, 0x36));
        canvas.drawCircle(point.x, point.y, radius * 1.28f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, cell * 0.065f));
        paint.setColor(0xf5ffffff);
        canvas.drawCircle(point.x, point.y, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        canvas.drawCircle(point.x, point.y, cell * 0.105f, paint);
    }

    private void drawDestinationMarker(Canvas canvas, PointF point, int color, float cell) {
        float radius = cell * 0.22f;
        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(color, 0x32));
        canvas.drawCircle(point.x, point.y, radius * 1.45f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, cell * 0.075f));
        paint.setColor(Color.WHITE);
        canvas.drawCircle(point.x, point.y, radius, paint);
        paint.setStrokeWidth(Math.max(1.5f, cell * 0.035f));
        paint.setColor(color);
        canvas.drawCircle(point.x, point.y, radius * 0.70f, paint);
    }

    private void drawBadge(Canvas canvas, String square, String mark, int background) {
        PointF destination = center(square);
        float tileWidth = drawBoardRect.width() / 8f;
        float tileHeight = drawBoardRect.height() / 8f;
        float radius = Math.max(8f, Math.min(tileWidth, tileHeight) * 0.17f);
        float bx = clamp(destination.x + tileWidth * 0.29f,
                drawBoardRect.left + radius, drawBoardRect.right - radius);
        float by = clamp(destination.y - tileHeight * 0.29f,
                drawBoardRect.top + radius, drawBoardRect.bottom - radius);

        paint.reset();
        paint.setAntiAlias(true);
        paint.setColor(0xdd101827);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(bx, by, radius * 1.18f, paint);
        paint.setColor(background);
        canvas.drawCircle(bx, by, radius, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(radius * 0.96f);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        canvas.drawText(mark, bx, by + radius * 0.34f, paint);
    }

    private PointF center(String square) {
        int file = square.charAt(0) - 'a';
        int row = 8 - (square.charAt(1) - '0');
        if (!whiteBottom) {
            file = 7 - file;
            row = 7 - row;
        }
        float cellWidth = drawBoardRect.width() / 8f;
        float cellHeight = drawBoardRect.height() / 8f;
        return new PointF(
                drawBoardRect.left + (file + 0.5f) * cellWidth,
                drawBoardRect.top + (row + 0.5f) * cellHeight);
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00ffffff) | ((alpha & 0xff) << 24);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
