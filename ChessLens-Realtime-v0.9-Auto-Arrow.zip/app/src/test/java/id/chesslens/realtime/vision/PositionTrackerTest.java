package id.chesslens.realtime.vision;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.move.Move;

import org.junit.Test;

import static org.junit.Assert.*;

public class PositionTrackerTest {
    @Test public void standardStartingPositionKnowsWhiteMovesFirst() {
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result start = resultFor(new Board());

        assertNull(tracker.observe(start));
        PositionTracker.Update update = tracker.observe(start);

        assertNotNull(update);
        assertTrue(update.initialPosition);
        assertTrue(tracker.isOrientationKnown());
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
    }

    @Test public void middlegameStartDoesNotGuessTurnAndInfersItFromNextLegalMove() {
        Board board = new Board();
        assertTrue(board.doMove(findMove(board, "e2e4")));
        assertTrue(board.doMove(findMove(board, "e7e5")));
        assertTrue(board.doMove(findMove(board, "g1f3")));
        // This is a mid-game position with Black to move, but the tracker has no history.
        PositionTracker tracker = new PositionTracker();
        PieceClassifier.Result initial = resultFor(board);

        assertNull(tracker.observe(initial));
        PositionTracker.Update first = tracker.observe(initial);
        assertNotNull(first);
        assertTrue(first.initialPosition);
        assertFalse(tracker.isTurnKnown());

        assertTrue(board.doMove(findMove(board, "b8c6")));
        PieceClassifier.Result afterBlackMove = resultFor(board);
        assertNull(tracker.observe(afterBlackMove));
        PositionTracker.Update move = tracker.observe(afterBlackMove);

        assertNotNull(move);
        assertNotNull(move.move);
        assertEquals("b8c6", move.move.toString());
        assertTrue(move.turnInferred);
        assertTrue(tracker.isTurnKnown());
        assertTrue(tracker.isWhiteToMove());
    }

    private static Move findMove(Board board, String uci) {
        for (Move move : board.legalMoves()) {
            if (uci.equalsIgnoreCase(move.toString())) return move;
        }
        throw new AssertionError("Expected legal move not found: " + uci);
    }

    private static PieceClassifier.Result resultFor(Board board) {
        String placement = board.getFen().split(" ")[0];
        char[] screen = new char[64];
        int count = 0, white = 0, black = 0;
        for (int row = 0; row < 8; row++) {
            int col = 0;
            for (char symbol : placement.split("/")[row].toCharArray()) {
                if (Character.isDigit(symbol)) {
                    int empty = symbol - '0';
                    for (int i = 0; i < empty; i++) screen[row * 8 + col++] = '.';
                } else {
                    screen[row * 8 + col++] = symbol;
                    count++;
                    if (Character.isUpperCase(symbol)) white++;
                    else black++;
                }
            }
        }
        return new PieceClassifier.Result(screen, new float[64], 0.95f, 0.90f,
                0, count, true, true, 0.90f, white, black, false, 1, 1);
    }
}
