# ChessLens Realtime v0.9

ChessLens Realtime reads a visible digital chessboard, converts the recognized squares to FEN, and analyses the position with Stockfish 18 running locally in Android WebView.

## v0.9 highlights

- **Clear move arrows:** thick high-contrast arrows, glowing source-square rings, and destination markers. The last played move is cyan, the primary recommendation is green, and the predicted opponent reply is dashed orange.
- **Compact translucent HUD:** board relock, pause, hide/restore, stop, and separate `Saya` / `Lawan` visibility toggles.
- **Automatic orientation and player side:** the app estimates which color is at the bottom of the board and assumes that is the player's side.
- **Automatic turn tracking:** legal board transitions reveal whose turn follows. If the session begins mid-game, the app does not guess the initial turn; it waits for one observed legal move.
- **Legal PV validation:** every suggested move is checked against the recognized position before its arrow is drawn.
- **Fresh analysis only:** a new board state invalidates stale analysis, stops the old engine search, and clears queued work.
- **Smaller installer:** the APK contains only the `arm64-v8a` ONNX Runtime library. Stockfish remains a verified on-demand download after installation.

## Build

Use `.github/workflows/build-android-v0.9.yml` or upload the source archive `ChessLens-Realtime-v0.9-Auto-Arrow.zip` to the repository root and run the workflow. The workflow:

1. Downloads the MIT-licensed Chess CV model weights.
2. Converts the model to ONNX and checks the model shape/inference path.
3. Runs the FEN mapping, learning-PV, v0.9 feature, and UCI parser smoke tests.
4. Downloads the pinned Stockfish 18.0.5 JavaScript/WASM assets to calculate SHA-256 values and patches those values into the installer.
5. Builds and verifies an ARM64-only debug APK.
6. Confirms that Stockfish JS/WASM is not bundled in the APK and uploads the APK as a workflow artifact.

## Important behavior when starting mid-game

A single static board image cannot reveal whose turn it is. If ChessLens starts after the game has already begun, it reads the piece placement and board orientation first, then waits until it sees one legal move between two stable positions. After that transition, it knows the next side to move and starts showing recommendations. If several moves are missed or the position cannot be matched to one legal move, it resynchronises and waits again rather than showing a potentially wrong arrow.

Player color is inferred from the side at the bottom of the displayed board. This assumes the player is seated at the bottom of their board view.

See `THIRD_PARTY_NOTICES.md` for model and runtime licenses.
