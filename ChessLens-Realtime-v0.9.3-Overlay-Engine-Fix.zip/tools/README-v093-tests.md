# v0.9.3 test taxonomy

- `tools/test_v093_features.py`: static code assertions (fast).
- `tools/test_fen_mapping.py`, `tools/test_learning_pv.py`: coordinate and PV mapping assertions.
- `tools/uci-smoke/TestUciEngine.java`: parser and progress listener with a **fake** Worker response.
- `gradle testDebugUnitTest`: ChessLib tracking and 1.e4 regression tests (requires Android Gradle toolchain).
- **Real engine test**: starts from `ScreenService` on an Android device with the actual downloaded Stockfish 18 WebAssembly and sends real FEN/go commands. Only an actual device run can validate this path.
