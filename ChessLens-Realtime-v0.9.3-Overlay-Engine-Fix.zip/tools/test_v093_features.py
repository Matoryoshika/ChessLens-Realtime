#!/usr/bin/env python3
"""Static integrity checks; real WASM engine is tested on-device by ScreenService.
This cannot replace an actual Android build or a background Worker handshake test.
"""
from pathlib import Path
from zipfile import ZipFile
import re

ROOT = Path(__file__).resolve().parents[1]
def read(path): return (ROOT / path).read_text(encoding='utf-8')

host = read('app/src/main/java/id/chesslens/realtime/engine/WasmEngineHost.java')
service = read('app/src/main/java/id/chesslens/realtime/ScreenService.java')
uci = read('app/src/main/java/id/chesslens/realtime/engine/UciEngine.java')
tracker = read('app/src/main/java/id/chesslens/realtime/vision/PositionTracker.java')
gradle = read('app/build.gradle')
practice = read('app/src/main/java/id/chesslens/realtime/practice/PracticeActivity.java')
assert "versionCode 11" in gradle and "versionName '0.9.3'" in gradle
assert "abiFilters 'arm64-v8a'" in gradle
assert 'attachForService(Service service)' in host
assert 'WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY' in host
assert 'restartServiceHost(Service service)' in host
assert 'releaseService()' in host
assert 'private final long generation;' in host
assert 'generation != epoch' in host
assert 'onLine(String line)' in host and 'onError(String message)' in host
assert 'String diagnosticStage' in host
assert 'Stockfish Worker' in host
assert 'WasmEngineHost.attachForService(this)' in service
assert 'Uji mandiri engine gagal sebelum CV' in service
assert 'legalPvMove(starting, check, 0)' in service
assert 'recoverEngineIfNeeded' in service
assert 'showProvisional(' in service
assert 'synchronized (UCI_LOCK)' in uci
assert 'ProgressListener' in uci and 'onProgress(new Evaluation' in uci
assert '"position startpos"' in uci
assert 'Stockfish tidak mengirim bestmove setelah' in uci
assert 'if (homeRank != (screenPieces[i] != \'.\')) return false;' in tracker
assert 'whiteKingRow >= 5 && blackKingRow <= 2' in tracker
assert 'Hentikan Overlay sebelum analisis Papan Latihan' in practice
print('PASS: v0.9.3 background Service ownership, UCI isolation, self-test, progress, startup/FEN guards')
