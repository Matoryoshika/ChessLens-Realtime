package id.chesslens.realtime.vision;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Side;
import com.github.bhlangonijr.chesslib.move.Move;

/** Tracks stable board positions and infers the side to move from observed legal transitions. */
public final class PositionTracker {
    private static final String START_PLACEMENT =
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

    private boolean whiteBottom = true;
    private boolean orientationLocked = false;
    private boolean whiteToMove = true;
    private boolean turnKnown = false;
    private String currentPlacement = "";
    private String pendingPlacement = "";
    private int stableFrames = 0;
    private Board currentBoard;

    public static final class Update {
        public final Board before;
        public final Board after;
        public final Move move;
        public final boolean initialPosition;
        public final boolean resynchronised;
        public final boolean turnKnown;
        public final boolean turnInferred;
        public final String fen;

        Update(Board before, Board after, Move move, boolean initial, boolean resync,
               boolean known, boolean inferred) {
            this.before = before;
            this.after = after;
            this.move = move;
            this.initialPosition = initial;
            this.resynchronised = resync;
            this.turnKnown = known;
            this.turnInferred = inferred;
            this.fen = after.getFen();
        }
    }

    private static final class Match {
        final Board before;
        final Board after;
        final Move move;
        Match(Board before, Board after, Move move) {
            this.before = before;
            this.after = after;
            this.move = move;
        }
    }

    public synchronized boolean isReady() { return currentBoard != null; }
    public synchronized boolean isWhiteBottom() { return whiteBottom; }
    public synchronized boolean isOrientationKnown() { return orientationLocked; }
    public synchronized boolean isTurnKnown() { return turnKnown; }
    public synchronized boolean isWhiteToMove() { return whiteToMove; }
    public synchronized String getFen() { return currentBoard == null ? "" : currentBoard.getFen(); }
    public synchronized Board getBoardCopy() { return currentBoard == null ? null : copy(currentBoard); }

    public synchronized void resetPosition() {
        currentPlacement = "";
        pendingPlacement = "";
        stableFrames = 0;
        currentBoard = null;
        whiteToMove = true;
        turnKnown = false;
    }

    /**
     * Applies a stable model result. Two matching frames are required for a move.
     * If the app starts mid-game, the turn is deliberately unknown until a legal
     * one-ply transition is observed; piece placement alone cannot reveal whose
     * turn it is. A standard starting position is the one safe exception.
     */
    public synchronized Update observe(PieceClassifier.Result result) {
        if (result == null || result.pieceCount < 4 || result.averageConfidence < 0.42f
                || result.lowConfidenceSquares > 22) return null;

        boolean orientationChanged = false;
        if (!orientationLocked) {
            Boolean kingOrientation = inferWhiteBottomFromKings(result.screenPieces);
            if (kingOrientation == null && looksLikeStartingOccupancy(result.screenPieces)) {
                kingOrientation = inferWhiteBottomFromStartingRows(result.screenPieces);
            }
            boolean reliable = kingOrientation != null || result.orientationReliable;
            if (reliable) {
                boolean nextWhiteBottom = kingOrientation != null
                        ? kingOrientation : result.suggestedWhiteBottom;
                orientationChanged = currentBoard != null && whiteBottom != nextWhiteBottom;
                whiteBottom = nextWhiteBottom;
                orientationLocked = true;
                if (orientationChanged) resetPosition();
            }
        }

        String placement = result.toFenPlacement(whiteBottom);
        boolean startingSetup = currentBoard == null && looksLikeStartingOccupancy(result.screenPieces);
        if (startingSetup) placement = START_PLACEMENT;
        if (!isSanePlacement(placement)) return null;

        if (!placement.equals(pendingPlacement)) {
            pendingPlacement = placement;
            stableFrames = 1;
            return null;
        }
        stableFrames++;
        if (stableFrames < 2 || placement.equals(currentPlacement)) return null;

        if (currentBoard == null) {
            currentPlacement = placement;
            whiteToMove = true;
            turnKnown = startingSetup || START_PLACEMENT.equals(placement);
            currentBoard = boardFromPlacement(placement, whiteToMove);
            pendingPlacement = placement;
            return new Update(null, copy(currentBoard), null, true, false, turnKnown, false);
        }

        if (turnKnown) {
            Match currentSide = findMatchingMove(currentBoard, placement);
            if (currentSide != null) return accept(currentSide, placement, false);

            // Recover if an earlier recognition error left the remembered turn one ply behind.
            Match otherSide = findMatchingMove(currentPlacement, !whiteToMove, placement);
            if (otherSide != null) return accept(otherSide, placement, true);
        } else {
            Match whiteCandidate = findMatchingMove(currentPlacement, true, placement);
            Match blackCandidate = findMatchingMove(currentPlacement, false, placement);
            if (whiteCandidate != null && blackCandidate == null)
                return accept(whiteCandidate, placement, true);
            if (blackCandidate != null && whiteCandidate == null)
                return accept(blackCandidate, placement, true);
        }

        // Do not resynchronise on a brief drag/animation frame. Wait for four
        // identical classifications before accepting a non-one-ply position.
        if (stableFrames < 4) return null;

        Board before = copy(currentBoard);
        currentPlacement = placement;
        whiteToMove = true; // placeholder only; turnKnown prevents engine use.
        turnKnown = false;
        currentBoard = boardFromPlacement(placement, whiteToMove);
        pendingPlacement = placement;
        return new Update(before, copy(currentBoard), null, false, true, false, false);
    }

    private Update accept(Match match, String placement, boolean inferred) {
        currentBoard = match.after;
        currentPlacement = placement;
        whiteToMove = currentBoard.getSideToMove() == Side.WHITE;
        turnKnown = true;
        pendingPlacement = placement;
        return new Update(copy(match.before), copy(currentBoard), match.move,
                false, false, true, inferred);
    }

    private static Match findMatchingMove(Board source, String targetPlacement) {
        if (source == null) return null;
        Board before = copy(source);
        for (Move move : before.legalMoves()) {
            Board after = copy(before);
            if (after.doMove(move) && placementOf(after).equals(targetPlacement))
                return new Match(before, after, move);
        }
        return null;
    }

    private static Match findMatchingMove(String placement, boolean sideWhite, String targetPlacement) {
        return findMatchingMove(boardFromPlacement(placement, sideWhite), targetPlacement);
    }

    private static Board boardFromPlacement(String placement, boolean whiteToMove) {
        Board board = new Board();
        String castling = START_PLACEMENT.equals(placement) ? "KQkq" : "-";
        board.loadFromFen(placement + (whiteToMove ? " w " : " b ") + castling + " - 0 1");
        return board;
    }

    private static String placementOf(Board board) {
        return board.getFen().split(" ")[0];
    }

    private static Board copy(Board source) {
        Board result = new Board();
        result.loadFromFen(source.getFen());
        return result;
    }

    private static Boolean inferWhiteBottomFromKings(char[] screenPieces) {
        int whiteKingRow = -1, blackKingRow = -1, whiteKings = 0, blackKings = 0;
        for (int i = 0; i < screenPieces.length; i++) {
            if (screenPieces[i] == 'K') { whiteKings++; whiteKingRow = i / 8; }
            else if (screenPieces[i] == 'k') { blackKings++; blackKingRow = i / 8; }
        }
        if (whiteKings != 1 || blackKings != 1) return null;
        if (whiteKingRow >= 5 && blackKingRow <= 2) return true;
        if (blackKingRow >= 5 && whiteKingRow <= 2) return false;
        return null;
    }

    private static Boolean inferWhiteBottomFromStartingRows(char[] screenPieces) {
        int topWhite = 0, topBlack = 0, bottomWhite = 0, bottomBlack = 0;
        for (int i = 0; i < 64; i++) {
            char piece = screenPieces[i];
            int row = i / 8;
            if (row <= 1) {
                if (Character.isUpperCase(piece) && piece != '.') topWhite++;
                else if (Character.isLowerCase(piece)) topBlack++;
            } else if (row >= 6) {
                if (Character.isUpperCase(piece) && piece != '.') bottomWhite++;
                else if (Character.isLowerCase(piece)) bottomBlack++;
            }
        }
        if (topBlack >= topWhite + 3 && bottomWhite >= bottomBlack + 3) return true;
        if (topWhite >= topBlack + 3 && bottomBlack >= bottomWhite + 3) return false;
        return null;
    }

    /**
     * Only a board with all 32 pieces on their two home ranks is eligible
     * for start-position recovery. After 1.e4 one pawn is in the center and
     * must NEVER be silently replaced with the full starting FEN.
     */
    private static boolean looksLikeStartingOccupancy(char[] screenPieces) {
        if (screenPieces == null || screenPieces.length != 64) return false;
        int kingsWhite = 0, kingsBlack = 0;
        for (int i = 0; i < 64; i++) {
            if (screenPieces[i] == 'K') kingsWhite++;
            if (screenPieces[i] == 'k') kingsBlack++;
            boolean homeRank = (i / 8 <= 1 || i / 8 >= 6);
            if (homeRank != (screenPieces[i] != '.')) return false;
        }
        return kingsWhite == 1 && kingsBlack == 1;
    }

    private static boolean isSanePlacement(String placement) {
        int whiteKings = 0, blackKings = 0, whitePawns = 0, blackPawns = 0;
        int pieces = 0;
        String[] ranks = placement.split("/");
        if (ranks.length != 8) return false;
        for (int rank = 0; rank < ranks.length; rank++) {
            int files = 0;
            for (int i = 0; i < ranks[rank].length(); i++) {
                char p = ranks[rank].charAt(i);
                if (p >= '1' && p <= '8') { files += p - '0'; continue; }
                files++;
                if (p == 'K') whiteKings++;
                else if (p == 'k') blackKings++;
                else if (p == 'P') { whitePawns++; if (rank == 0 || rank == 7) return false; }
                else if (p == 'p') { blackPawns++; if (rank == 0 || rank == 7) return false; }
                else if (!(p >= 'A' && p <= 'Z') && !(p >= 'a' && p <= 'z')) return false;
                pieces++;
            }
            if (files != 8) return false;
        }
        return whiteKings == 1 && blackKings == 1 && pieces <= 32
                && whitePawns <= 8 && blackPawns <= 8;
    }
}
