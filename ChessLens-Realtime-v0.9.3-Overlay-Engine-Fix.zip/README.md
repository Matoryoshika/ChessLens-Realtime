# ChessLens Realtime v0.9.3

Android ARM64 chess position recognition and locally downloaded Stockfish 18 WASM engine, with a practice board and an opt-in screen-capture overlay.

## What's new in v0.9.3

The Overlay now attaches its 2×2 non-touchable WebView Worker to the foreground `ScreenService`, rather than relying on an Activity that is backgrounded when another chess app is shown. Stockfish sessions are serialized across modes, with an independent Android on-device self-test, diagnostic UCI stages, engine restart on transport failure, and provisional (clearly labeled) PV arrows before final `bestmove`. The position tracker no longer guesses a starting board after a pawn has moved to the center.

See `CHANGELOG-v0.9.3.md` and `tools/README-v093-tests.md` for exact changes, tests, and limitations.

## Build using GitHub Actions

1. Upload `ChessLens-Realtime-v0.9.3-Overlay-Engine-Fix.zip` to repository root. The filename can end in `(1)` or `(2)`; the workflow selects the most recently committed matching ZIP.
2. Upload `build-android-v0.9.3.yml` to `.github/workflows/`. Suffixes such as `(1)` are accepted by `push.paths` glob.
3. Commit both files on `main`. The workflow automatically builds an ARM64 debug APK and uploads `ChessLens-Realtime-v0.9.3-ARM64-APK`.

The workflow downloads the pinned ONNX piece classifier, Stockfish 18 WASM package, verifies assets and runs static checks, JVM UCI parser smoke tests and Android/ChessLib unit tests. **Android device validation is still required**: a successful build and fake UCI smoke test cannot prove the real WebView Worker stays responsive on your phone.

## Usage and diagnostics

Install and permit floating overlay plus Android screen capture. Before classifying captured frames, `ScreenService` sends a real starting FEN to Stockfish; HUD should show `Stockfish Overlay siap (FEN awal → ...)`. If this fails, note the UCI stage (`Worker`, `uciok`, `readyok`) and compare to Papan Latihan **with Overlay stopped**. Check behavior on initial position, after 1.e4, middlegame, check and flipped boards.

In midgame, a screenshot alone cannot reveal the side to move, all castling/en-passant rights or move history; this application does not invent those facts. The recognition model has not been retrained for every 3D piece theme, and panah/analysis still depend on a correct observed board.

Use on games and platforms only when assistance is permitted.
