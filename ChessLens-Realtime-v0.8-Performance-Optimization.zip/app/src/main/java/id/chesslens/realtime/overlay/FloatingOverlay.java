package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact, draggable HUD with a separate restore handle when minimized. */
public final class FloatingOverlay {
    private final WindowManager windowManager;
    private final ArrowCanvas arrows;
    private final LinearLayout panel;
    private final TextView status;
    private final Button pauseButton;
    private final Button orientationButton;
    private final Button turnButton;
    private final Button myBestButton;
    private final Button opponentBestButton;
    private final Button playerSideButton;
    private final WindowManager.LayoutParams params;
    private final TextView miniHandle;
    private final WindowManager.LayoutParams miniParams;
    private boolean minimized = false;
    private float touchX, touchY;
    private int beginX, beginY;

    public FloatingOverlay(Context context, Runnable relockBoard, Runnable togglePause,
                           Runnable flipOrientation, Runnable toggleTurn, Runnable toggleMyBest,
                           Runnable toggleOpponentBest, Runnable togglePlayerSide, Runnable stop) {
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        arrows = new ArrowCanvas(context);
        WindowManager.LayoutParams canvasParams = new WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        canvasParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowManager.addView(arrows, canvasParams);

        panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(context, 8), dp(context, 7), dp(context, 8), dp(context, 7));
        GradientDrawable backdrop = new GradientDrawable();
        backdrop.setColor(0xee111a2c);
        backdrop.setCornerRadius(dp(context, 14));
        panel.setBackground(backdrop);
        panel.setElevation(dp(context, 5));

        status = new TextView(context);
        status.setText("♟ ChessLens: mencari papan…");
        status.setTextSize(11);
        status.setTextColor(Color.WHITE);
        status.setMaxLines(6);
        status.setMinWidth(0);
        panel.addView(status);

        TextView hint = new TextView(context);
        hint.setText("Hijau: kamu · Oranye putus: lawan");
        hint.setTextSize(9);
        hint.setTextColor(0xffb7c5d9);
        hint.setMaxLines(1);
        panel.addView(hint);

        LinearLayout firstRow = row(context);
        Button relock = button(context, "Kunci", relockBoard);
        addWeighted(context, firstRow, relock);
        orientationButton = button(context, "Putih↓", flipOrientation);
        addWeighted(context, firstRow, orientationButton);
        turnButton = button(context, "Giliran P", toggleTurn);
        addWeighted(context, firstRow, turnButton);
        panel.addView(firstRow);

        LinearLayout secondRow = row(context);
        pauseButton = button(context, "Jeda", togglePause);
        addWeighted(context, secondRow, pauseButton);
        Button hide = button(context, "Sembunyi", this::hidePanel);
        addWeighted(context, secondRow, hide);
        Button close = button(context, "Stop", stop);
        addWeighted(context, secondRow, close);
        panel.addView(secondRow);

        LinearLayout learningRow = row(context);
        myBestButton = button(context, "Saya ON", toggleMyBest);
        opponentBestButton = button(context, "Lawan ON", toggleOpponentBest);
        playerSideButton = button(context, "Saya P", togglePlayerSide);
        addWeighted(context, learningRow, myBestButton);
        addWeighted(context, learningRow, opponentBestButton);
        addWeighted(context, learningRow, playerSideButton);
        panel.addView(learningRow);

        params = new WindowManager.LayoutParams(
                dp(context, 232), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = dp(context, 8);
        params.y = dp(context, 72);
        windowManager.addView(panel, params);

        miniHandle = new TextView(context);
        miniHandle.setText("♟");
        miniHandle.setTextSize(21);
        miniHandle.setTextColor(Color.WHITE);
        miniHandle.setGravity(Gravity.CENTER);
        GradientDrawable miniBackground = new GradientDrawable();
        miniBackground.setColor(0xee111a2c);
        miniBackground.setCornerRadius(dp(context, 24));
        miniBackground.setStroke(dp(context, 1), 0xff38bdf8);
        miniHandle.setBackground(miniBackground);
        miniHandle.setElevation(dp(context, 5));
        miniHandle.setOnClickListener(view -> showPanel());
        miniParams = new WindowManager.LayoutParams(
                dp(context, 48), dp(context, 48),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        miniParams.gravity = Gravity.TOP | Gravity.LEFT;
        miniParams.x = params.x;
        miniParams.y = params.y;

        status.setOnTouchListener((View view, MotionEvent event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                touchX = event.getRawX();
                touchY = event.getRawY();
                beginX = params.x;
                beginY = params.y;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = beginX + (int) (event.getRawX() - touchX);
                params.y = beginY + (int) (event.getRawY() - touchY);
                windowManager.updateViewLayout(panel, params);
                return true;
            }
            return true;
        });
    }

    private static LinearLayout row(Context context) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private static void addWeighted(Context context, LinearLayout row, Button button) {
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(
                0, dp(context, 32), 1f);
        layout.setMargins(dp(context, 1), dp(context, 1), dp(context, 1), dp(context, 1));
        row.addView(button, layout);
    }

    private static Button button(Context context, String label, Runnable action) {
        Button button = new Button(context);
        button.setText(label);
        button.setTextSize(9);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(dp(context, 2), 0, dp(context, 2), 0);
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xff263449);
        background.setCornerRadius(dp(context, 7));
        button.setBackground(background);
        button.setOnClickListener(view -> action.run());
        return button;
    }

    private void hidePanel() {
        if (minimized) return;
        panel.setVisibility(View.GONE);
        miniParams.x = params.x;
        miniParams.y = params.y;
        windowManager.addView(miniHandle, miniParams);
        minimized = true;
    }

    private void showPanel() {
        if (!minimized) return;
        try { windowManager.removeView(miniHandle); } catch (Exception ignored) { }
        panel.setVisibility(View.VISIBLE);
        windowManager.updateViewLayout(panel, params);
        minimized = false;
    }

    private static int dp(Context context, int value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public void status(String message) {
        if (status != null) status.post(() -> status.setText(message));
    }

    public void setPaused(boolean paused) {
        pauseButton.post(() -> pauseButton.setText(paused ? "Lanjut" : "Jeda"));
    }

    public void setOrientation(boolean whiteBottom, boolean manual) {
        String label = whiteBottom ? "Putih↓" : "Hitam↓";
        orientationButton.post(() -> orientationButton.setText(label + (manual ? " *" : "")));
    }

    public void setTurn(boolean whiteToMove) {
        turnButton.post(() -> turnButton.setText("Giliran " + (whiteToMove ? "P" : "H")));
    }

    public void setLearningOptions(boolean myBest, boolean opponentBest, boolean playerWhite) {
        myBestButton.post(() -> myBestButton.setText("Saya " + (myBest ? "ON" : "OFF")));
        opponentBestButton.post(() -> opponentBestButton.setText("Lawan " + (opponentBest ? "ON" : "OFF")));
        playerSideButton.post(() -> playerSideButton.setText("Saya " + (playerWhite ? "P" : "H")));
    }

    public void annotate(Rect rect, int frameWidth, int frameHeight,
                         String from, String to, String symbol,
                         String myBestMove, String opponentBestMove, boolean whiteBottom) {
        arrows.post(() -> arrows.update(rect, frameWidth, frameHeight, from, to, symbol,
                myBestMove, opponentBestMove, whiteBottom));
    }

    public void clear() {
        arrows.post(() -> arrows.update(null, 0, 0, "", "", "", "", "", true));
    }

    public void dispose() {
        try { windowManager.removeView(arrows); } catch (Exception ignored) { }
        if (minimized) {
            try { windowManager.removeView(miniHandle); } catch (Exception ignored) { }
        }
        try { windowManager.removeView(panel); } catch (Exception ignored) { }
    }
}
