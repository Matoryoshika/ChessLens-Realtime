package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Draws played-move, own-best, and predicted-opponent arrows over the captured board. */
public final class ArrowCanvas extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Rect sourceBoardRect;
    private Rect drawBoardRect;
    private int sourceWidth;
    private int sourceHeight;
    private String playedFrom = "", playedTo = "", myFrom = "", myTo = "";
    private String opponentFrom = "", opponentTo = "", symbol = "";
    private boolean whiteBottom = true;

    public ArrowCanvas(Context context) {
        super(context);
    }

    public void update(Rect rect, int frameWidth, int frameHeight,
                       String from, String to, String mark,
                       String myMove, String opponentMove, boolean white) {
        sourceBoardRect = rect == null ? null : new Rect(rect);
        sourceWidth = frameWidth;
        sourceHeight = frameHeight;
        playedFrom = from == null ? "" : from;
        playedTo = to == null ? "" : to;
        symbol = mark == null ? "" : mark;
        myFrom = square(myMove, 0);
        myTo = square(myMove, 2);
        opponentFrom = square(opponentMove, 0);
        opponentTo = square(opponentMove, 2);
        whiteBottom = white;
        invalidate();
    }

    private String square(String move, int offset) {
        if (move == null || !move.matches("[a-h][1-8][a-h][1-8][qrbn]?")) return "";
        return move.substring(offset, offset + 2);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (sourceBoardRect == null || getWidth() <= 0 || getHeight() <= 0) return;

        float sx = sourceWidth > 0 ? (float) getWidth() / sourceWidth : 1f;
        float sy = sourceHeight > 0 ? (float) getHeight() / sourceHeight : 1f;
        drawBoardRect = new Rect(
                Math.round(sourceBoardRect.left * sx),
                Math.round(sourceBoardRect.top * sy),
                Math.round(sourceBoardRect.right * sx),
                Math.round(sourceBoardRect.bottom * sy));
        if (drawBoardRect.width() < 8 || drawBoardRect.height() < 8) return;

        if (!playedFrom.isEmpty() && !playedTo.isEmpty()) {
            int color = ("??".equals(symbol) || "?".equals(symbol)) ? 0xffed5965
                    : ("?!".equals(symbol) || "!?".equals(symbol)) ? 0xffe7a23a
                    : 0xff32c886;
            arrow(canvas, playedFrom, playedTo, color, false);
            if (!symbol.isEmpty() && !"…".equals(symbol)) badge(canvas, playedTo, symbol, color);
        }
        if (!opponentFrom.isEmpty() && !opponentTo.isEmpty()) {
            arrow(canvas, opponentFrom, opponentTo, 0xffffa126, true);
            badge(canvas, opponentTo, "L", 0xffd97706);
        }
        if (!myFrom.isEmpty() && !myTo.isEmpty()) {
            arrow(canvas, myFrom, myTo, 0xff22c55e, false);
            badge(canvas, myTo, "S", 0xff15803d);
        }
    }

    private void arrow(Canvas canvas, String from, String to, int color, boolean dashed) {
        PointF start = center(from);
        PointF finish = center(to);
        float boardUnit = Math.min(drawBoardRect.width(), drawBoardRect.height());
        float width = Math.max(4f, boardUnit / 82f);
        double angle = Math.atan2(finish.y - start.y, finish.x - start.x);
        float trim = Math.max(width * 1.35f, boardUnit / 46f);
        PointF lineEnd = new PointF(
                finish.x - (float) Math.cos(angle) * trim,
                finish.y - (float) Math.sin(angle) * trim);

        paint.reset();
        paint.setAntiAlias(true);
        paint.setColor(color);
        paint.setStrokeWidth(width);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStyle(Paint.Style.STROKE);
        if (dashed) paint.setPathEffect(new DashPathEffect(new float[]{width * 2f, width * 1.4f}, 0));
        canvas.drawLine(start.x, start.y, lineEnd.x, lineEnd.y, paint);
        paint.setPathEffect(null);

        float head = width * 2.8f;
        Path tip = new Path();
        tip.moveTo(finish.x, finish.y);
        tip.lineTo(finish.x - (float) Math.cos(angle - 0.51) * head,
                finish.y - (float) Math.sin(angle - 0.51) * head);
        tip.lineTo(finish.x - (float) Math.cos(angle + 0.51) * head,
                finish.y - (float) Math.sin(angle + 0.51) * head);
        tip.close();
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(tip, paint);
    }

    private void badge(Canvas canvas, String square, String mark, int background) {
        PointF destination = center(square);
        float tileWidth = drawBoardRect.width() / 8f;
        float tileHeight = drawBoardRect.height() / 8f;
        float radius = Math.max(10f, Math.min(tileWidth, tileHeight) * 0.19f);
        float bx = destination.x + tileWidth * 0.29f;
        float by = destination.y - tileHeight * 0.28f;

        paint.reset();
        paint.setAntiAlias(true);
        paint.setColor(background);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(bx, by, radius, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(radius * 0.98f);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        canvas.drawText(mark, bx, by + radius * 0.34f, paint);
    }

    private PointF center(String square) {
        int file = square.charAt(0) - 'a';
        int row = 8 - (square.charAt(1) - '0');
        if (!whiteBottom) {
            file = 7 - file;
            row = 7 - row;
        }
        float cellWidth = drawBoardRect.width() / 8f;
        float cellHeight = drawBoardRect.height() / 8f;
        return new PointF(
                drawBoardRect.left + (file + 0.5f) * cellWidth,
                drawBoardRect.top + (row + 0.5f) * cellHeight);
    }
}
