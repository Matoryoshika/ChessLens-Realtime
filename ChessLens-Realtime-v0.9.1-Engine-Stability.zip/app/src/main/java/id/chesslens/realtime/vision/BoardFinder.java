package id.chesslens.realtime.vision;

import android.graphics.Bitmap;
import android.graphics.Rect;

/**
 * Finds a square 8x8 checkerboard in a screen frame. The search accepts smaller
 * boards (split-screen / compact layouts), boards touching screen edges, and
 * avoids recycling the caller's bitmap when no scaling is necessary.
 */
public final class BoardFinder {
  private static final int LIMIT = 360;
  private static final double MIN_SCORE = 10.0;
  private volatile double lastScore = 0.0;
  private volatile int lastCandidateSize = 0;

  public double getLastScore() { return lastScore; }
  public int getLastCandidateSize() { return lastCandidateSize; }

  private static final class Candidate {
    final int x, y, size;
    final double score;
    Candidate(int x, int y, int size, double score) {
      this.x = x; this.y = y; this.size = size; this.score = score;
    }
  }

  public Rect find(Bitmap original) {
    lastScore = 0.0;
    lastCandidateSize = 0;
    if (original == null || original.isRecycled() || original.getWidth() < 96 || original.getHeight() < 96) return null;

    float ratio = Math.min(1f, (float) LIMIT / Math.min(original.getWidth(), original.getHeight()));
    int w = Math.max(8, Math.round(original.getWidth() * ratio));
    int h = Math.max(8, Math.round(original.getHeight() * ratio));
    Bitmap scaled = (w == original.getWidth() && h == original.getHeight())
        ? original : Bitmap.createScaledBitmap(original, w, h, true);
    boolean ownsScaled = scaled != original;

    try {
      int[] rgb = new int[w * h];
      scaled.getPixels(rgb, 0, w, 0, 0, w, h);
      int[] gray = new int[rgb.length];
      for (int i = 0; i < rgb.length; i++) {
        int v = rgb[i];
        gray[i] = ((v >> 16 & 255) * 77 + (v >> 8 & 255) * 150 + (v & 255) * 29) >> 8;
      }

      int minDimension = Math.min(w, h);
      int minSize = Math.max(96, (int) (minDimension * 0.36f));
      int maxSize = minDimension;
      int sizeStep = Math.max(7, (maxSize - minSize) / 20);
      Candidate best = new Candidate(0, 0, 0, -1);

      for (int size = minSize; size <= maxSize; size += sizeStep) {
        int step = Math.max(6, size / 26);
        for (int y = 0; y <= h - size; y += step) {
          for (int x = 0; x <= w - size; x += step) {
            double score = score(gray, w, h, x, y, size);
            if (score > best.score) best = new Candidate(x, y, size, score);
          }
        }
      }

      if (best.size == 0) return null;
      lastScore = best.score;
      lastCandidateSize = best.size;
      if (best.score < MIN_SCORE) return null;

      Candidate fine = best;
      int minFineSize = Math.max(minSize, best.size - Math.max(10, sizeStep));
      int maxFineSize = Math.min(maxSize, best.size + Math.max(10, sizeStep));
      for (int size = minFineSize; size <= maxFineSize; size += 3) {
        int y0 = Math.max(0, best.y - 12), y1 = Math.min(h - size, best.y + 12);
        int x0 = Math.max(0, best.x - 12), x1 = Math.min(w - size, best.x + 12);
        for (int y = y0; y <= y1; y += 3) {
          for (int x = x0; x <= x1; x += 3) {
            double score = score(gray, w, h, x, y, size);
            if (score > fine.score) fine = new Candidate(x, y, size, score);
          }
        }
      }

      lastScore = fine.score;
      lastCandidateSize = fine.size;
      if (fine.score < MIN_SCORE) return null;
      float inverse = 1f / ratio;
      int left = Math.max(0, Math.round(fine.x * inverse));
      int top = Math.max(0, Math.round(fine.y * inverse));
      int right = Math.min(original.getWidth(), Math.round((fine.x + fine.size) * inverse));
      int bottom = Math.min(original.getHeight(), Math.round((fine.y + fine.size) * inverse));
      if (right - left < 96 || bottom - top < 96) return null;
      return new Rect(left, top, right, bottom);
    } finally {
      if (ownsScaled && !scaled.isRecycled()) scaled.recycle();
    }
  }

  private double score(int[] gray, int width, int height, int x, int y, int size) {
    double light = 0, dark = 0, light2 = 0, dark2 = 0;
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        int cx = x + Math.round((col + 0.5f) * size / 8f);
        int cy = y + Math.round((row + 0.5f) * size / 8f);
        int offset = Math.max(2, Math.round(size / 8f * 0.34f));
        int a = gray[clamp(cy - offset, height) * width + clamp(cx - offset, width)];
        int b = gray[clamp(cy - offset, height) * width + clamp(cx + offset, width)];
        int c = gray[clamp(cy + offset, height) * width + clamp(cx - offset, width)];
        int d = gray[clamp(cy + offset, height) * width + clamp(cx + offset, width)];
        int minimum = Math.min(Math.min(a, b), Math.min(c, d));
        int maximum = Math.max(Math.max(a, b), Math.max(c, d));
        double value = (a + b + c + d - minimum - maximum) / 2.0;
        if (((row + col) & 1) == 0) { light += value; light2 += value * value; }
        else { dark += value; dark2 += value * value; }
      }
    }
    double meanLight = light / 32.0, meanDark = dark / 32.0;
    double varianceLight = Math.max(0, light2 / 32.0 - meanLight * meanLight);
    double varianceDark = Math.max(0, dark2 / 32.0 - meanDark * meanDark);
    double difference = meanLight - meanDark;
    return difference * difference / (5.0 + Math.sqrt(varianceLight) + Math.sqrt(varianceDark));
  }

  private static int clamp(int value, int limit) {
    return Math.max(0, Math.min(limit - 1, value));
  }
}
