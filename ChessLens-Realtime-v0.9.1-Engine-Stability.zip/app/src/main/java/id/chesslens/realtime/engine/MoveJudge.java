package id.chesslens.realtime.engine;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Piece;
import com.github.bhlangonijr.chesslib.Square;
import com.github.bhlangonijr.chesslib.move.Move;

/** Educational heuristics based on evaluation loss; NOT Chess.com Game Review's proprietary labels. */
public final class MoveJudge {
  public static class Result {
    public final String symbol, name, note, best;
    public final int centipawnsLost;
    public Result(String a,String b,String c,String d,int e){symbol=a;name=b;note=c;best=d;centipawnsLost=e;}
  }
  private static int value(Piece p){
    if(p==null||p==Piece.NONE)return 0;
    String s=p.getPieceType().name();
    switch(s){case "PAWN":return 100;case "KNIGHT":return 320;case "BISHOP":return 330;case "ROOK":return 500;case "QUEEN":return 900;default:return 0;}
  }
  private static boolean sacrificed(Board before,Board after,Move m){
    int moved=value(before.getPiece(m.getFrom()));
    int taken=value(before.getPiece(m.getTo()));
    if(moved<300||moved-taken<150)return false;
    // A valuable piece was deliberately left capturable immediately by the opponent.
    for(Move reply:after.legalMoves())if(reply.getTo()==m.getTo() && value(after.getPiece(m.getTo()))==moved)return true;
    return false;
  }
  public static Result judge(Board before,Board after,Move move,UciEngine.Evaluation pre,UciEngine.Evaluation post){
    int loss=Math.max(0,pre.cp+post.cp); // scores are from each position's side to move
    boolean best=pre.bestMove.equalsIgnoreCase(move.toString());
    String symbol,name,note;
    if(loss>=300){symbol="??";name="Blunder";note="Penurunan evaluasi sangat besar";}
    else if(loss>=150){symbol="?";name="Mistake";note="Ada alternatif lebih kuat";}
    else if(loss>=70){symbol="?!";name="Inaccuracy";note="Ketepatan langkah kurang optimal";}
    else if(loss>=35){symbol="!?";name="Interesting";note="Menarik, tetapi ada langkah lebih akurat";}
    else if(best && loss<=20 && sacrificed(before,after,move)){
      symbol="!!";name="Brilliant (perkiraan)";note="Pengorbanan bernilai tinggi yang didukung evaluasi mesin";
    }else if(best){symbol="★";name="Best";note="Langkah pilihan utama Stockfish";}
    else {symbol="!";name="Excellent";note="Sangat dekat dengan langkah terbaik";}
    return new Result(symbol,name,note,pre.bestMove,loss);
  }
}
