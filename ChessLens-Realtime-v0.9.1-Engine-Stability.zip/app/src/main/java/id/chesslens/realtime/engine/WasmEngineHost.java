package id.chesslens.realtime.engine;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Hosts the downloaded Stockfish 18 WebAssembly worker inside Android WebView. */
public final class WasmEngineHost {
    private static final String HOST = "chesslens.local";
    private static final String BASE_URL = "https://" + HOST + "/";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LinkedBlockingQueue<String> OUTPUT = new LinkedBlockingQueue<>();
    private static final CountDownLatch PAGE_READY = new CountDownLatch(1);
    private static volatile WebView webView;
    private static volatile String engineError;
    private static volatile boolean pageStarted;
    private static volatile Activity attachedActivity;

    private static final String HTML = "<!doctype html><html><head><meta charset='utf-8'>"
            + "<meta name='viewport' content='width=device-width,initial-scale=1'></head><body>"
            + "<script>"
            + "(function(){try{"
            + "const worker=new Worker('/engine/stockfish-18-single.js');"
            + "worker.onmessage=function(e){try{var d=e.data;ChessLensNative.onLine(String(d&&d.line!==undefined?d.line:d));}catch(x){}};"
            + "worker.onerror=function(e){try{ChessLensNative.onError('Worker Stockfish gagal: '+String(e.message||'unknown')+' ('+String(e.filename||'')+':'+String(e.lineno||0)+')');}catch(x){}};"
            + "worker.onmessageerror=function(e){try{ChessLensNative.onError('Pesan dari worker Stockfish tidak dapat dibaca.');}catch(x){}};"
            + "window.chesslensSend=function(command){try{worker.postMessage(String(command));}catch(e){ChessLensNative.onError('Perintah UCI gagal dikirim: '+String(e));}};"
            + "ChessLensNative.onReady();"
            + "}catch(e){ChessLensNative.onError(String(e&&e.message||e));}})();"
            + "</script></body></html>";

    private WasmEngineHost() {}

    /** Must be called on the UI thread after the two WASM files have been verified. */
    public static synchronized void attach(Activity activity, ViewGroup parent) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException("WasmEngineHost.attach harus dipanggil pada UI thread.");
        }
        attachedActivity = activity;
        if (webView == null) {
            webView = new WebView(activity);
            webView.setBackgroundColor(Color.TRANSPARENT);
            webView.setAlpha(0.01f);
            webView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(false);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            webView.addJavascriptInterface(new Bridge(), "ChessLensNative");
            webView.setWebViewClient(new WebViewClient() {
                @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    return intercept(request.getUrl());
                }
                @SuppressWarnings("deprecation")
                @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                    return intercept(Uri.parse(url));
                }
            });
        }
        if (webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) webView.getParent()).removeView(webView);
        }
        parent.addView(webView, 0, new ViewGroup.LayoutParams(2, 2));
        webView.onResume();
        webView.resumeTimers();
        if (!pageStarted) {
            pageStarted = true;
            webView.loadUrl(BASE_URL + "index.html");
        }
    }

    private static WebResourceResponse intercept(Uri uri) {
        if (uri == null || !HOST.equals(uri.getHost())) return null;
        String path = uri.getPath();
        try {
            if ("/".equals(path) || "/index.html".equals(path)) {
                return response("text/html", "UTF-8", new ByteArrayInputStream(HTML.getBytes(StandardCharsets.UTF_8)));
            }
            File file = null;
            String mime = null;
            if ("/engine/stockfish-18-single.js".equals(path)) {
                file = EngineInstaller.engineJsFile(attachedActivity);
                mime = "application/javascript";
            } else if ("/engine/stockfish.wasm".equals(path)
                    || "/engine/stockfish-18-single.wasm".equals(path)
                    || "/stockfish.wasm".equals(path)
                    || "/stockfish-18-single.wasm".equals(path)) {
                // Emscripten builds differ in whether they resolve the sibling WASM
                // relative to the worker URL or the document URL. Serve both aliases.
                file = EngineInstaller.engineWasmFile(attachedActivity);
                mime = "application/wasm";
            }
            if (file == null || !file.isFile()) return notFound();
            return response(mime, null, new FileInputStream(file));
        } catch (Exception e) {
            engineError = "Tidak dapat membuka aset Stockfish: " + e.getMessage();
            OUTPUT.offer("__CHESSLENS_ERROR__" + engineError);
            return notFound();
        }
    }

    private static WebResourceResponse response(String mime, String encoding, java.io.InputStream stream) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, encoding, 200, "OK", headers, stream);
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));
    }

    public static void awaitReady(long timeoutMs) throws Exception {
        if (webView == null) throw new IOException("Mesin WebAssembly belum disiapkan. Kembali ke ChessLens dan selesaikan persiapan Stockfish.");
        if (!PAGE_READY.await(timeoutMs, TimeUnit.MILLISECONDS)) {
            throw new IOException(engineError == null ? "WebView belum memuat mesin Stockfish." : engineError);
        }
        if (engineError != null) throw new IOException(engineError);
    }

    public static void send(String command) throws IOException {
        if (webView == null) throw new IOException("WebView Stockfish belum aktif.");
        final String quoted = JSONObject.quote(command);
        MAIN.post(() -> {
            WebView current = webView;
            if (current != null) current.evaluateJavascript("window.chesslensSend && window.chesslensSend(" + quoted + ");", null);
        });
    }

    public static String pollLine(long timeoutMs) throws Exception {
        String line = OUTPUT.poll(Math.max(1L, timeoutMs), TimeUnit.MILLISECONDS);
        if (line == null) {
            if (engineError != null) throw new IOException(engineError);
            return null;
        }
        if (line.startsWith("__CHESSLENS_ERROR__")) throw new IOException(line.substring("__CHESSLENS_ERROR__".length()));
        return line;
    }

    public static String nextLine(long timeoutMs) throws Exception {
        String line = pollLine(timeoutMs);
        if (line == null) throw new IOException("Stockfish tidak mengirim respons dalam batas waktu.");
        return line;
    }

    public static void clearOutput() { OUTPUT.clear(); }

    private static final class Bridge {
        @JavascriptInterface public void onReady() { PAGE_READY.countDown(); }
        @JavascriptInterface public void onLine(String line) {
            if (line != null) OUTPUT.offer(line);
        }
        @JavascriptInterface public void onError(String message) {
            engineError = message == null ? "Worker Stockfish mengalami kesalahan." : message;
            OUTPUT.offer("__CHESSLENS_ERROR__" + engineError);
            PAGE_READY.countDown();
        }
    }
}
