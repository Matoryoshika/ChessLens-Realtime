package id.chesslens.realtime.vision;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Collections;
import java.util.Map;

/**
 * On-device 13-class chess-square classifier.
 * Model input: 64 RGB square crops, NCHW float32, 32x32, values in [0,1].
 * Class order follows S1M0N38/chess-cv (MIT): bB,bK,bN,bP,bQ,bR,wB,wK,wN,wP,wQ,wR,xx.
 */
public final class PieceClassifier implements AutoCloseable {
    private static final int SIDE = 32;
    private static final int SQUARES = 64;
    private static final int PIXELS = SIDE * SIDE;
    private static final String[] LABELS = {
            "bB", "bK", "bN", "bP", "bQ", "bR",
            "wB", "wK", "wN", "wP", "wQ", "wR", "xx"
    };
    private static final char[] SYMBOLS = {
            'b', 'k', 'n', 'p', 'q', 'r',
            'B', 'K', 'N', 'P', 'Q', 'R', '.'
    };

    private final OrtEnvironment environment;
    private final OrtSession session;
    private final OrtSession.SessionOptions sessionOptions;
    private final String inputName;
    private Boolean rotatePieces180 = null;
    private Result lastResult;
    private final float[] inputBuffer = new float[SQUARES * 3 * PIXELS];
    private final ByteBuffer tensorBytes = ByteBuffer.allocateDirect(SQUARES * 3 * PIXELS * Float.BYTES).order(ByteOrder.nativeOrder());
    private final FloatBuffer tensorBuffer = tensorBytes.asFloatBuffer();
    private int[] boardPixelBuffer = new int[0];
    private final char[][] recentPieces = new char[3][];
    private final float[][] recentConfidence = new float[3][];
    private int historyCount = 0;
    private int historyCursor = 0;
    private int lowConfidenceStreak = 0;

    public static final class Result {
        public final char[] screenPieces;
        public final float[] confidenceBySquare;
        public final float averageConfidence;
        public final float minimumConfidence;
        public final int lowConfidenceSquares;
        public final int pieceCount;
        public final boolean suggestedWhiteBottom;
        public final boolean orientationReliable;
        public final float orientationConfidence;
        public final int whiteSamples;
        public final int blackSamples;
        public final boolean rotated180;
        public final int whiteKings;
        public final int blackKings;

        Result(char[] pieces, float[] confidence, float average, float minimum, int low,
               int count, boolean whiteBottom, boolean orientationReliable,
               float orientationConfidence, int whiteSamples, int blackSamples,
               boolean rotated180, int whiteKings, int blackKings) {
            this.screenPieces = pieces;
            this.confidenceBySquare = confidence;
            this.averageConfidence = average;
            this.minimumConfidence = minimum;
            this.lowConfidenceSquares = low;
            this.pieceCount = count;
            this.suggestedWhiteBottom = whiteBottom;
            this.orientationReliable = orientationReliable;
            this.orientationConfidence = orientationConfidence;
            this.whiteSamples = whiteSamples;
            this.blackSamples = blackSamples;
            this.rotated180 = rotated180;
            this.whiteKings = whiteKings;
            this.blackKings = blackKings;
        }

        /** Returns FEN piece placement, independent of whose turn it is. */
        public String toFenPlacement(boolean whiteBottom) {
            StringBuilder fen = new StringBuilder(80);
            for (int rankRow = 0; rankRow < 8; rankRow++) {
                int empty = 0;
                for (int file = 0; file < 8; file++) {
                    int screenRow = whiteBottom ? rankRow : 7 - rankRow;
                    int screenCol = whiteBottom ? file : 7 - file;
                    char piece = screenPieces[screenRow * 8 + screenCol];
                    if (piece == '.') {
                        empty++;
                    } else {
                        if (empty > 0) { fen.append(empty); empty = 0; }
                        fen.append(piece);
                    }
                }
                if (empty > 0) fen.append(empty);
                if (rankRow < 7) fen.append('/');
            }
            return fen.toString();
        }

        public String labelAtScreen(int row, int col) {
            char p = screenPieces[row * 8 + col];
            if (p == '.') return "Kosong";
            String color = Character.isUpperCase(p) ? "Putih" : "Hitam";
            String type;
            switch (Character.toLowerCase(p)) {
                case 'k': type = "Raja"; break;
                case 'q': type = "Menteri"; break;
                case 'r': type = "Benteng"; break;
                case 'b': type = "Gajah"; break;
                case 'n': type = "Kuda"; break;
                default: type = "Pion"; break;
            }
            return color + " " + type;
        }
    }

    public PieceClassifier(Context context) throws Exception {
        environment = OrtEnvironment.getEnvironment();
        sessionOptions = new OrtSession.SessionOptions();
        sessionOptions.setIntraOpNumThreads(Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1)));
        sessionOptions.setInterOpNumThreads(1);
        sessionOptions.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
        byte[] model;
        try (InputStream input = context.getAssets().open("models/chess-pieces.onnx");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32 * 1024];
            for (int read; (read = input.read(buffer)) != -1;) output.write(buffer, 0, read);
            model = output.toByteArray();
        }
        if (model.length < 10_000) throw new IllegalStateException("Model pengenal bidak tidak lengkap.");
        session = environment.createSession(model, sessionOptions);
        if (session.getInputNames().isEmpty()) throw new IllegalStateException("Model tidak memiliki input.");
        inputName = session.getInputNames().iterator().next();
    }

    /**
     * On first use, compare upright and 180-degree-rotated square crops. This
     * supports boards where the black side is displayed at the bottom and the
     * piece artwork itself is rotated with the board. The chosen transform is
     * cached until the user manually flips the board or confidence collapses.
     */
    public synchronized Result classify(Bitmap frame, Rect board) throws Exception {
        if (rotatePieces180 == null || lowConfidenceStreak >= 4) {
            Result normal = classifyOnce(frame, board, false);
            Result rotated = classifyOnce(frame, board, true);
            if (recognitionScore(rotated) > recognitionScore(normal) + 0.005f) {
                rotatePieces180 = true;
                lastResult = rotated;
            } else {
                rotatePieces180 = false;
                lastResult = normal;
            }
            lowConfidenceStreak = lastResult.averageConfidence < 0.48f ? 1 : 0;
            clearHistory();
            lastResult = smooth(lastResult);
            return lastResult;
        }
        Result current = classifyOnce(frame, board, rotatePieces180);
        lowConfidenceStreak = current.averageConfidence < 0.48f ? lowConfidenceStreak + 1 : 0;
        lastResult = smooth(current);
        return lastResult;
    }

    public synchronized void setRotatePieces180(boolean value) {
        rotatePieces180 = value;
        lastResult = null;
        lowConfidenceStreak = 0;
        clearHistory();
    }

    private void clearHistory() {
        for (int i = 0; i < recentPieces.length; i++) {
            recentPieces[i] = null;
            recentConfidence[i] = null;
        }
        historyCount = 0;
        historyCursor = 0;
    }

    /** Majority-votes each square over the last three frames; a single noisy frame cannot move a piece. */
    private Result smooth(Result current) {
        recentPieces[historyCursor] = current.screenPieces.clone();
        recentConfidence[historyCursor] = current.confidenceBySquare.clone();
        historyCursor = (historyCursor + 1) % recentPieces.length;
        historyCount = Math.min(recentPieces.length, historyCount + 1);
        if (historyCount < 2) return current;

        char[] pieces = current.screenPieces.clone();
        float[] confidence = current.confidenceBySquare.clone();
        for (int square = 0; square < SQUARES; square++) {
            char[] labels = new char[13];
            float[] weights = new float[13];
            int[] votes = new int[13];
            int labelCount = 0;
            for (int h = 0; h < historyCount; h++) {
                int index = (historyCursor - 1 - h + recentPieces.length) % recentPieces.length;
                char label = recentPieces[index][square];
                int slot = -1;
                for (int j = 0; j < labelCount; j++) if (labels[j] == label) { slot = j; break; }
                if (slot < 0) { slot = labelCount++; labels[slot] = label; }
                votes[slot]++;
                weights[slot] += Math.max(0.05f, recentConfidence[index][square]);
            }
            int best = -1;
            for (int j = 0; j < labelCount; j++) {
                if (best < 0 || votes[j] > votes[best]
                        || (votes[j] == votes[best] && weights[j] > weights[best])) best = j;
            }
            if (best >= 0 && votes[best] >= 2) {
                pieces[square] = labels[best];
                confidence[square] = weights[best] / votes[best];
            }
        }

        double sum = 0, whiteRow = 0, blackRow = 0;
        float minimum = 1f;
        int low = 0, count = 0, whiteCount = 0, blackCount = 0, whiteKings = 0, blackKings = 0;
        for (int i = 0; i < SQUARES; i++) {
            float value = confidence[i];
            sum += value;
            minimum = Math.min(minimum, value);
            if (value < 0.42f) low++;
            char piece = pieces[i];
            if (piece == '.') continue;
            count++;
            int row = i / 8;
            if (Character.isUpperCase(piece)) {
                whiteRow += row; whiteCount++;
                if (piece == 'K') whiteKings++;
            } else {
                blackRow += row; blackCount++;
                if (piece == 'k') blackKings++;
            }
        }
        float whiteMean = whiteCount == 0 ? 0 : (float) (whiteRow / whiteCount);
        float blackMean = blackCount == 0 ? 0 : (float) (blackRow / blackCount);
        float separation = whiteMean - blackMean;
        float balance = Math.min(1f, Math.min(whiteCount, blackCount) / 5f);
        float orientationConfidence = Math.min(1f, Math.abs(separation) / 3f) * balance;
        boolean orientationReliable = whiteCount >= 2 && blackCount >= 2
                && Math.abs(separation) >= 0.85f && orientationConfidence >= 0.25f;
        return new Result(pieces, confidence, (float) (sum / SQUARES), minimum, low, count,
                separation > 0, orientationReliable, orientationConfidence, whiteCount, blackCount,
                current.rotated180, whiteKings, blackKings);
    }

    private static float recognitionScore(Result result) {
        float score = result.averageConfidence;
        if (result.whiteKings == 1 && result.blackKings == 1) score += 0.12f;
        if (result.pieceCount >= 4 && result.pieceCount <= 32) score += 0.02f;
        if (result.lowConfidenceSquares <= 12) score += 0.02f;
        return score;
    }

    private Result classifyOnce(Bitmap frame, Rect board, boolean rotate180) throws Exception {
        if (frame == null || frame.isRecycled() || board == null || board.width() < 96 || board.height() < 96)
            throw new IllegalArgumentException("Area papan tidak valid.");
        if (board.left < 0 || board.top < 0 || board.right > frame.getWidth() || board.bottom > frame.getHeight())
            throw new IllegalArgumentException("Area papan berada di luar frame layar.");

        int boardArea = board.width() * board.height();
        if (boardPixelBuffer.length < boardArea) boardPixelBuffer = new int[boardArea];
        frame.getPixels(boardPixelBuffer, 0, board.width(), board.left, board.top, board.width(), board.height());
        float[] input = inputBuffer;
        float cellWidth = board.width() / 8f;
        float cellHeight = board.height() / 8f;
        for (int square = 0; square < SQUARES; square++) {
            int row = square / 8, col = square % 8;
            int base = square * 3 * PIXELS;
            for (int y = 0; y < SIDE; y++) {
                int sampleY = rotate180 ? SIDE - 1 - y : y;
                int sourceY = clamp(Math.round(board.top + (row + (sampleY + 0.5f) / SIDE) * cellHeight), frame.getHeight());
                for (int x = 0; x < SIDE; x++) {
                    int sampleX = rotate180 ? SIDE - 1 - x : x;
                    int sourceX = clamp(Math.round(board.left + (col + (sampleX + 0.5f) / SIDE) * cellWidth), frame.getWidth());
                    int color = boardPixelBuffer[(sourceY - board.top) * board.width() + (sourceX - board.left)];
                    int pixel = y * SIDE + x;
                    input[base + pixel] = ((color >> 16) & 255) / 255f;
                    input[base + PIXELS + pixel] = ((color >> 8) & 255) / 255f;
                    input[base + 2 * PIXELS + pixel] = (color & 255) / 255f;
                }
            }
        }

        tensorBuffer.clear();
        tensorBuffer.put(input);
        tensorBuffer.rewind();
        try (OnnxTensor tensor = OnnxTensor.createTensor(environment, tensorBuffer,
                new long[]{SQUARES, 3, SIDE, SIDE});
             OrtSession.Result output = session.run(Collections.singletonMap(inputName, tensor))) {
            Object raw = output.get(0).getValue();
            if (!(raw instanceof float[][])) throw new IllegalStateException("Bentuk output model tidak dikenali.");
            float[][] logits = (float[][]) raw;
            if (logits.length != SQUARES) throw new IllegalStateException("Model tidak mengembalikan 64 prediksi.");
            char[] pieces = new char[SQUARES];
            float[] confidence = new float[SQUARES];
            double sum = 0;
            float min = 1f;
            int low = 0, count = 0, whiteKings = 0, blackKings = 0;
            double whiteRow = 0, blackRow = 0;
            int whiteCount = 0, blackCount = 0;
            for (int i = 0; i < SQUARES; i++) {
                if (logits[i].length != LABELS.length) throw new IllegalStateException("Model bukan classifier 13 kelas.");
                int best = 0;
                float max = logits[i][0];
                for (int c = 1; c < logits[i].length; c++) {
                    if (logits[i][c] > max) { max = logits[i][c]; best = c; }
                }
                double denominator = 0;
                for (float value : logits[i]) denominator += Math.exp(Math.max(-40, Math.min(40, value - max)));
                float probability = (float) (1.0 / denominator);
                pieces[i] = SYMBOLS[best];
                confidence[i] = probability;
                sum += probability;
                min = Math.min(min, probability);
                if (probability < 0.42f) low++;
                if (pieces[i] != '.') {
                    count++;
                    int row = i / 8;
                    if (Character.isUpperCase(pieces[i])) {
                        whiteRow += row; whiteCount++;
                        if (pieces[i] == 'K') whiteKings++;
                    } else {
                        blackRow += row; blackCount++;
                        if (pieces[i] == 'k') blackKings++;
                    }
                }
            }
            float whiteMean = whiteCount == 0 ? 0 : (float) (whiteRow / whiteCount);
            float blackMean = blackCount == 0 ? 0 : (float) (blackRow / blackCount);
            float separation = whiteMean - blackMean;
            float balance = Math.min(1f, Math.min(whiteCount, blackCount) / 5f);
            float orientationConfidence = Math.min(1f, Math.abs(separation) / 3f) * balance;
            boolean orientationReliable = whiteCount >= 2 && blackCount >= 2
                    && Math.abs(separation) >= 0.85f && orientationConfidence >= 0.25f;
            return new Result(pieces, confidence, (float) (sum / SQUARES), min, low, count,
                    separation > 0, orientationReliable, orientationConfidence, whiteCount, blackCount,
                    rotate180, whiteKings, blackKings);
        }
    }

    private static int clamp(int value, int limit) { return Math.max(0, Math.min(limit - 1, value)); }

    @Override public void close() {
        try { session.close(); } catch (Exception ignored) { }
        try { sessionOptions.close(); } catch (Exception ignored) { }
    }
}
