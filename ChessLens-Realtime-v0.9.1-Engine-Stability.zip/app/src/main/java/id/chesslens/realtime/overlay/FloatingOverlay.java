package id.chesslens.realtime.overlay;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact translucent HUD. Board orientation, player color, and turn are automatic. */
public final class FloatingOverlay {
    private final WindowManager windowManager;
    private final ArrowCanvas arrows;
    private final LinearLayout panel;
    private final TextView status;
    private final TextView autoState;
    private final Button pauseButton;
    private final Button myBestButton;
    private final Button opponentBestButton;
    private final WindowManager.LayoutParams params;
    private final TextView miniHandle;
    private final WindowManager.LayoutParams miniParams;
    private boolean minimized = false;
    private float touchX, touchY;
    private int beginX, beginY;

    public FloatingOverlay(Context context, Runnable relockBoard, Runnable togglePause,
                           Runnable toggleMyBest, Runnable toggleOpponentBest, Runnable stop) {
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        arrows = new ArrowCanvas(context);
        WindowManager.LayoutParams canvasParams = new WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        canvasParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowManager.addView(arrows, canvasParams);

        panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(context, 8), dp(context, 7), dp(context, 8), dp(context, 7));
        GradientDrawable backdrop = new GradientDrawable();
        backdrop.setColor(0xc7111a2c);
        backdrop.setCornerRadius(dp(context, 14));
        backdrop.setStroke(dp(context, 1), 0x5538bdf8);
        panel.setBackground(backdrop);
        panel.setElevation(dp(context, 5));

        status = new TextView(context);
        status.setText("♟ ChessLens aktif · mencari papan…");
        status.setTextSize(11);
        status.setTextColor(Color.WHITE);
        status.setMaxLines(5);
        status.setMinWidth(0);
        panel.addView(status);

        autoState = new TextView(context);
        autoState.setText("Papan, giliran, dan warna pemain: otomatis mendeteksi");
        autoState.setTextSize(9);
        autoState.setTextColor(0xffa9d8f5);
        autoState.setMaxLines(2);
        autoState.setPadding(0, dp(context, 2), 0, dp(context, 4));
        panel.addView(autoState);

        LinearLayout controls = row(context);
        addWeighted(context, controls, button(context, "Kunci", relockBoard));
        pauseButton = button(context, "Jeda", togglePause);
        addWeighted(context, controls, pauseButton);
        addWeighted(context, controls, button(context, "Sembunyi", this::hidePanel));
        addWeighted(context, controls, button(context, "Stop", stop));
        panel.addView(controls);

        LinearLayout learning = row(context);
        myBestButton = button(context, "Saya ON", toggleMyBest);
        opponentBestButton = button(context, "Lawan ON", toggleOpponentBest);
        addWeighted(context, learning, myBestButton);
        addWeighted(context, learning, opponentBestButton);
        panel.addView(learning);

        params = new WindowManager.LayoutParams(
                dp(context, 238), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = dp(context, 8);
        params.y = dp(context, 72);
        windowManager.addView(panel, params);

        miniHandle = new TextView(context);
        miniHandle.setText("♟");
        miniHandle.setTextSize(21);
        miniHandle.setTextColor(Color.WHITE);
        miniHandle.setGravity(Gravity.CENTER);
        GradientDrawable miniBackground = new GradientDrawable();
        miniBackground.setColor(0xc7111a2c);
        miniBackground.setCornerRadius(dp(context, 24));
        miniBackground.setStroke(dp(context, 1), 0xff38bdf8);
        miniHandle.setBackground(miniBackground);
        miniHandle.setElevation(dp(context, 5));
        miniHandle.setOnClickListener(view -> showPanel());
        miniParams = new WindowManager.LayoutParams(
                dp(context, 46), dp(context, 46),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        miniParams.gravity = Gravity.TOP | Gravity.LEFT;
        miniParams.x = params.x;
        miniParams.y = params.y;

        status.setOnTouchListener((View view, MotionEvent event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                touchX = event.getRawX();
                touchY = event.getRawY();
                beginX = params.x;
                beginY = params.y;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = beginX + (int) (event.getRawX() - touchX);
                params.y = beginY + (int) (event.getRawY() - touchY);
                windowManager.updateViewLayout(panel, params);
                return true;
            }
            return true;
        });
    }

    private static LinearLayout row(Context context) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private static void addWeighted(Context context, LinearLayout row, Button button) {
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, dp(context, 31), 1f);
        layout.setMargins(dp(context, 1), dp(context, 1), dp(context, 1), dp(context, 1));
        row.addView(button, layout);
    }

    private static Button button(Context context, String label, Runnable action) {
        Button button = new Button(context);
        button.setText(label);
        button.setTextSize(9);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(dp(context, 2), 0, dp(context, 2), 0);
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xdd263449);
        background.setCornerRadius(dp(context, 7));
        button.setBackground(background);
        button.setOnClickListener(view -> action.run());
        return button;
    }

    private void hidePanel() {
        if (minimized) return;
        panel.setVisibility(View.GONE);
        miniParams.x = params.x;
        miniParams.y = params.y;
        windowManager.addView(miniHandle, miniParams);
        minimized = true;
    }

    private void showPanel() {
        if (!minimized) return;
        try { windowManager.removeView(miniHandle); } catch (Exception ignored) { }
        panel.setVisibility(View.VISIBLE);
        windowManager.updateViewLayout(panel, params);
        minimized = false;
    }

    private static int dp(Context context, int value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public void status(String message) {
        if (status != null) status.post(() -> status.setText(message));
    }

    public void setAutoState(boolean orientationKnown, boolean whiteBottom,
                             boolean turnKnown, boolean whiteToMove) {
        String board = orientationKnown
                ? (whiteBottom ? "Papan: Putih di bawah" : "Papan: Hitam di bawah")
                : "Papan: membaca orientasi";
        String turn = turnKnown
                ? ("Giliran: " + (whiteToMove ? "Putih" : "Hitam"))
                : "Giliran: menunggu satu langkah legal";
        String player = orientationKnown
                ? ("Kamu: " + (whiteBottom ? "Putih" : "Hitam") + " (otomatis)")
                : "Kamu: mendeteksi sisi pemain";
        autoState.post(() -> autoState.setText(board + "  ·  " + turn + "\n" + player));
    }

    public void setPaused(boolean paused) {
        pauseButton.post(() -> pauseButton.setText(paused ? "Lanjut" : "Jeda"));
    }

    public void setLearningOptions(boolean myBest, boolean opponentBest) {
        myBestButton.post(() -> myBestButton.setText("Saya " + (myBest ? "ON" : "OFF")));
        opponentBestButton.post(() -> opponentBestButton.setText("Lawan " + (opponentBest ? "ON" : "OFF")));
    }

    public void annotate(Rect rect, int frameWidth, int frameHeight,
                         String from, String to, String symbol,
                         String myBestMove, String opponentBestMove,
                         boolean whiteBottom, boolean playerSideKnown) {
        arrows.post(() -> arrows.update(rect, frameWidth, frameHeight, from, to, symbol,
                myBestMove, opponentBestMove, whiteBottom, playerSideKnown));
    }

    public void clear() {
        arrows.post(() -> arrows.update(null, 0, 0, "", "", "", "", "", true, false));
    }

    public void dispose() {
        try { windowManager.removeView(arrows); } catch (Exception ignored) { }
        if (minimized) {
            try { windowManager.removeView(miniHandle); } catch (Exception ignored) { }
        }
        try { windowManager.removeView(panel); } catch (Exception ignored) { }
    }
}
