package id.chesslens.realtime.practice;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Square;
import com.github.bhlangonijr.chesslib.move.Move;
import id.chesslens.realtime.engine.UciEngine;
import id.chesslens.realtime.engine.EngineInstaller;
import id.chesslens.realtime.engine.MoveJudge;
import id.chesslens.realtime.engine.WasmEngineHost;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.*;

/** Native in-app practice board, FEN editor and saved-position history. */
public final class PracticeActivity extends Activity {
  private final Board board=new Board();
  private final List<String> undo=new ArrayList<>();
  private final ExecutorService executor=Executors.newSingleThreadExecutor();
  private ChessView boardView;
  private EditText fenBox;
  private TextView info;
  private boolean flipped=false;
  private String lastFrom="",lastTo="",best="",lastGrade="";
  private UciEngine engine;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    ScrollView scroll=new ScrollView(this);
    LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(14),dp(18),dp(14),dp(18));
    body.setBackgroundColor(0xfff2f5fa);scroll.addView(body);setContentView(scroll);
    TextView h=new TextView(this);h.setText("♟ Papan Latihan · ChessLens");h.setTextColor(0xff102036);h.setTextSize(23);body.addView(h);
    TextView caption=new TextView(this);caption.setText("Sentuh bidak lalu kotak tujuan. Aturan langkah diverifikasi chesslib. Mode ini tidak memerlukan tangkap layar.");caption.setTextColor(0xff4d6077);body.addView(caption);
    boardView=new ChessView(this);body.addView(boardView,new LinearLayout.LayoutParams(-1,getResources().getDisplayMetrics().widthPixels-dp(28)));
    info=new TextView(this);info.setTextColor(0xff22364a);info.setTextSize(14);info.setPadding(0,dp(8),0,dp(8));body.addView(info);
    LinearLayout row1=row(body);
    button(row1,"Balik",()->{flipped=!flipped;boardView.invalidate();});
    button(row1,"Undo",()->{if(!undo.isEmpty()){board.loadFromFen(undo.remove(undo.size()-1));lastFrom="";lastTo="";best="";refresh();}});
    button(row1,"Awal",()->{undo.clear();board.loadFromFen(new Board().getFen());lastFrom="";lastTo="";best="";refresh();});
    LinearLayout row2=row(body);
    button(row2,"Stockfish",this::analyze);
    button(row2,"Simpan",this::savePosition);
    button(row2,"Riwayat",this::showHistory);
    TextView label=new TextView(this);label.setText("Editor FEN");label.setTextSize(16);label.setTextColor(0xff233249);body.addView(label);
    fenBox=new EditText(this);fenBox.setSingleLine(false);fenBox.setMinLines(2);fenBox.setTextSize(13);fenBox.setSelectAllOnFocus(true);body.addView(fenBox);
    LinearLayout row3=row(body);
    button(row3,"Muat FEN",()->{
      try{Board test=new Board();test.loadFromFen(fenBox.getText().toString().trim());
        if(test.getFen()==null||test.getFen().isEmpty())throw new IllegalArgumentException("FEN kosong");
        undo.add(board.getFen());board.loadFromFen(test.getFen());lastFrom="";lastTo="";best="";refresh();
      }catch(Exception ex){toast("FEN tidak valid: "+ex.getMessage());}
    });
    button(row3,"Salin FEN",()->{
      android.content.ClipboardManager cb=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
      cb.setPrimaryClip(ClipData.newPlainText("FEN",board.getFen()));toast("FEN disalin");
    });
    refresh();
    if (EngineInstaller.isInstalled(this)) WasmEngineHost.attach(this, body);
  }
  private LinearLayout row(LinearLayout parent){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);parent.addView(r);return r;}
  private void button(LinearLayout r,String name,Runnable action){
    Button b=new Button(this);b.setText(name);b.setAllCaps(false);b.setTextSize(11);
    r.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));b.setOnClickListener(v->action.run());
  }
  private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  private void refresh(){
    if(fenBox!=null)fenBox.setText(board.getFen());
    if(info!=null)info.setText("Posisi: "+board.getSideToMove()+" melangkah"+(best.isEmpty()?"":" • Stockfish: "+best));
    boardView.invalidate();
  }
  private UciEngine stockfish() throws Exception {
    if(engine==null)engine=new UciEngine();
    return engine;
  }
  private void perform(Move m){
    final String beforeFen=board.getFen();
    undo.add(beforeFen);
    if(!board.doMove(m)){undo.remove(undo.size()-1);return;}
    final String afterFen=board.getFen();
    lastFrom=m.getFrom().toString().toLowerCase(Locale.ROOT);
    lastTo=m.getTo().toString().toLowerCase(Locale.ROOT);
    best="";lastGrade="";refresh();info.setText("⏳ Menghitung penilaian langkah "+m+"…");
    executor.submit(()->{
      try{
        UciEngine sf=stockfish();
        UciEngine.Evaluation pre=sf.analyze(beforeFen,650),post=sf.analyze(afterFen,650);
        Board b=new Board();b.loadFromFen(beforeFen);
        Board a=new Board();a.loadFromFen(afterFen);
        MoveJudge.Result grade=MoveJudge.judge(b,a,m,pre,post);
        runOnUiThread(()->{
          if(!board.getFen().equals(afterFen))return;
          best=post.bestMove;lastGrade=grade.symbol;refresh();
          info.setText(grade.symbol+" "+grade.name+" · "+m+"\n"+grade.note+"\nCPL: "+grade.centipawnsLost+" · Saran: "+best);
        });
      }catch(Exception ex){
        final String message="Analisis tidak tersedia: "+ex.getMessage();
        runOnUiThread(()->{if(board.getFen().equals(afterFen))info.setText(message);});
      }
    });
  }
  private void analyze(){
    final String fen=board.getFen();info.setText("Stockfish menganalisis posisi…");
    executor.submit(()->{
      try{
        UciEngine sf=stockfish();
        UciEngine.Evaluation e=sf.analyze(fen,1200);
        final String result="Stockfish: "+e.bestMove+" · "+e.description;
        final String recommendation=e.bestMove;
        runOnUiThread(()->{if(!board.getFen().equals(fen))return;best=recommendation;refresh();info.setText(result);});
      }catch(Exception ex){final String error="Engine belum tersedia: "+ex.getMessage();runOnUiThread(()->info.setText(error));}
    });
  }
  private void savePosition(){
    try{JSONArray archive=new JSONArray(getPreferences(0).getString("saved","[]"));
      JSONObject object=new JSONObject();object.put("fen",board.getFen());object.put("when",new java.text.SimpleDateFormat("dd MMM HH:mm",Locale.forLanguageTag("id-ID")).format(new Date()));
      JSONArray latest=new JSONArray();latest.put(object);
      for(int i=0;i<Math.min(archive.length(),29);i++)latest.put(archive.getJSONObject(i));
      getPreferences(0).edit().putString("saved",latest.toString()).apply();toast("Posisi disimpan ke Riwayat");
    }catch(Exception e){toast("Tidak dapat menyimpan");}
  }
  private void showHistory(){
    try{JSONArray archive=new JSONArray(getPreferences(0).getString("saved","[]"));
      if(archive.length()==0){toast("Belum ada posisi tersimpan");return;}
      String[] labels=new String[archive.length()];
      for(int i=0;i<archive.length();i++){JSONObject p=archive.getJSONObject(i);labels[i]=p.optString("when")+" · "+p.optString("fen").split(" ")[0];}
      new AlertDialog.Builder(this).setTitle("Riwayat posisi").setItems(labels,(dialog,which)->{
        try{undo.add(board.getFen());board.loadFromFen(archive.getJSONObject(which).getString("fen"));best="";lastFrom="";lastTo="";refresh();}
        catch(Exception ex){toast("Arsip gagal dibuka");}
      }).setNegativeButton("Tutup",null).show();
    }catch(Exception e){toast("Riwayat rusak");}
  }
  @Override protected void onDestroy(){executor.shutdownNow();if(engine!=null)engine.close();super.onDestroy();}

  private final class ChessView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private String selected="";
    private final Map<String,String> unicode=new HashMap<>();
    ChessView(Context c){super(c);
      String[] names={"WHITE_KING","WHITE_QUEEN","WHITE_ROOK","WHITE_BISHOP","WHITE_KNIGHT","WHITE_PAWN", "BLACK_KING","BLACK_QUEEN","BLACK_ROOK","BLACK_BISHOP","BLACK_KNIGHT","BLACK_PAWN"};
      String[] glyphs={"♔","♕","♖","♗","♘","♙","♚","♛","♜","♝","♞","♟︎"};
      for(int i=0;i<names.length;i++)unicode.put(names[i],glyphs[i]);
    }
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
      int size=Math.min(getWidth(),getHeight());float cell=size/8f;
      for(int row=0;row<8;row++)for(int col=0;col<8;col++){
        int file=flipped?7-col:col, rank=flipped?row:7-row;
        String square="abcdefgh".substring(file,file+1)+(rank+1);
        float x=col*cell,y=row*cell;
        p.setStyle(Paint.Style.FILL);p.setColor(((row+col)&1)==0?0xffefdfc8:0xff9e7957);
        canvas.drawRect(x,y,x+cell,y+cell,p);
        if(square.equals(selected)){p.setColor(0x88ffd447);canvas.drawRect(x,y,x+cell,y+cell,p);}
        if(square.equals(lastFrom)||square.equals(lastTo)){p.setColor(0x663bd5b3);canvas.drawRect(x,y,x+cell,y+cell,p);}
        if(best.length()>=4&&(square.equals(best.substring(0,2))||square.equals(best.substring(2,4)))){
          p.setColor(0x7740bcef);canvas.drawRect(x,y,x+cell,y+cell,p);
        }
        String key=board.getPiece(Square.valueOf(square.toUpperCase(Locale.ROOT))).name();
        String g=unicode.get(key);if(g!=null){
          p.setTextSize(cell*.78f);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
          p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2f);p.setColor(key.startsWith("WHITE")?0xff202b3a:0xfffafafa);
          canvas.drawText(g,x+cell/2,y+cell*.77f,p);
          p.setStyle(Paint.Style.FILL);p.setColor(key.startsWith("WHITE")?0xfffafafa:0xff101722);
          canvas.drawText(g,x+cell/2,y+cell*.77f,p);
        }
        p.setColor(0xaa27303b);p.setTextAlign(Paint.Align.LEFT);p.setTextSize(cell*.18f);
        if(col==0)canvas.drawText(""+(rank+1),x+2,y+cell*.22f,p);
        if(row==7)canvas.drawText("abcdefgh".substring(file,file+1),x+cell*.80f,y+cell*.95f,p);
      }
      if(lastFrom.length()==2&&lastTo.length()==2)drawArrow(canvas,lastFrom,lastTo,0xff1fa877,false);
      if(best.matches("[a-h][1-8][a-h][1-8][qrbn]?"))drawArrow(canvas,best.substring(0,2),best.substring(2,4),0xff1d9dd9,true);
      if(!lastGrade.isEmpty()){
        p.setStyle(Paint.Style.FILL);p.setTextSize(cell*.40f);p.setColor(0xff072a47);p.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(lastGrade,cell*.13f,cell*.45f,p);
      }
    }
    private void drawArrow(Canvas c,String from,String to,int color,boolean dashed){
      PointF a=center(from),b=center(to);float tile=Math.min(getWidth(),getHeight())/8f;
      float dx=b.x-a.x,dy=b.y-a.y;double angle=Math.atan2(dy,dx);
      Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);line.setColor(color);line.setStrokeWidth(tile*.11f);line.setStrokeCap(Paint.Cap.ROUND);
      if(dashed)line.setPathEffect(new DashPathEffect(new float[]{tile*.22f,tile*.12f},0));
      c.drawLine(a.x,a.y,b.x,b.y,line);line.setPathEffect(null);
      float tip=tile*.28f;Path head=new Path();head.moveTo(b.x,b.y);
      head.lineTo(b.x-(float)Math.cos(angle-.55)*tip,b.y-(float)Math.sin(angle-.55)*tip);
      head.lineTo(b.x-(float)Math.cos(angle+.55)*tip,b.y-(float)Math.sin(angle+.55)*tip);
      head.close();line.setStyle(Paint.Style.FILL);c.drawPath(head,line);
    }
    private PointF center(String sq){
      int file=sq.charAt(0)-'a',rank=sq.charAt(1)-'1';
      int col=flipped?7-file:file,row=flipped?rank:7-rank;
      float cell=Math.min(getWidth(),getHeight())/8f;
      return new PointF((col+.5f)*cell,(row+.5f)*cell);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent event){
      if(event.getAction()!=MotionEvent.ACTION_UP)return true;
      float side=Math.min(getWidth(),getHeight())/8f;int col=(int)(event.getX()/side),row=(int)(event.getY()/side);
      if(col<0||col>7||row<0||row>7)return true;
      int file=flipped?7-col:col,rank=flipped?row:7-row;
      String square="abcdefgh".substring(file,file+1)+(rank+1);
      if(selected.isEmpty()){for(Move m:board.legalMoves())if(m.getFrom().toString().equalsIgnoreCase(square)){selected=square;break;}}
      else{
        Move candidate=null;
        for(Move m:board.legalMoves()){
          if(m.getFrom().toString().equalsIgnoreCase(selected)&&m.getTo().toString().equalsIgnoreCase(square)){
            candidate=m;
            if(m.toString().endsWith("q"))break;
          }
        }
        selected="";
        if(candidate!=null)perform(candidate);
        else for(Move m:board.legalMoves())if(m.getFrom().toString().equalsIgnoreCase(square)){selected=square;break;}
      }
      invalidate();return true;
    }
  }
}
