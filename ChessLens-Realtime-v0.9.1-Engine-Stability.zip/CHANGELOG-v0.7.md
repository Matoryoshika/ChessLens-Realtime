# ChessLens Realtime v0.7 — Universal Position Recognition + Learning Mode

## Main changes

- Replaces the start-position-only template tracker with a 13-class per-square classifier.
- Reads 64 squares independently and generates FEN from arbitrary visible piece placement.
- Supports starting, opening, middlegame, and endgame positions when the board theme is compatible with the model.
- Locks board coordinates after detection; small movements are smoothed and larger relocations require two consistent frames instead of restarting piece calibration.
- Requires two consecutive matching classifications before accepting a new board state.
- Tests upright and 180-degree-rotated square crops to handle piece artwork that rotates with a flipped board; caches the more confident transform.
- Detects white/black piece distribution for an initial orientation estimate; the user can manually flip the board.
- Adds a Floating HUD control for side to move, because a single board image cannot reliably reveal turn, castling rights, or en-passant rights.
- Runs Stockfish analysis on the first stable position and after subsequent detected changes.
- Shows the best move arrow even when the session begins in the middle of a game.
- If a legal single-ply transition can be matched, evaluates the played move and returns a move-quality label; if frames were skipped, it resynchronises to the visible position and asks the user to verify the side to move.

## Model

- Uses the MIT-licensed Chess CV 13-class square classifier from S1M0N38/chess-cv.
- The CI workflow downloads the upstream `pieces.safetensors` weights, converts them to ONNX, verifies PyTorch/ONNX parity, and packages the ONNX model in the APK.
- Stockfish 18 WASM remains an on-demand in-app download and is not bundled in the APK.

## Known limitations

- The classifier was trained on synthetic 2D digital chessboard square images. It is intended for compatible Chess.com/Lichess-like screen boards; unusual piece sets, physical-board photographs, heavy perspective distortion, board animations, or themes outside the training distribution may reduce accuracy.
- The model does not infer side-to-move, castling rights, or en-passant rights from piece placement alone. Side to move can be changed in the HUD. For a session that starts mid-game, castling and en-passant rights default to none because prior move history is unavailable.
- If more than one ply occurs between stable frames, the app resynchronises to the visible position. The user should verify the turn button before trusting the recommendation.
- Build success and model conversion tests do not replace testing on the target Android phone and on the user's chessboard theme.

## Learning Mode — own move and predicted opponent reply

- Adds independent `Saya` and `Lawan` ON/OFF controls to the Floating HUD.
- Adds a `Saya: Putih/Hitam` player-side selector, saved across sessions.
- Parses Stockfish's deepest UCI `info ... pv` line and retains the principal variation.
- When it is the user's turn, the first PV move is shown as the user's recommendation and the second PV move is shown as the opponent's predicted best reply before the user moves.
- When it is the opponent's turn, the first PV move is shown as the opponent's best move and the second PV move as the user's predicted reply.
- Draws the user's arrow in green and the opponent's predicted arrow in dashed orange. Each can be hidden independently without restarting analysis.
- Reuses the same Stockfish analysis when toggles or player side change; recalculates when the recognised board position changes.
- Prediction is conditional on the preceding PV move and is not a guarantee of the opponent's actual choice.
