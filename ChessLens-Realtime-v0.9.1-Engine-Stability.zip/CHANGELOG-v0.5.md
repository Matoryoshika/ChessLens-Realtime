# Changelog — ChessLens Realtime v0.5

- Improved square-board search for smaller boards and boards touching display edges.
- Fixed a bitmap ownership issue when BoardFinder does not need to scale the source frame.
- Added automatic White/Black orientation estimation from local piece contrast and screen-space piece distribution.
- Added a visible orientation indicator and manual side override in Floating HUD.
- Kept arrow coordinate mapping consistent when the board is rotated 180 degrees.
- Added a conservative starting-position check so a middlegame is not silently treated as the standard initial position during template calibration.
- Removed the misleading fixed "White at bottom" checkbox from the dashboard; orientation is now auto-estimated and can be corrected in the HUD.
