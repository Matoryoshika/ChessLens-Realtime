# ChessLens Realtime v0.9.0

## Move arrows and HUD
- Engine arrows now use a thicker, high-contrast shaft with a soft glow.
- The source square receives a glowing ring; the destination square receives a clear target marker.
- The last played move is cyan, the primary recommendation is green, and the predicted reply is dashed orange.
- The floating HUD is smaller and more transparent. It keeps board relock, pause, hide/restore, stop, and independent `Saya` / `Lawan` visibility controls.
- Manual orientation, turn, and player-color buttons have been removed.

## Automatic recognition and safer recommendations
- Board orientation is inferred from recognized piece distribution.
- Player color is inferred from the color displayed at the bottom of the board.
- Side to move is inferred from a legal one-ply transition. When a session starts from a middlegame, the app waits for one observed legal move rather than guessing whose turn it is.
- If a position changes by more than one unrecognised ply, the tracker resynchronises and waits for a new legal transition before engine output resumes.
- Each Stockfish PV move is replayed against the recognised board and checked against legal moves before an arrow is drawn.
- New analysis requests clear stale queued jobs and stop the previous search so old recommendations do not appear after the board has changed.

## Package size and engine
- The APK is built for `arm64-v8a` only, avoiding the other three ONNX Runtime ABI libraries.
- Stockfish 18 WASM remains an on-demand in-app download and is not bundled in the APK.

## Known constraints
- A static midgame board does not contain enough information to prove whose turn it is. v0.9 deliberately waits for a legal board transition if no move history has been observed.
- If the app misses multiple moves between stable frames, it resynchronises and waits for another legal move instead of fabricating a turn.
- Player color assumes the player is seated on the bottom side of the displayed board.
- Recognition still depends on the supported digital-board visual themes and the classifier's confidence.
