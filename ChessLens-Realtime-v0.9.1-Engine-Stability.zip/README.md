# ChessLens Realtime v0.9.1

ChessLens Realtime reads a visible digital chessboard, converts the recognized squares to FEN, and analyses the position with Stockfish 18 running locally in Android WebView.

## v0.9.1 highlights

- **Clear move arrows:** soft translucent green recommendation arrows and dashed orange opponent-reply arrows. The last played move is not drawn as a recommendation-like arrow.
- **Compact translucent HUD:** board relock, pause, hide/restore, stop, and separate `Saya` / `Lawan` visibility toggles.
- **Automatic orientation and player side:** the app estimates which color is at the bottom of the board and assumes that is the player's side.
- **Automatic turn tracking:** legal board transitions reveal whose turn follows. If the session begins mid-game and the turn is unknown, the app analyses both possible sides to move and labels each recommendation rather than guessing.
- **Legal PV validation:** every suggested move is checked against the recognized position before its arrow is drawn.
- **Fresh analysis only:** a new board state invalidates stale analysis, stops the old engine search, and clears queued work.
- **Smaller installer:** the APK contains only the `arm64-v8a` ONNX Runtime library. Stockfish remains a verified on-demand download after installation.

## Build

Upload `ChessLens-Realtime-v0.9.1-Engine-Stability.zip` to the repository root and `.github/workflows/build-android-v0.9.1.yml` into the workflows folder. Committing either file triggers the build automatically. The workflow:

1. Downloads the MIT-licensed Chess CV model weights.
2. Converts the model to ONNX and checks the model shape/inference path.
3. Runs the FEN mapping, learning-PV, v0.9.1 feature, and UCI parser smoke tests.
4. Downloads the pinned Stockfish 18.0.5 JavaScript/WASM assets to calculate SHA-256 values and patches those values into the installer.
5. Builds and verifies an ARM64-only debug APK.
6. Confirms that Stockfish JS/WASM is not bundled in the APK and uploads the APK as a workflow artifact.

## Important behavior when starting mid-game

A static board image cannot prove whose turn it is. When ChessLens starts in a middlegame, it now analyses both FEN variants (White to move and Black to move) and labels the two recommendations separately. It does not claim either is the actual turn. After it observes a legal transition between stable positions, it knows the next side to move and switches to the single live recommendation.

The classifier uses short temporal voting and king-row orientation cues to reduce flicker and improve orientation on non-starting positions. The standard initial occupancy pattern can be normalised even if a small number of piece labels are uncertain. Recognition still depends on the board theme and piece artwork; custom 3D themes need validation against real screenshots.

Player color is inferred from the side at the bottom of the displayed board. This assumes the player is seated at the bottom of their board view.

See `THIRD_PARTY_NOTICES.md` for model and runtime licenses.
