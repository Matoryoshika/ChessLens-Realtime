# Changelog — ChessLens Realtime v0.6

- Removed Android FLAG_SECURE from both Floating HUD windows. The fullscreen transparent arrow layer no longer marks the whole display as secure, so system screenshots and MediaProjection can read the underlying chessboard.
- Added explicit MediaProjection diagnostics when no screen frame arrives or frame decoding fails; errors are no longer silently swallowed.
- Added BoardFinder diagnostic score and candidate-size reporting to distinguish capture failures from board-pattern detection failures.
- Updated first status message to confirm that screen capture is active and waiting for frames.
- Updated app version to versionCode 5 / versionName 0.6.0.

Important: this release fixes a confirmed screenshot-blocking configuration in ChessLens overlays. It does not bypass FLAG_SECURE screens in other apps. Board recognition still requires physical-device testing across board themes and photo perspective conditions.
