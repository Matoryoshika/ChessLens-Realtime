# ChessLens Realtime v0.9.1 — Engine Stability Hotfix

## Stockfish reliability
- Added a UCI `isready` barrier before each search to prevent stale output from crossing between searches.
- Reduced the default engine hash allocation to 8 MB for lower-memory Android devices.
- Increased the search watchdog and changed it to report the last engine line and number of responses received.
- Added worker error details and aliases for the common Emscripten WASM asset URL paths.
- The current-position recommendation is rendered before optional previous-move grading, so grading cannot suppress the live recommendation.

## Arrows
- The last played move is no longer drawn as a cyan recommendation-like arrow.
- Primary and predicted-reply arrows use softer translucent colors and thinner shafts.

## Recognition
- Added three-frame per-square majority smoothing to reduce one-frame piece flicker.
- Orientation can be inferred from the relative screen rows of the two kings when the piece-distribution heuristic is ambiguous.
- A near-complete standard starting occupancy pattern can be normalized to the standard initial FEN, so a few low-confidence piece labels do not block the starting position.
- Recognition confidence gate is less restrictive, while king count, board dimensions, and pawn-rank sanity checks remain enforced.

## Known limitation
- A static midgame board alone does not encode whose turn it is. ChessLens therefore analyses both possible side-to-move FENs and labels the two recommendations separately until a legal transition identifies the actual turn.
- Recognition accuracy on custom 3D piece themes must be validated against screenshots from the target chess app; temporal smoothing and orientation heuristics do not replace theme-specific training data.
