# ChessLens Realtime v0.9.1 — Build and QA checklist

## Checks completed in the prepared source archive
- [x] Python model-conversion script passes `py_compile`.
- [x] FEN orientation mapping test passes for normal, flipped, and non-starting layouts.
- [x] Learning PV mapping regression test passes for both player colors and both turns.
- [x] v0.9.1 feature checks confirm UCI readiness barriers, both-turn analysis for static middlegames, legal-PV validation, soft arrows, temporal piece smoothing, and ARM64-only packaging.
- [x] Added JUnit tests for standard-start detection, king-row orientation, near-complete start-layout recovery, and automatic turn inference after a legal move.
- [x] Stockfish remains an on-demand download and SHA-256 values are filled during CI.

## CI checks — pending GitHub Actions build
- [ ] Download the upstream Chess CV safetensors weights.
- [ ] Convert weights to ONNX and verify model inference/parity.
- [ ] Run FEN, PV, v0.9.1 feature, PositionTracker JUnit, and UCI parser smoke tests.
- [ ] Build the Android APK with ONNX Runtime.
- [ ] Verify APK signature and packaged model asset.
- [ ] Confirm the APK contains only `arm64-v8a` native libraries.
- [ ] Confirm Stockfish JS/WASM is not bundled in the installer APK.

## Must test on the target phone
- [ ] Start capture at the standard starting position; confirm White is initially detected to move.
- [ ] Start capture in a middlegame; confirm it shows separately labelled White-to-move and Black-to-move recommendations until a legal transition is observed.
- [ ] Make one legal move after a middlegame start; confirm the next side to move is inferred automatically.
- [ ] Flip the board; confirm orientation and player color follow the bottom side automatically.
- [ ] Confirm the recommended arrow is soft/translucent, readable, and not confused with the last played move.
- [ ] Confirm the player-side recommendation is muted green and the opponent-side prediction is muted dashed orange.
- [ ] Confirm only legal PV moves are drawn; invalid PV plies are omitted.
- [ ] Make a new move during analysis; confirm the stale search/queue is cancelled and no old arrow returns.
- [ ] Move/resize the board slightly and confirm the board lock follows without repeated calibration.
- [ ] Test at least one Chess.com theme and one Lichess-like theme.
- [ ] Confirm the compact HUD can be hidden/restored and that pause/stop still work.
- [ ] Confirm Stockfish worker initialises from the hidden WebView while capture is active.

## Known limits to verify, not conceal
- A static middlegame piece placement does not prove whose turn it is. The app analyses both side-to-move possibilities until a legal transition reveals the actual next turn.
- If multiple moves are missed between stable frames, the tracker resynchronises and waits for another legal transition.
- Player color is inferred from the color at the bottom of the displayed board; this assumes the user is at the bottom side.
- Endgames with too few pieces may not provide enough evidence for reliable automatic orientation.
- A successful APK build does not prove the classifier generalises to every board theme. Compare the recognised FEN with the visible board during phone testing.
