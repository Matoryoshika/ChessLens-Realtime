import id.chesslens.realtime.engine.UciEngine;

public final class TestUciEngine {
    public static void main(String[] args) throws Exception {
        UciEngine engine = new UciEngine();
        UciEngine.Evaluation result = engine.analyze("startpos", 700);
        if (!"e2e4".equals(result.bestMove)) throw new AssertionError("bestmove=" + result.bestMove);
        if (!"e7e5".equals(result.moveAt(1))) throw new AssertionError("PV=" + result.principalVariation);
        if (!"f1c4".equals(result.moveAt(4))) throw new AssertionError("PV=" + result.principalVariation);
        if (!"+0.41".equals(result.description)) throw new AssertionError("score=" + result.description);
        System.out.println("PASS: UCI bestmove + deepest PV + score: " + result.principalVariation);
    }
}
