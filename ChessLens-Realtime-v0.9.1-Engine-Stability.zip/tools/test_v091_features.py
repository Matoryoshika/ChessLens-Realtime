#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
read = lambda p: (ROOT / p).read_text(encoding="utf-8")

uci = read("app/src/main/java/id/chesslens/realtime/engine/UciEngine.java")
host = read("app/src/main/java/id/chesslens/realtime/engine/WasmEngineHost.java")
service = read("app/src/main/java/id/chesslens/realtime/ScreenService.java")
arrows = read("app/src/main/java/id/chesslens/realtime/overlay/ArrowCanvas.java")
tracker = read("app/src/main/java/id/chesslens/realtime/vision/PositionTracker.java")
classifier = read("app/src/main/java/id/chesslens/realtime/vision/PieceClassifier.java")
gradle = read("app/build.gradle")

assert 'send("isready")' in uci and 'waitFor("readyok", 12_000)' in uci
assert 'Stockfish tidak mengirim bestmove setelah' in uci
assert 'setoption name Hash value 8' in uci
assert 'pollLine(long timeoutMs)' in host
assert 'onmessageerror' in host and 'worker.onerror' in host
assert '"/stockfish-18-single.wasm".equals(path)' in host
assert 'Rekomendasi untuk posisi terbaru' in service
assert service.index('engine.analyze(afterFen, thinkMs)') < service.index('engine.analyze(beforeFen,')
assert 'result.averageConfidence < 0.42f' in service
assert 'recentPieces' in classifier and 'votes[best] >= 2' in classifier
assert 'inferWhiteBottomFromKings' in tracker and 'looksLikeStartingOccupancy' in tracker
assert 'analyzeBothTurns' in service and 'Jika Putih jalan' in service and 'Jika Hitam jalan' in service
assert 'result.lowConfidenceSquares > 22' in tracker
assert 'findMatchingMove(currentBoard, placement)' in tracker
assert 'START_PLACEMENT.equals(placement) ? \"KQkq\"' in tracker
assert 'drawMoveArrow(canvas, playedFrom' not in arrows
assert '0xC078A98B' in arrows and '0xB8C58A62' in arrows
assert 'versionCode 10' in gradle and "versionName '0.9.1'" in gradle
print('PASS: v0.9.1 engine stability, recommendation order, soft arrows, and recognition checks')
