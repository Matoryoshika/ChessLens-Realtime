#!/usr/bin/env python3
"""Sanity tests for mapping Stockfish PV plies to user and opponent moves."""


def select_moves(pv, white_to_move, player_white):
    user_to_move = white_to_move == player_white
    my_ply = 0 if user_to_move else 1
    opponent_ply = 1 if user_to_move else 0
    my_move = pv[my_ply] if my_ply < len(pv) else ""
    opponent_move = pv[opponent_ply] if opponent_ply < len(pv) else ""
    return my_move, opponent_move


cases = [
    (True, True, ["e2e4", "e7e5"], ("e2e4", "e7e5")),
    (True, False, ["e2e4", "e7e5"], ("e7e5", "e2e4")),
    (False, False, ["e7e5", "e2e4"], ("e7e5", "e2e4")),
    (False, True, ["e7e5", "e2e4"], ("e2e4", "e7e5")),
]
for white_to_move, player_white, pv, expected in cases:
    actual = select_moves(pv, white_to_move, player_white)
    assert actual == expected, (white_to_move, player_white, actual, expected)

assert select_moves(["e2e4"], True, True) == ("e2e4", "")
assert select_moves(["e2e4"], True, False) == ("", "e2e4")
print("PASS: Learning Mode PV mapping for White/Black player and both turns")
