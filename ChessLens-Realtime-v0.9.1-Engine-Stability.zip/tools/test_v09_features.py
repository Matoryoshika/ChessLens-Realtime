#!/usr/bin/env python3
"""Regression checks for the v0.9 automatic-turn, legal-PV, arrow, and APK changes."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
read = lambda path: (ROOT / path).read_text(encoding="utf-8")

tracker = read("app/src/main/java/id/chesslens/realtime/vision/PositionTracker.java")
service = read("app/src/main/java/id/chesslens/realtime/ScreenService.java")
arrows = read("app/src/main/java/id/chesslens/realtime/overlay/ArrowCanvas.java")
overlay = read("app/src/main/java/id/chesslens/realtime/overlay/FloatingOverlay.java")
gradle = read("app/build.gradle")

# A static middlegame position must not be assigned a fabricated side to move.
assert "private boolean turnKnown = false" in tracker
assert "START_PLACEMENT.equals(placement)" in tracker
assert "findMatchingMove(currentPlacement, true, placement)" in tracker
assert "findMatchingMove(currentPlacement, false, placement)" in tracker
assert "if (stableFrames < 4) return null" in tracker
assert "turnKnown = false" in tracker

# The HUD no longer exposes manual turn/orientation/player-side switches.
for obsolete in ("Putih↓", "Hitam↓", "Giliran P", "Saya P"):
    assert obsolete not in overlay
assert "setAutoState" in overlay
assert "Sembunyi" in overlay and "Lanjut" in overlay
assert "0xc7111a2c" in overlay  # translucent panel background

# Arrow styling includes the requested source glow, target marker, and thick shaft.
assert "drawOriginMarker" in arrows
assert "drawDestinationMarker" in arrows
assert "shaftWidth * 2.8f" in arrows
assert "0xff22c55e" in arrows and "0xffffa126" in arrows

# Engine PV plies are replayed through the current legal move list before drawing.
assert "legalPvMove(current, evaluation" in service
assert "for (com.github.bhlangonijr.chesslib.move.Move candidate : position.legalMoves())" in service
assert "analysisWorker.getQueue().clear()" in service
assert "tracker.isTurnKnown()" in service
assert "tracker.isOrientationKnown()" in service

# Ship one phone ABI only; Stockfish remains an in-app download.
assert "versionCode 9" in gradle
assert "versionName '0.9.0'" in gradle
assert "abiFilters 'arm64-v8a'" in gradle
installer = read("app/src/main/java/id/chesslens/realtime/engine/EngineInstaller.java")
assert "__STOCKFISH_WASM_SHA256__" in installer
assert "downloadOne(WASM_URL" in installer

print("PASS: v0.9 auto turn, legal PV, arrow/HUD, and ARM64 packaging checks")
