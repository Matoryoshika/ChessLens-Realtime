#!/usr/bin/env python3
"""Convert the MIT-licensed Chess CV MLX weights to a mobile ONNX model.

Source model: https://github.com/S1M0N38/chess-cv
Weights: https://huggingface.co/S1M0N38/chess-cv
The upstream MLX Conv2d kernels are stored as O-H-W-I; PyTorch expects O-I-H-W.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from safetensors.torch import load_file
from torch import nn


class ChessPieceCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fc1 = nn.Linear(64 * 4 * 4, 128)
        self.fc2 = nn.Linear(128, 13)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = self.pool(torch.relu(self.conv3(x)))
        # Upstream MLX uses NHWC; preserve its H-W-C flatten order before fc1.
        x = x.permute(0, 2, 3, 1).contiguous().reshape(x.shape[0], -1)
        x = torch.relu(self.fc1(x))
        return self.fc2(x)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    torch.set_num_threads(1)
    weights = load_file(args.weights, device="cpu")
    required = {
        "conv1.weight", "conv1.bias", "conv2.weight", "conv2.bias",
        "conv3.weight", "conv3.bias", "fc1.weight", "fc1.bias",
        "fc2.weight", "fc2.bias",
    }
    missing = sorted(required - set(weights))
    if missing:
        raise RuntimeError(f"Missing model tensors: {missing}")
    expected_shapes = {
        "conv1.weight": (16, 3, 3, 3), "conv1.bias": (16,),
        "conv2.weight": (32, 3, 3, 16), "conv2.bias": (32,),
        "conv3.weight": (64, 3, 3, 32), "conv3.bias": (64,),
        "fc1.weight": (128, 1024), "fc1.bias": (128,),
        "fc2.weight": (13, 128), "fc2.bias": (13,),
    }
    for name, shape in expected_shapes.items():
        if tuple(weights[name].shape) != shape:
            raise RuntimeError(f"Unexpected shape for {name}: {tuple(weights[name].shape)} != {shape}")

    state = {
        "conv1.weight": weights["conv1.weight"].permute(0, 3, 1, 2).contiguous(),
        "conv1.bias": weights["conv1.bias"],
        "conv2.weight": weights["conv2.weight"].permute(0, 3, 1, 2).contiguous(),
        "conv2.bias": weights["conv2.bias"],
        "conv3.weight": weights["conv3.weight"].permute(0, 3, 1, 2).contiguous(),
        "conv3.bias": weights["conv3.bias"],
        "fc1.weight": weights["fc1.weight"],
        "fc1.bias": weights["fc1.bias"],
        "fc2.weight": weights["fc2.weight"],
        "fc2.bias": weights["fc2.bias"],
    }
    model = ChessPieceCNN().eval()
    model.load_state_dict(state, strict=True)

    sample = torch.zeros((64, 3, 32, 32), dtype=torch.float32)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(
        model,
        sample,
        str(output),
        input_names=["input"],
        output_names=["logits"],
        dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}},
        opset_version=17,
        do_constant_folding=True,
        dynamo=False,
    )

    # Verify that ONNX Runtime and PyTorch agree before the model is packaged.
    import onnx
    onnx.checker.check_model(onnx.load(str(output)))
    import onnxruntime as ort

    rng = np.random.default_rng(20261123)
    batch = rng.random((64, 3, 32, 32), dtype=np.float32)
    with torch.no_grad():
        expected = model(torch.from_numpy(batch)).cpu().numpy()
    session = ort.InferenceSession(str(output), providers=["CPUExecutionProvider"])
    actual = session.run(["logits"], {"input": batch})[0]
    if actual.shape != (64, 13):
        raise RuntimeError(f"Unexpected ONNX output shape: {actual.shape}")
    if not np.isfinite(actual).all():
        raise RuntimeError("ONNX model produced non-finite values")
    max_error = float(np.max(np.abs(expected - actual)))
    if max_error > 1e-3:
        raise RuntimeError(f"PyTorch/ONNX mismatch: max absolute error {max_error}")
    print(f"ONNX model verified: {output} ({output.stat().st_size} bytes), max error={max_error:.8f}")


if __name__ == "__main__":
    main()
