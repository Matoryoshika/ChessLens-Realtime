#!/usr/bin/env python3
"""Small regression test for screen-orientation to canonical FEN mapping."""

START = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR"


def placement(screen_pieces: str, white_bottom: bool) -> str:
    rows = []
    for rank_row in range(8):
        row = []
        for file in range(8):
            screen_row = rank_row if white_bottom else 7 - rank_row
            screen_col = file if white_bottom else 7 - file
            row.append(screen_pieces[screen_row * 8 + screen_col])
        encoded = ""
        empty = 0
        for piece in row:
            if piece == ".":
                empty += 1
            else:
                if empty:
                    encoded += str(empty)
                    empty = 0
                encoded += piece
        if empty:
            encoded += str(empty)
        rows.append(encoded)
    return "/".join(rows)


def main() -> None:
    normal = START
    rotated = "".join(START[(7 - row) * 8 + (7 - col)] for row in range(8) for col in range(8))
    expected = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
    assert placement(normal, True) == expected
    assert placement(rotated, False) == expected

    # A deliberately non-starting middlegame-like position also survives a 180° flip.
    middle = list(START)
    middle[8] = "."; middle[48] = "p"
    middle[1] = "."; middle[42] = "n"
    middle = "".join(middle)
    middle_rotated = "".join(middle[(7 - row) * 8 + (7 - col)] for row in range(8) for col in range(8))
    assert placement(middle, True) == placement(middle_rotated, False)
    print("FEN orientation mapping: PASS (normal, flipped, non-starting layout)")


if __name__ == "__main__":
    main()
